import java.io.FileInputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.LowerCaseFilter;
import org.apache.lucene.analysis.PorterStemFilter;
import org.apache.lucene.analysis.StopFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.standard.StandardFilter;
import org.apache.lucene.analysis.standard.StandardTokenizer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.util.Version;

import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSTagger;
import opennlp.tools.postag.POSTaggerME;
import opennlp.tools.tokenize.Tokenizer;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;
import br.ufu.facom.lsa.Lda.ManipuladorDeTexto;


public class TestPartOfSpeechTagging {
	public static void main(String[] args) {
		try{
			POSModel posModel = new POSModel(new FileInputStream("/home/lucas/Dropbox/models OpenNLP/en-pos-maxent.bin"));
			
			POSTagger posTagger = new POSTaggerME(posModel);
			
			String sent[] = new String[]{"Most", "large", "cities", "in", "the", "US", "had",
	                "morning", "and", "afternoon", "newspapers"};	
			
			String postBody = "I want to use a track-bar to change a form's opacity. " + 
			"This is my code: " +
			"decimal trans = trackBar1.Value / 5000; " + 
			"this.Opacity = trans; " +
			" " +
			"When I try to build it, I get this error: " +
			" " +
			"Cannot implicitly convert type 'decimal' to 'double'. " +
			" " +
			"I tried making, but then the control doesn't work. This code has worked fine for me in VB.NET in the past.";

			//List<String> listaTokens = new ArrayList<String>();
			
			///List<String> listaTokens = obtemTokens(postBody);
			
			List<String> listaTokens = obtemTokens2(postBody);
			
			String vet[] = new String[listaTokens.size()];
			
			for(int i=0; i< listaTokens.size(); i++){
				vet[i] = listaTokens.get(i);
			}
			
			String tags[] = posTagger.tag(vet);
			
			for(int i=0; i < tags.length; i++){
				System.out.println(tags[i]);
			}
			
			//StringReader tReader = new StringReader(texto);
    		//TokenStream tStream = tokenStream("contents", tReader);
    		

		}catch(Exception e){
			e.printStackTrace();
		}
		//ManipuladorDeTexto mt = new ManipuladorDeTexto(vetAPIs, true);
		
			}

	private static List<String> obtemTokens(String postBody) {
		List<String> listaTokens = new ArrayList<String>();
		try{
			StringReader tReader = new StringReader(postBody);
			
			TokenStream result = new StandardTokenizer(Version.LUCENE_36, tReader);
			result = new StandardFilter(Version.LUCENE_36, result);
			result = new LowerCaseFilter(Version.LUCENE_36, result); 
			
			CharTermAttribute charTermAttribute = result.addAttribute(CharTermAttribute.class);
		    String saida = "";
			
		    while(result.incrementToken()){
				//Vamos desconsiderar tokens que contem apenas numeros
				//:TODO por enquanto estemos removendo numeros desta forma, mas a forma correta eh modificar a gramtica (jfex) para nao gerar esses numeros 
				String token = charTermAttribute.toString().toString();
				System.out.println(token);
				listaTokens.add(token);
				
		    }
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaTokens;
	}
	
	private static List<String> obtemTokens2(String postBody) {
		List<String> listaTokens = new ArrayList<String>();
		try{
			TokenizerModel tokenModel = new TokenizerModel(new FileInputStream("/home/lucas/Dropbox/models OpenNLP/en-token.bin"));
			Tokenizer tokenizer = new TokenizerME(tokenModel);
	   		String tokens[] = tokenizer.tokenize(postBody);
	   		for(int i=0; i< tokens.length; i++){
	   			listaTokens.add(tokens[i]);
	   			System.out.println(tokens[i]);
	   		}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaTokens;
	}
}

/*public static TokenStream tokenStream(String fieldName, Reader reader) {  
	
	TokenStream result = new StandardTokenizer(Version.LUCENE_36, reader);
	result = new StandardFilter(Version.LUCENE_36, result);
	result = new LowerCaseFilter(Version.LUCENE_36, result); 
	
	CharTermAttribute charTermAttribute = result.addAttribute(CharTermAttribute.class);
    String saida = "";
	
    while(result.incrementToken()){
		//Vamos desconsiderar tokens que contem apenas numeros
		//:TODO por enquanto estemos removendo numeros desta forma, mas a forma correta eh modificar a gramtica (jfex) para nao gerar esses numeros 
		String token = charTermAttribute.toString().toString();
		System.out.println(token);
    }
	
	
	result = new PorterStemFilter(result);   
    //Vamos remover stop words depois do stemming, pois o set de stowords contem o stemming das stop words
	result = new StopFilter(Version.LUCENE_36, result, stopWords);
    return result; *
} */
