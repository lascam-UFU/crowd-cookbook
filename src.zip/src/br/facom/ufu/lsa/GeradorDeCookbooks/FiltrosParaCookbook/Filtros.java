package br.facom.ufu.lsa.GeradorDeCookbooks.FiltrosParaCookbook;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.htmlcleaner.HtmlCleaner;
import org.htmlcleaner.TagNode;

import com.meterware.httpunit.GetMethodWebRequest;
import com.meterware.httpunit.HttpUnitOptions;
import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebRequest;
import com.meterware.httpunit.WebResponse;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;
import br.ufu.facom.lsa.Lda.ManipuladorDeTexto;

public class Filtros {
	
	/*public static void main(String[] args) {
		
	}*/
	
	private Map<String, Boolean> mapLinksTestados;
	private String caminhoDoArquivoComLinkTestados;
	private HtmlCleaner cleaner;
	//Se a pergunta possui tamanho a partir dessa qted de caracteres, a mesma eh considerada grande
	private int limiteDeTamanhoConsiderandoCodigo = 1300;
	private int limiteDeTamanhoDesconsiderandoCodigo = 1300;
	
	public Filtros(String caminhoDoArquivoComLinkTestados){
		mapLinksTestados = new HashMap<String, Boolean>();
		this.caminhoDoArquivoComLinkTestados = caminhoDoArquivoComLinkTestados;
		this.cleaner  = new HtmlCleaner(); 
		if(!this.caminhoDoArquivoComLinkTestados.equals(""))
			inicializaMapDeLinksTestados();
	}
	
	private void inicializaMapDeLinksTestados() {
		try{
			BufferedReader bufferedArquivoResultadoLinks = new BufferedReader(new InputStreamReader(new FileInputStream(caminhoDoArquivoComLinkTestados)));
			String linha = "";
			while ((linha = bufferedArquivoResultadoLinks.readLine()) != null) {
				String vet[] = linha.split(" ");
				String url = vet[0];
				
				//System.out.println(linha);
				boolean status = vet[1].equals("1") ? true : false ;
				mapLinksTestados.put(url, status);
			}
			bufferedArquivoResultadoLinks.close();	
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public boolean possuiPerguntaGrande(String corpoPost, boolean consideraCodigoFonte){
		int tamanhoDaPergunta = calculaNroDeCaracteresEmPost(corpoPost,consideraCodigoFonte);
		
		if(consideraCodigoFonte && tamanhoDaPergunta >= limiteDeTamanhoConsiderandoCodigo)
			return true;
		else if(!consideraCodigoFonte && tamanhoDaPergunta >= limiteDeTamanhoDesconsiderandoCodigo)
			return true;
		return false;
	}
	
	private  int calculaNroDeCaracteresEmPost(String corpoResposta, boolean consideraCodigoFonte) {
		try{
			//Primeiro vamos remover os codigos, uams vez que nao sera considerados no calculo de tamanho do post
			TagNode root = cleaner.clean( corpoResposta );
			
			if(!consideraCodigoFonte){
				Object[] codeNodes = root.evaluateXPath( "//code" );
				for(int i=0; i<codeNodes.length; i++){
					((TagNode)codeNodes[i]).removeFromTree();
				}
			}
			String texto = "";
			texto += root.getText();
			
			return texto.length();
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
	
	public boolean possuiLinksMortos(String corpoPost){
		List<String> listaDeUrls = encontraLinks(corpoPost);
		//TODO mudar isso
		for(int i=0; i< listaDeUrls.size(); i++){
			//try{
			//se encontrar alguma url invalida, retorna true
			if(mapLinksTestados.containsKey(listaDeUrls.get(i)) && !mapLinksTestados.get(listaDeUrls.get(i)))
				return true;
			//}catch(Exception e){
			//	System.out.println(listaDeUrls.get(i));
			////	e.printStackTrace();
			//	return false;
			//}
		}
		return false;
	}

	public boolean possuiCodigoFonte(String corpoDoPost) {
		if(getNumeroDeTrechosDeCodigo(corpoDoPost) > 0)
			return true;
		return false;
	}
	
	//metodo responsavel por descobir o numero de trechos de codigo existente num post
	public int getNumeroDeTrechosDeCodigo(String texto){
		try{
			TagNode root = cleaner.clean( texto );
			
			Object[] codeNodes = root.evaluateXPath( "//pre/code" );
			return codeNodes.length;
		}catch(Exception e){
			e.printStackTrace();
		}
		
		//return textoCodigos;
		return 0;
	}
	
	public List<String> encontraLinks(String corpoPost) {
		List<String> listUrlLinks = new ArrayList<String>();
		try{
			TagNode root = cleaner.clean( corpoPost );
			
			Object[] QuotedBlocksNodes = root.evaluateXPath( "//a" );
			for(int i=0; i<QuotedBlocksNodes.length; i++){
				String url = "";
				url += ((TagNode)QuotedBlocksNodes[i]).getAttributeByName("href");
				listUrlLinks.add(url);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return listUrlLinks;
	}
	
	/*public static boolean possuiLinksMortos(String corpoPost){
		List<String> listaDeUrls = encontraLinks(corpoPost);
		for(int i=0; i< listaDeUrls.size(); i++){
			//se encontrar alguma url invalida, retorna true
			if(!verificaValidadeDeUrl(listaDeUrls.get(i)))
				return true;
		}
		return false;
	}
	
	public static boolean verificaValidadeDeUrl(String url){
		try{
			url = "http://portal.acm.org/citation.cfm?id=234418";
			/*HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
			connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-GB;     rv:1.9.2.13) Gecko/20101203 Firefox/3.6.13 (.NET CLR 3.5.30729)");
		   connection.setRequestMethod("GET");
			
			int responseCode = connection.getResponseCode();
			//OK -> codigo 200
 			if (responseCode != 200) 
			    return false;
			return true;
			 URL source = new URL(url);
			 URLConnection connection = source.openConnection();
	            connection.setRequestProperty("User-Agent","Mozilla/5.0 ( compatible ) ");
	            connection.setRequestProperty("Accept","[star]/[star]");
	            connection.setDoInput(true);
	            //connection.setDoOutput(true);
	            int code = (((HttpURLConnection) connection).getResponseCode());
	            int a = 0;
			
			/*url = "http://www.transio.com/content/how-pass-spam-filters-php-mail";
			HttpURLConnection connection = null;
			URL u = new URL(url);
	        connection = (HttpURLConnection) u.openConnection();
	        connection.setRequestMethod("HEAD");
	        int code = connection.getResponseCode();
	        System.out.println("" + code);*/
			
			
			
			/*URL u = new URL(url); 
		    HttpURLConnection huc =  (HttpURLConnection)  u.openConnection(); 
		    huc.setRequestMethod("HEAD"); 
		    huc.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 (.NET CLR 3.5.30729)");
		    huc.connect(); 
		    int code = huc.getResponseCode();
		    int a = 0;*/
			


			//url = "http://portal.acm.org/citation.cfm?id=234418";
			/*url = "http://www.google.com";
			HttpUnitOptions.setScriptingEnabled(false);
	        WebConversation wc = new WebConversation();
			
			WebRequest request = new GetMethodWebRequest( url );
	        WebResponse response = wc.getResponse( request );
	        System.out.println("OK");
	        
		}catch(Exception e){
			System.out.println("ERRO");
			e.printStackTrace();
		}
		return false;
	}*/
}
