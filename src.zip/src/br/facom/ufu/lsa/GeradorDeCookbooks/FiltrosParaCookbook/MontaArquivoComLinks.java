/**Essa classe ira produzir um arquivo contendo os links presentes nos posts das categorias consideradas no estudo 
*/

package br.facom.ufu.lsa.GeradorDeCookbooks.FiltrosParaCookbook;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;

public class MontaArquivoComLinks {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try{
			
			String vetNomeApis[][] = {};
			List<String[]> listaApis = new ArrayList<String[]>();
			/*String api1[] = {"jquery", "asp.net"};
			listaApis.add(api1);
			String api2[] = {"swing"};
			listaApis.add(api2);
			String api3[] = {"swt"};
			listaApis.add(api3);
			String api4[] = {"stl"};
			listaApis.add(api4);
			String api5[] = {"qt4"};
			listaApis.add(api5);
			String api6[] = {"log4net", "c#"};
			listaApis.add(api6);
			String api7[] = {"awt"};
			listaApis.add(api7);
			String api8[] = {"boost"};
			listaApis.add(api8);
			String api9[] = {"matplotlib"};
			listaApis.add(api9);
			String api10[] = {"backbone.js"};
			listaApis.add(api10);*/
			
			//String api11[] = {"linq"};
			//listaApis.add(api11);
			
			String api12[] = {"linq"};
			listaApis.add(api12);
			String api13[] = {"qt"};
			listaApis.add(api13);
			String api14[] = {"swt"};
			listaApis.add(api14);
			
			Filtros f = new Filtros("");
			ConexaoDB cbd = new ConexaoDB();
			 //Conecta ao banco
			cbd.conectaAoBD();
			Set<String> setLinks = new HashSet<String>();
			for(int i=0; i< listaApis.size(); i++){
				String[] vetAPIs = listaApis.get(i);
				System.out.println(vetAPIs[0]);
				
				
				String query = ConsultasBD.consultaPostsEmCategorias(vetAPIs);
				//System.out.println(query);
				ResultSet rs = cbd.executaQuery(query);
				while(rs.next()){
					String body = rs.getString("body");
					List<String> listaDeUrls = f.encontraLinks(body);
					for(int j=0; j< listaDeUrls.size(); j++){
						setLinks.add(listaDeUrls.get(j));
					}
				}
				
			}
			
			//PrintWriter outLinks = new PrintWriter(new BufferedWriter(new FileWriter("/media/HDii-2x3Tb/Lucas/lucas2/drop box/Dropbox/Dados Dead Links/SO_links_10apis.txt", false)));
			//PrintWriter outLinks = new PrintWriter(new BufferedWriter(new FileWriter("/media/HDii-2x3Tb/Lucas/lucas2/drop box/Dropbox/Dados Dead Links/SO_links_linq.txt", false)));
			PrintWriter outLinks = new PrintWriter(new BufferedWriter(new FileWriter("/home/lucas/Dropbox/dados_dead_links/SO_links_linq_qt_swt.txt", false)));
			Iterator iter = setLinks.iterator();
			while (iter.hasNext()) {
				outLinks.println(iter.next());
			}
			
			outLinks.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
