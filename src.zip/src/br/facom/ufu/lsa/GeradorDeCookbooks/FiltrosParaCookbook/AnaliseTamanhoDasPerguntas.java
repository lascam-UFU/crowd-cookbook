package br.facom.ufu.lsa.GeradorDeCookbooks.FiltrosParaCookbook;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.htmlcleaner.HtmlCleaner;
import org.htmlcleaner.TagNode;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;
import br.ufu.facom.lsa.Lda.ManipuladorDeTexto;
import br.ufu.facom.lsa.TesteHowTo.ClassificadorHowTo;

public class AnaliseTamanhoDasPerguntas {
	public static void main(String[] args) {
		try{
			
			List<String[]> listaApis = new ArrayList<String[]>();
			String api1[] = {"swt"};
			listaApis.add(api1);
			String api2[] = {"stl"};
			listaApis.add(api2);
			String api3[] = {"linq"};
			listaApis.add(api3);
			String api4[] = {"qt"};
			listaApis.add(api4);
			String api5[] = {"swing"};
			listaApis.add(api5);
			String api6[] = {"boost"};
			listaApis.add(api6);
			String api7[] = {"awt"};
			listaApis.add(api7);
			String api8[] = {"log4net"};
			listaApis.add(api8);
			String api9[] = {"jquery"};
			listaApis.add(api9);
			String api10[] = {"backbone.js"};
			listaApis.add(api10);
						
			ClassificadorHowTo classificador = new ClassificadorHowTo();
			ManipuladorDeTexto mt = new ManipuladorDeTexto("", true);
			boolean consideraCondigoFonte = true;
			
			String nomeDaPasta = "";
			if(!consideraCondigoFonte)
				nomeDaPasta = "SemCodigoFonte";
			else
				nomeDaPasta = "ComCodigoFonte";
			PrintWriter outTodasApis = new PrintWriter(new BufferedWriter(new FileWriter("/home/lucas/Dropbox/Analise Tamanho Perguntas/" + nomeDaPasta + "/all_apis.txt", false)));
			outTodasApis.println("id,numeroDeCaracteres");
			outTodasApis.flush();
			
			ConexaoDB cbd = new ConexaoDB();
			 //Conecta ao banco
			cbd.conectaAoBD();
			for(int i=0; i< listaApis.size(); i++){
				String[] vetAPIs = listaApis.get(i);
				//System.out.println(vetAPIs[0]);
				List<String> listaTagsLib = new ArrayList<String>();
				String nomeApis = "";
				for(int j=0; j< vetAPIs.length; j++){
					listaTagsLib.add(vetAPIs[j]);
					nomeApis += vetAPIs[j];
					if(j!=vetAPIs.length-1)
						nomeApis += "_";
				}
								
				PrintWriter outApi = new PrintWriter(new BufferedWriter(new FileWriter("/home/lucas/Dropbox/Analise Tamanho Perguntas/" + nomeDaPasta + "/" + nomeApis + ".txt", false)));
				outApi.println("id,numeroDeCaracteres");
				outApi.flush();
		
				//String query = ConsultasBD.consultaPerguntasEmCategorias(listaTagsLib);
				
				String query = "SELECT p.id postid, title, body, owneruserid " +
				"FROM posts p " +
				"WHERE tags like '<%" + nomeApis + "%>' AND DATE(p.CreationDate) <= '2013-03-05'";
				
				//System.out.println(query);
				ResultSet rs = cbd.executaQuery(query);
				while(rs.next()){
					int id = rs.getInt("postid");
					String corpoPergunta = rs.getString("body");
					String titulo = rs.getString("title");
					
					if(!classificador.classficaComoHowTO(titulo, corpoPergunta)){
						continue;
					}
					
					int nroDeCaracteresEmPost = calculaNroDeCaracteresEmPost(corpoPergunta, mt, consideraCondigoFonte);
					outApi.println(id + "," + nroDeCaracteresEmPost);
					outApi.flush();
					
					outTodasApis.println(id + "," + nroDeCaracteresEmPost);
					outTodasApis.flush();
				}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private static  int calculaNroDeCaracteresEmPost(String corpoResposta,
			ManipuladorDeTexto mt, boolean consideraCodigoFonte) {
		try{
			//Primeiro vamos remover os codigos, uams vez que nao sera considerados no calculo de tamanho do post
			HtmlCleaner cleaner = new HtmlCleaner();
			TagNode root = cleaner.clean( corpoResposta );
			
			if(!consideraCodigoFonte){
				Object[] codeNodes = root.evaluateXPath( "//code" );
				for(int i=0; i<codeNodes.length; i++){
					((TagNode)codeNodes[i]).removeFromTree();
				}
			}
			String texto = "";
			texto += root.getText();
			
			return texto.length();
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
	
}
