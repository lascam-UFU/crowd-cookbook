package br.ufu.facom.lsal.ProduzDadosParaLimeSurvey;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class Main {

	public static void main(String[] args) {
		
		try{
			 String path = "/home/lucas/Dropbox/dados_lime_survey/dados_receitas"; 
			 String fileName;
			 File folder = new File(path);
			 File[] listOfFiles = folder.listFiles();
			 
			
			 String strOpcoes = "SQ	0	comment		Coment&aacuterio		pt																																																																																																																									\n" + 
			 "A	0	A1		2		pt																																																																																																																									\n" +
			 "A	0	A2		1		pt																																																																																																																									\n" +
			 "A	0	A3		0		pt																																																																																																																									\n" +
			 "A	0	A4		-1		pt																																																																																																																									\n" +
			 "A	0	A5		-2		pt	 ";
			 
			  for (int i = 0; i < listOfFiles.length; i++) 
			 //for (int i = 0; i < 1; i++)
			  {
				  
				 int idGrupoAtual = 1;
				 
				  fileName = listOfFiles[i].getName();
				  
				 // if(fileName.endsWith(".txt")){
				//	  System.out.println(fileName);
				 // }
				  
				  if(!fileName.equals("qt_fake.txt"))
					  continue;
				  System.out.println(fileName);
				  
				  BufferedReader br = null;
				  String sCurrentLine;
		 
				  br = new BufferedReader(new FileReader(listOfFiles[i].getAbsolutePath()));
		 
				  int lineCount = 0;
				  while ((sCurrentLine = br.readLine()) != null) {
					  String vetPartes[] = sCurrentLine.split("\t");
					  
					  String idDoCapitulo = vetPartes[0];
					  String idDaPergunta = vetPartes[1];
					  String idDaResposta = vetPartes[2];
					  String idNoCookbook = vetPartes[3];
					  String nomeAPI = vetPartes[4];
					  
					  String strGrupo = "G	G" + idGrupoAtual++ + "	Avalia&ccedil&atildeo de Crit&eacuterios para receita " + idNoCookbook + " do cookbook sobre " + nomeAPI +"	1	<p style=\"margin: 0px; padding: 0px; color: rgb(29, 45, 69); font-family: verdana; font-weight: bold; line-height: 15.600000381469727px;\">Coment&aacuterios/Observa&ccedil&atildees devem ser inclu&iacutedas no campo de Coment&aacuterio</p>  		pt																																																																																																																									";
					 
					  String idDaQuestaoC1 = "Q" + idDaPergunta + "s" + idDaResposta + "c1";
					  String c1Str = "Q	O	" + idDaQuestaoC1 + "	1	<p>Adequa&ccedil&atildeo para ser parte de um cookbook:</p>  		pt		Y	N		1																																																																																															1																					";
					  
					  String idDaQuestaoC2 = "Q" + idDaPergunta + "s" + idDaResposta + "c2";
					  String c2Str = "Q	O	" + idDaQuestaoC2 + "	1	<p>Auto-conten&ccedil&atildeo:</p>  		pt		Y	N		1																																																																																															1																					";
					  
					  String idDaQuestaoC3 = "Q" + idDaPergunta + "s" + idDaResposta + "c3";
					  String c3Str = "Q	O	" + idDaQuestaoC3 + "	1	<p>Reprodutibilidade dos c&oacutedigos-fontes:</p>  		pt		Y	N		1																																																																																															1																					";

					  String idDaQuestaoC4 = "Q" + idDaPergunta + "s" + idDaResposta + "c4";
					  String c4Str = "Q	O	" + idDaQuestaoC4 + "	1	<p>Relacionamento com o cap&iacutetulo:</p>  		pt		Y	N		1																																																																																															1																					";
					  
					  String textoFinal = strGrupo + "\n" + c1Str + "\n" + strOpcoes + "\n" + c2Str + "\n" + strOpcoes + "\n" + c3Str + "\n" + strOpcoes + "\n" + c4Str + "\n" + strOpcoes;
					  System.out.println(textoFinal);
				  }
					
				  
			  } 
				
		}catch(Exception e){
			e.printStackTrace();;
		}

	}

}
