package br.ufu.facom.lsal.AnalisaDadosDoSurvey;

import java.util.ArrayList;
import java.util.List;

import br.ufu.facom.lsa.Lda.ManipuladorDeTexto;
import it.gonzo.assessor.WordNetAssessor;
import it.gonzo.similarity.utils.SimilarityConstants;

public class CalculaSemanticSimilarity {
	static ManipuladorDeTexto mt = new ManipuladorDeTexto("", true);
//	public static void main(String args[]){
//
//		String frase1 = "jar files and plugins.";
//		String frase2 = "Compiling a plugin for Eclipse.";
//
//		System.out.println(calculaSimilarity(frase1, frase2));
//	}
	
	public static double calculaSimilarity(String frase1, String frase2){
		
		String substantivosStemmizadosFrase1 = mt.obtemTermosComRemocaoDeStopWords(frase1, true);
		String vetFrase1[] = substantivosStemmizadosFrase1.split("\n");

		String substantivosStemmizadosFrase2 = mt.obtemTermosComRemocaoDeStopWords(frase2, true);
		String vetFrase2[] = substantivosStemmizadosFrase2.split("\n");

		double similarity = 0;
		for(int i=0; i< vetFrase1.length; i++){
			String termoFrase1 = vetFrase1[i];
			for(int j=0; j< vetFrase2.length; j++){
				String termoFrase2 = vetFrase2[j];

				if(termoFrase1.equals(termoFrase2)){
					similarity = 1;
					return similarity;
				}
			}
		}

		String substantivosOriginaisFrase1 = mt.obtemTermosComRemocaoDeStopWords(frase1, false);
		vetFrase1 = substantivosOriginaisFrase1.split("\n");
		for(int i=0; i< vetFrase1.length; i++){
			vetFrase1[i] = mt.lemmatize(vetFrase1[i].toLowerCase());
		}
		
		String substantivosOriginaisFrase2 = mt.obtemTermosComRemocaoDeStopWords(frase2, false);
		vetFrase2 = substantivosOriginaisFrase2.split("\n");
		for(int i=0; i< vetFrase2.length; i++){
			vetFrase2[i] = mt.lemmatize(vetFrase2[i].toLowerCase());
		}

		similarity = 0;
		for(int i=0; i< vetFrase1.length; i++){
			String termoFrase1 = vetFrase1[i];
			if(termoFrase1.equals("plugin")){
				termoFrase1 = "plug-in";
			}
			
			for(int j=0; j< vetFrase2.length; j++){
				String termoFrase2 = vetFrase2[j];
				
				if(termoFrase2.equals("plugin")){
					termoFrase2 = "plug-in";
				}

				double similarityAtual = calculaSemanticLibrarySimilarity(termoFrase1, termoFrase2);
				System.out.println("sim("+termoFrase1+","+termoFrase2+") = " + similarityAtual);
				if(similarityAtual > similarity)
					similarity = similarityAtual;
			}
		}
		return similarity;
	}

	private static double calculaSemanticLibrarySimilarity(String termoFrase1,
			String termoFrase2) {
		WordNetAssessor wn = new WordNetAssessor();
		
		//**************noun
		
		double sim = wn.getWordNetNounSimilarityByIC(termoFrase1, termoFrase2,
						SimilarityConstants.LIN_MEASURE,
						SimilarityConstants.INTRINSIC_IC);
		
		if(sim > 0)
			return sim;
		
		//**************verb
		
		sim = wn.getWordNetVerbSimilarityByIC(termoFrase1, termoFrase2,
				SimilarityConstants.LIN_MEASURE,
				SimilarityConstants.INTRINSIC_IC);
		
		if(sim > 0)
			return sim;
		
		//**************adjective
		
		sim = wn.getWordNetAdjectiveSimilarityByIC(termoFrase1, termoFrase2,
				SimilarityConstants.LIN_MEASURE,
				SimilarityConstants.INTRINSIC_IC);
		
		if(sim > 0)
			return sim;
		
		//**************adverb
		
		sim = wn.getWordNetAdverbSimilarityByIC(termoFrase1, termoFrase2,
				SimilarityConstants.LIN_MEASURE,
				SimilarityConstants.INTRINSIC_IC);
		
		return sim;
	}
}
