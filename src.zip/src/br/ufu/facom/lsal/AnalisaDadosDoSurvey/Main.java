package br.ufu.facom.lsal.AnalisaDadosDoSurvey;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;

public class Main {
	public static void main(String[] args) {

		/************SWT FAKE********************/
		//int surveyId =  676822;

		//Johnatas
		//int tokenId = 125411
		
		
		//int tokenId = 458541;


		/************LINQ FAKE********************/
		//int surveyId = 115573;

		//Eduardo Cunha
		//int tokenId = 999897;
		//
		//int tokenId = 528139;


		/************QT FAKE********************/
		int surveyId =  176949;

		
		//int tokenId = 398573;
		
		int tokenId = 528139;

		//-Calcular ICC de tudo (todas notas numericas considerando as fake)
		//extraiNotasDasPerguntasFake(115573, 412276);


		List<Integer> listSurveyId = new ArrayList<Integer>();
		listSurveyId.add(176949);
		listSurveyId.add(115573);
		listSurveyId.add(676822);

		List<Integer> listTokenId = new ArrayList<Integer>();
		listTokenId.add(957121);
		listTokenId.add(999897);
		listTokenId.add(125411);

		//extraiTitulosComuns(listSurveyId, listTokenId, false);
	
		extraiTitulosDeQuestao("QQT14b", listSurveyId);
		//QSWT4
		//extraiNotasNumericasPorCriterio(176949, 447785,false);
		
		//extraiNotasNumericasPorCriterio(176949, 528139, false);
		
		//extraiNotasNumericasComunsPorCriterio(676822, 894123);
		
		//extraiNotasNumericasPorCriterio(676822, 894123, false);
		
		//extraiNotasNumericasPorCriterio(176949, 172341, false);
		
		 //extraiNotasNumericasComunsPorCriterio(676822, 117756);
		
		//extraiNotasNumericasPorCriterio(115573, 412276, false);
		
		//extraiNotasDasPerguntasFake(676822, 117756);

	}

	private static void extraiTitulosDeQuestao(String questionId, List<Integer> listSurveyId) {
		try {
			System.out.println(questionId);
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD("limeSurveyDB");
			
			List<Capitulo> listaCapitulos = new ArrayList<Capitulo>();

			for(int j=0; j< listSurveyId.size(); j++){
				int surveyId = listSurveyId.get(j);
				
				String query = "select * from survey_" + surveyId
						+ " where submitdate IS NOT NULL";
				// Executa a query
				ResultSet rs = cbd.executaQuery(query);

				while (rs.next()) {
					String tokenId = rs.getString("token");
					
					String queryinterna = "select consider_semantic_chap from tokens_" + surveyId
							+ " where token = '" + tokenId + "'";
					ResultSet rsInterno = cbd.executaQuery(queryinterna);
					rsInterno.next();
					boolean consideraChapterSemantic = rsInterno.getBoolean("consider_semantic_chap");
					if(!consideraChapterSemantic){
						int a =0;
						int b =a;
						continue;
					}
					
					ResultSetMetaData meta = rs.getMetaData();
					int numeroDeColunas = meta.getColumnCount();

					String codigoRealDaPerguntaAnterior = "";

					boolean isFakeDaPerguntaAnterior = false;
					boolean isCommonDaPerguntaAnterior = false;


					for (int i = 0; i < numeroDeColunas; i++) {
						String nomeDaColuna = meta.getColumnName(i + 1);
						// System.out.println(nomeDaColuna);

						if (i >= 9) {
							String idDaPergunta = nomeDaColuna.split("X")[2];
							String codigoRealDaPergunta = "";
							boolean isFake = false;
							boolean isCommon = false;


							if (!idDaPergunta.contains("comment")) {
								codigoRealDaPergunta = descobreIdRealDaPergunta(
										idDaPergunta, cbd);
								isFake = verificaSeEhFake(idDaPergunta, cbd);
								isCommon = verificaSeEhCommon(idDaPergunta, cbd);
							} else {
								codigoRealDaPergunta = codigoRealDaPerguntaAnterior
										+ "comment";
								isFake = isFakeDaPerguntaAnterior;
								isCommon = isCommonDaPerguntaAnterior;
							}
							codigoRealDaPerguntaAnterior = codigoRealDaPergunta;
							isFakeDaPerguntaAnterior = isFake;
							isCommonDaPerguntaAnterior = isCommon;

							if (codigoRealDaPergunta.equals(questionId)){
							//if (codigoRealDaPergunta.endsWith("b")){
								// mapNomeDaColunaId.put(nomeDaColuna,
								// codigoRealDaPergunta);
								String valor = rs.getString(nomeDaColuna);
								if(valor == null)
									continue;
								
								System.out.println(tokenId + "\t" + valor);
								Capitulo c = new Capitulo(codigoRealDaPergunta, valor, tokenId);
								listaCapitulos.add(c);
								//if((!consideraFake && !isFake) || consideraFake)
									//System.out.println(idDaPergunta + "\t"
									//		+ codigoRealDaPergunta + "\t" + valor);
							}
						}
					}
				}
			}
			
			/*for(int i=0; i< listaCapitulos.size(); i++){
				String tit1 = listaCapitulos.get(i).getTitulo();
				String token1 = listaCapitulos.get(i).getTokenId();
				for(int j=i+1; j< listaCapitulos.size(); j++){
					String tit2 = listaCapitulos.get(j).getTitulo();
					String token2 = listaCapitulos.get(j).getTokenId();
					double sim = CalculaSemanticSimilarity.calculaSimilarity(tit1, tit2);
					System.out.println("###################" + token1 + "-" + token2 + "\t" + sim);
				}
				
			}*/
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}


	/*private static void extraiTitulosComuns(List<Integer> listSurveyId, List<Integer> listTokenId, boolean consideraFake) {
		try {

			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD("limeSurveyDB");

			Map<String, Integer> mapTituloCount = new HashMap<String, Integer>();
			List<List<Capitulo>> listDeDaDosDoUsuario = new ArrayList<List<Capitulo>>();

			for(int j=0; j< listSurveyId.size(); j++){
				int surveyId = listSurveyId.get(j);
				int tokenId = listTokenId.get(j);

				List<Capitulo> listaCapituloUsuario = new ArrayList<Capitulo>();
				listDeDaDosDoUsuario.add(listaCapituloUsuario);

				String query = "select * from survey_" + surveyId
						+ " where token = '" + tokenId + "' and submitdate IS NOT NULL";
				// Executa a query
				ResultSet rs = cbd.executaQuery(query);

				while (rs.next()) {
					ResultSetMetaData meta = rs.getMetaData();
					int numeroDeColunas = meta.getColumnCount();

					String codigoRealDaPerguntaAnterior = "";

					boolean isFakeDaPerguntaAnterior = false;
					boolean isCommonDaPerguntaAnterior = false;


					for (int i = 0; i < numeroDeColunas; i++) {
						String nomeDaColuna = meta.getColumnName(i + 1);
						// System.out.println(nomeDaColuna);

						if (i >= 9) {
							String idDaPergunta = nomeDaColuna.split("X")[2];
							String codigoRealDaPergunta = "";
							boolean isFake = false;
							boolean isCommon = false;


							if (!idDaPergunta.contains("comment")) {
								codigoRealDaPergunta = descobreIdRealDaPergunta(
										idDaPergunta, cbd);
								isFake = verificaSeEhFake(idDaPergunta, cbd);
								isCommon = verificaSeEhCommon(idDaPergunta, cbd);
							} else {
								codigoRealDaPergunta = codigoRealDaPerguntaAnterior
										+ "comment";
								isFake = isFakeDaPerguntaAnterior;
								isCommon = isCommonDaPerguntaAnterior;
							}
							codigoRealDaPerguntaAnterior = codigoRealDaPergunta;
							isFakeDaPerguntaAnterior = isFake;
							isCommonDaPerguntaAnterior = isCommon;


							if (codigoRealDaPergunta.endsWith("b")){
								// mapNomeDaColunaId.put(nomeDaColuna,
								// codigoRealDaPergunta);
								String valor = rs.getString(nomeDaColuna);
								if(valor == null)
									continue;

								Capitulo c = new Capitulo(codigoRealDaPergunta, valor);
								listaCapituloUsuario.add(c);

								if(mapTituloCount.containsKey(codigoRealDaPergunta)){
									mapTituloCount.put(codigoRealDaPergunta, mapTituloCount.get(codigoRealDaPergunta)+1);
								}else{
									mapTituloCount.put(codigoRealDaPergunta, 1);
								}


								if(codigoRealDaPergunta.equals("QLINQ1b")){
									int a =0;
									int b =a;
								}

								//if((!consideraFake && !isFake) || consideraFake)
								//	System.out.println(idDaPergunta + "\t"
								//			+ codigoRealDaPergunta + "\t" + valor);
							}
						}
					}


				}

			}

			int nroDeTokens = listTokenId.size();

			Iterator entries = mapTituloCount.entrySet().iterator();
			while (entries.hasNext()) {
				Entry thisEntry = (Entry) entries.next();
				String idCap = (String)thisEntry.getKey();
				Integer countCap = (Integer)thisEntry.getValue();

				if(countCap < nroDeTokens){

					for(int i=0; i< listDeDaDosDoUsuario.size(); i++){
						List<Capitulo> listUsuarioAtual = listDeDaDosDoUsuario.get(i);

						for(int j=0; j< listUsuarioAtual.size(); j++){
							Capitulo c = listUsuarioAtual.get(j);
							if(c.getId().equals(idCap)){
								listUsuarioAtual.remove(j);
								j--;
							}

						}
					}
				}
			}

			for(int i=0; i< listDeDaDosDoUsuario.size(); i++){
				List<Capitulo> listUsuarioAtual = listDeDaDosDoUsuario.get(i);
				System.out.println(listTokenId.get(i));
				for(int j=0; j< listUsuarioAtual.size(); j++){
					Capitulo c = listUsuarioAtual.get(j);
					System.out.println(c.getId() + "\t" + c.getTitulo());
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}	*/

	// metodo que vai extrair todas as notas numericas (pode opcionalmente, considerar ou nao as fakes)
	/*private static void extraiTodasNotasNumericas(int surveyId, int tokenId, boolean consideraFake) {
		try {
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD("limeSurveyDB");

			String query = "select * from survey_" + surveyId
					+ " where token = '" + tokenId + "'";
			// Executa a query
			ResultSet rs = cbd.executaQuery(query);

			// <nomeDaColunaNoBD, idDaPerguntaNoQuestionario (ex.: )
			// Map<String, String> mapNomeDaColunaId = new HashMap<String,
			// String>();
			// Map<String, String> mapIdDaPerguntaValor = new HashMap<String,
			// String>();

			while (rs.next()) {
				ResultSetMetaData meta = rs.getMetaData();
				int numeroDeColunas = meta.getColumnCount();

				String codigoRealDaPerguntaAnterior = "";

				boolean isFakeDaPerguntaAnterior = false;
				boolean isCommonDaPerguntaAnterior = false;


				for (int i = 0; i < numeroDeColunas; i++) {
					String nomeDaColuna = meta.getColumnName(i + 1);
					// System.out.println(nomeDaColuna);

					// Ate a nona, trata-se de colunas com dados do participante
					if (i >= 9) {
						String idDaPergunta = nomeDaColuna.split("X")[2];
						String codigoRealDaPergunta = "";
						boolean isFake = false;
						boolean isCommon = false;

						if (!idDaPergunta.contains("comment")) {
							codigoRealDaPergunta = descobreIdRealDaPergunta(idDaPergunta, cbd);
							isFake = verificaSeEhFake(idDaPergunta, cbd);
							isCommon = verificaSeEhCommon(idDaPergunta, cbd);
						} else {
							codigoRealDaPergunta = codigoRealDaPerguntaAnterior + "comment";
							isFake = isFakeDaPerguntaAnterior;
							isCommon = isCommonDaPerguntaAnterior;
						}
						codigoRealDaPerguntaAnterior = codigoRealDaPergunta;
						isFakeDaPerguntaAnterior = isFake;
						isCommonDaPerguntaAnterior = isCommon;

						// No caso de ser comentario ou as perguntas que
						// solicitam o titulo dos capitulos, pula, pois elas nao
						// sao numericas
						if (codigoRealDaPergunta.contains("comment") || codigoRealDaPergunta.endsWith("b"))
							continue;

						// mapNomeDaColunaId.put(nomeDaColuna,
						// codigoRealDaPergunta);
						String valor = rs.getString(nomeDaColuna);

						// Tem esse if, para quando chegar na parte final do
						// questionario (perguntas dicursivas), sair.
						if (!valor.equals("A1") && !valor.equals("A2")
								&& !valor.equals("A3") && !valor.equals("A4")
								&& !valor.equals("A5")) {
							break;
						}

						// Descobre o valor real da nota dada (ex. A1 -> 2)
						query = "select answer from answers where qid = "
								+ idDaPergunta + " and code = '" + valor + "'";
						ResultSet rsInt = cbd.executaQuery(query);
						rsInt.next();
						// System.out.println(query);
						String realId = rsInt.getString("answer");


						if((!consideraFake && !isFake) || consideraFake)
							System.out.println(idDaPergunta + "\t"
									+ codigoRealDaPergunta + "\t" + realId);

					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/

	//metodo que vai extrair notas numericas, separadas por criterio (pode opcionalmente, considerar ou nao as fakes)
	private static void extraiNotasNumericasPorCriterio(int surveyId, int tokenId, boolean consideraFake) {
		try {
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD("limeSurveyDB");

			String query = "select * from survey_" + surveyId
					+ " where token = '" + tokenId + "' and submitdate IS NOT NULL";
			// Executa a query
			ResultSet rs = cbd.executaQuery(query);
			
			String queryinterna = "select consider_c1, consider_c2, consider_c3, consider_c4, consider_semantic_chap from tokens_" + surveyId
					+ " where token = '" + tokenId + "'";
			ResultSet rsInterno = cbd.executaQuery(queryinterna);
			rsInterno.next();
			boolean consideraC1 = rsInterno.getBoolean("consider_c1");
			boolean consideraC2 = rsInterno.getBoolean("consider_c2");
			boolean consideraC3 = rsInterno.getBoolean("consider_c3");
			boolean consideraC4 = rsInterno.getBoolean("consider_c4");
			boolean consideraChapterSemantic = rsInterno.getBoolean("consider_semantic_chap");
			
			//boolean consideraC1 = true;
			//boolean consideraC2 = true;
			//boolean consideraC3 = true;
			//boolean consideraC4 = true;
			//boolean consideraChapterSemantic = true;
		
			// Map<String, String> mapNomeDaColunaId = new HashMap<String,
			// String>();
			// Map<String, String> mapIdDaPerguntaValor = new HashMap<String,
			// String>();

			String strChapterSemantic = "";
			String strC1 = "";
			String strC2 = "";
			String strC3 = "";
			String strC4 = "";

			while (rs.next()) {
				ResultSetMetaData meta = rs.getMetaData();
				int numeroDeColunas = meta.getColumnCount();

				String codigoRealDaPerguntaAnterior = "";

				boolean isFakeDaPerguntaAnterior = false;
				boolean isCommonDaPerguntaAnterior = false;


				for (int i = 0; i < numeroDeColunas; i++) {
					String nomeDaColuna = meta.getColumnName(i + 1);
					// System.out.println(nomeDaColuna);

					if (i >= 9) {
						String idDaPergunta = nomeDaColuna.split("X")[2];
						String codigoRealDaPergunta = "";
						boolean isFake = false;
						boolean isCommon = false;


						if (!idDaPergunta.contains("comment")) {
							codigoRealDaPergunta = descobreIdRealDaPergunta(
									idDaPergunta, cbd);
							isFake = verificaSeEhFake(idDaPergunta, cbd);
							isCommon = verificaSeEhCommon(idDaPergunta, cbd);
						} else {
							codigoRealDaPergunta = codigoRealDaPerguntaAnterior
									+ "comment";
							isFake = isFakeDaPerguntaAnterior;
							isCommon = isCommonDaPerguntaAnterior;
						}
						codigoRealDaPerguntaAnterior = codigoRealDaPergunta;
						isFakeDaPerguntaAnterior = isFake;
						isCommonDaPerguntaAnterior = isCommon;


						if (codigoRealDaPergunta.contains("comment")
								|| codigoRealDaPergunta.endsWith("b"))
							continue;

						// mapNomeDaColunaId.put(nomeDaColuna,
						// codigoRealDaPergunta);
						String valor = rs.getString(nomeDaColuna);

						// esse if eh para desconsiderar (pular) as respostas
						// discursivas
						if (!valor.equals("A1") && !valor.equals("A2")
								&& !valor.equals("A3") && !valor.equals("A4")
								&& !valor.equals("A5")) {
							System.out.println(valor);
							break;
						} else {
							int a = 0;
							int b = a;
						}

						if(!consideraFake && isFake)
							continue;

						query = "select answer from answers where qid = "
								+ idDaPergunta + " and code = '" + valor + "'";
						ResultSet rsInt = cbd.executaQuery(query);
						rsInt.next();
						// System.out.println(query);
						String realId = rsInt.getString("answer");

						if (codigoRealDaPergunta.contains("c1") && consideraC1)
							strC1 += idDaPergunta + "\t" + codigoRealDaPergunta
							+ "\t" + realId + "\n";
						else if (codigoRealDaPergunta.contains("c2")  && consideraC2)
							strC2 += idDaPergunta + "\t" + codigoRealDaPergunta
							+ "\t" + realId + "\n";
						else if (codigoRealDaPergunta.contains("c3") && consideraC3)
							strC3 += idDaPergunta + "\t" + codigoRealDaPergunta
							+ "\t" + realId + "\n";
						else if (codigoRealDaPergunta.contains("c4") && consideraC4)
							strC4 += idDaPergunta + "\t" + codigoRealDaPergunta
							+ "\t" + realId + "\n";
						else if(!codigoRealDaPergunta.contains("c1") && !codigoRealDaPergunta.contains("c2") && !codigoRealDaPergunta.contains("c3") && !codigoRealDaPergunta.contains("c4") && consideraChapterSemantic)
							strChapterSemantic += idDaPergunta + "\t"
									+ codigoRealDaPergunta + "\t" + realId
									+ "\n";

						// mapIdDaPerguntaValor.put(codigoRealDaPergunta,
						// realId);
						// System.out.println(idDaPergunta + "\t" +
						// codigoRealDaPergunta + "\t" + realId);

					}
				}

				System.out
				.println("**************strChapterSemantic*******************");
				System.out.println(strChapterSemantic);
				System.out.println("**************strC1*******************");
				System.out.println(strC1);
				System.out.println("**************strC2*******************");
				System.out.println(strC2);
				System.out.println("**************strC3*******************");
				System.out.println(strC3);
				System.out.println("**************strC4*******************");
				System.out.println(strC4);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*//metodo que vai extrair notas numericas, separadas por API (pode opcionalmente, considerar ou nao as fakes)
	private static void extraiNotasNumericasPorAPI(int surveyId, int tokenId, boolean consideraFake) {
		try {
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD("limeSurveyDB");

			ConexaoDB cbdSO = new ConexaoDB();
			cbdSO.conectaAoBD("stackof");

			String query = "select * from survey_" + surveyId
					+ " where token = '" + tokenId + "'";
			// Executa a query
			ResultSet rs = cbd.executaQuery(query);

			// Map<String, String> mapNomeDaColunaId = new HashMap<String,
			// String>();
			// Map<String, String> mapIdDaPerguntaValor = new HashMap<String,
			// String>();

			String strSwt = "";
			String strLinq = "";
			String strQt = "";

			while (rs.next()) {
				ResultSetMetaData meta = rs.getMetaData();
				int numeroDeColunas = meta.getColumnCount();

				String codigoRealDaPerguntaAnterior = "";
				boolean isFakeDaPerguntaAnterior = false;
				boolean isCommonDaPerguntaAnterior = false;

				for (int i = 0; i < numeroDeColunas; i++) {
					String nomeDaColuna = meta.getColumnName(i + 1);
					// System.out.println(nomeDaColuna);

					if (i >= 9) {
						String idDaPergunta = nomeDaColuna.split("X")[2];
						String codigoRealDaPergunta = "";
						boolean isFake = false;
						boolean isCommon = false;


						if (!idDaPergunta.contains("comment")) {
							codigoRealDaPergunta = descobreIdRealDaPergunta(
									idDaPergunta, cbd);
							isFake = verificaSeEhFake(idDaPergunta, cbd);
							isCommon = verificaSeEhCommon(idDaPergunta, cbd);
						} else {
							codigoRealDaPergunta = codigoRealDaPerguntaAnterior
									+ "comment";
							isFake = isFakeDaPerguntaAnterior;
							isCommon = isCommonDaPerguntaAnterior;
						}
						codigoRealDaPerguntaAnterior = codigoRealDaPergunta;
						isFakeDaPerguntaAnterior = isFake;
						isCommonDaPerguntaAnterior = isCommon;

						if (codigoRealDaPergunta.contains("comment")
								|| codigoRealDaPergunta.endsWith("b"))
							continue;

						if(!consideraFake && isFake)
							continue;

						// mapNomeDaColunaId.put(nomeDaColuna,
						// codigoRealDaPergunta);
						String valor = rs.getString(nomeDaColuna);

						if (!valor.equals("A1") && !valor.equals("A2")
								&& !valor.equals("A3") && !valor.equals("A4")
								&& !valor.equals("A5")) {
							break;
						}

						query = "select answer from answers where qid = "
								+ idDaPergunta + " and code = '" + valor + "'";
						ResultSet rsInt = cbd.executaQuery(query);
						rsInt.next();
						// System.out.println(query);
						String realId = rsInt.getString("answer");

						String apiAtual = "";
						if (codigoRealDaPergunta.contains("c1")
								|| codigoRealDaPergunta.contains("c2")
								|| codigoRealDaPergunta.contains("c3")
								|| codigoRealDaPergunta.contains("c4")) {
							String idDaPerguntaNoSO = codigoRealDaPergunta
									.split("Q")[1].split("s")[0];
							// String idDaRespostaNoSO =
							// codigoRealDaPergunta.split("Q")[1].split("s")[1].split("c")[0];

							query = "select tags from posts where id = "
									+ idDaPerguntaNoSO;
							// System.out.println(query);
							// Executa a query
							ResultSet rsInterno = cbdSO.executaQuery(query);
							rsInterno.next();
							String tags = rsInterno.getString("tags");

							int count = 0;
							if (tags.contains("<swt>")) {
								apiAtual = "SWT";
								count++;
							}
							if (tags.contains("<linq>")) {
								apiAtual = "LINQ";
								count++;
							}
							if (tags.contains("<qt>")) {
								apiAtual = "QT";
								count++;
							}
							if (count > 1) {
								System.out.println("########DANGER#######");
							}
						} else {
							if (codigoRealDaPergunta.contains("SWT"))
								apiAtual = "SWT";
							if (codigoRealDaPergunta.contains("LINQ"))
								apiAtual = "LINQ";
							if (codigoRealDaPergunta.contains("QT"))
								apiAtual = "QT";
						}

						if (apiAtual.equals("SWT"))
							strSwt += idDaPergunta + "\t"
									+ codigoRealDaPergunta + "\t" + realId
									+ "\n";
						else if (apiAtual.equals("LINQ"))
							strLinq += idDaPergunta + "\t"
									+ codigoRealDaPergunta + "\t" + realId
									+ "\n";
						else if (apiAtual.equals("QT"))
							strQt += idDaPergunta + "\t" + codigoRealDaPergunta
							+ "\t" + realId + "\n";

						// mapIdDaPerguntaValor.put(codigoRealDaPergunta,
						// realId);
						// System.out.println(idDaPergunta + "\t" +
						// codigoRealDaPergunta + "\t" + realId);

					}
				}

				System.out.println("**************SWT*******************");
				System.out.println(strSwt);
				System.out.println("**************LINQ*******************");
				System.out.println(strLinq);
				System.out.println("**************strQt*******************");
				System.out.println(strQt);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/

	/*//metodo que vai extrair notas numericas, separadas por criterio (pode opcionalmente, considerar ou nao as fakes)
	private static void extraiNotasNumericasPorAPIePorCriterio(int surveyId, int tokenId, boolean consideraFake) {
		try {
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD("limeSurveyDB");

			ConexaoDB cbdSO = new ConexaoDB();
			cbdSO.conectaAoBD("stackof");

			String query = "select * from survey_" + surveyId
					+ " where token = '" + tokenId + "' and submitdate IS NOT NULL";
			// Executa a query
			ResultSet rs = cbd.executaQuery(query);

			// Map<String, String> mapNomeDaColunaId = new HashMap<String,
			// String>();
			// Map<String, String> mapIdDaPerguntaValor = new HashMap<String,
			// String>();

			String strSwtChapterSemantic = "";
			String strSwtC1 = "";
			String strSwtC2 = "";
			String strSwtC3 = "";
			String strSwtC4 = "";

			String strLinqChapterSemantic = "";
			String strLinqC1 = "";
			String strLinqC2 = "";
			String strLinqC3 = "";
			String strLinqC4 = "";

			String strQtChapterSemantic = "";
			String strQtC1 = "";
			String strQtC2 = "";
			String strQtC3 = "";
			String strQtC4 = "";


			while (rs.next()) {
				ResultSetMetaData meta = rs.getMetaData();
				int numeroDeColunas = meta.getColumnCount();

				String codigoRealDaPerguntaAnterior = "";

				boolean isFakeDaPerguntaAnterior = false;
				boolean isCommonDaPerguntaAnterior = false;


				for (int i = 0; i < numeroDeColunas; i++) {
					String nomeDaColuna = meta.getColumnName(i + 1);
					// System.out.println(nomeDaColuna);

					if (i >= 9) {
						String idDaPergunta = nomeDaColuna.split("X")[2];
						String codigoRealDaPergunta = "";
						boolean isFake = false;
						boolean isCommon = false;


						if (!idDaPergunta.contains("comment")) {
							codigoRealDaPergunta = descobreIdRealDaPergunta(
									idDaPergunta, cbd);
							isFake = verificaSeEhFake(idDaPergunta, cbd);
							isCommon = verificaSeEhCommon(idDaPergunta, cbd);
						} else {
							codigoRealDaPergunta = codigoRealDaPerguntaAnterior
									+ "comment";
							isFake = isFakeDaPerguntaAnterior;
							isCommon = isCommonDaPerguntaAnterior;
						}
						codigoRealDaPerguntaAnterior = codigoRealDaPergunta;
						isFakeDaPerguntaAnterior = isFake;
						isCommonDaPerguntaAnterior = isCommon;


						if (codigoRealDaPergunta.contains("comment")
								|| codigoRealDaPergunta.endsWith("b"))
							continue;

						// mapNomeDaColunaId.put(nomeDaColuna,
						// codigoRealDaPergunta);
						String valor = rs.getString(nomeDaColuna);

						// esse if eh para desconsiderar (pular) as respostas
						// discursivas
						if (!valor.equals("A1") && !valor.equals("A2")
								&& !valor.equals("A3") && !valor.equals("A4")
								&& !valor.equals("A5")) {
							System.out.println(valor);
							break;
						} else {
							int a = 0;
							int b = a;
						}

						if(!consideraFake && isFake)
							continue;

						query = "select answer from answers where qid = "
								+ idDaPergunta + " and code = '" + valor + "'";
						ResultSet rsInt = cbd.executaQuery(query);
						rsInt.next();
						// System.out.println(query);
						String realId = rsInt.getString("answer");

						String apiAtual = "";
						if (codigoRealDaPergunta.contains("c1")
								|| codigoRealDaPergunta.contains("c2")
								|| codigoRealDaPergunta.contains("c3")
								|| codigoRealDaPergunta.contains("c4")) {
							String idDaPerguntaNoSO = codigoRealDaPergunta
									.split("Q")[1].split("s")[0];
							// String idDaRespostaNoSO =
							// codigoRealDaPergunta.split("Q")[1].split("s")[1].split("c")[0];

							query = "select tags from posts where id = "
									+ idDaPerguntaNoSO;
							// System.out.println(query);
							// Executa a query
							ResultSet rsInterno = cbdSO.executaQuery(query);
							rsInterno.next();
							String tags = rsInterno.getString("tags");

							int count = 0;
							if (tags.contains("<swt>")) {
								apiAtual = "SWT";
								count++;
							}
							if (tags.contains("<linq>")) {
								apiAtual = "LINQ";
								count++;
							}
							if (tags.contains("<qt>")) {
								apiAtual = "QT";
								count++;
							}
							if (count > 1) {
								System.out.println("########DANGER#######");
							}
						} else {
							if (codigoRealDaPergunta.contains("SWT"))
								apiAtual = "SWT";
							if (codigoRealDaPergunta.contains("LINQ"))
								apiAtual = "LINQ";
							if (codigoRealDaPergunta.contains("QT"))
								apiAtual = "QT";
						}

						if (apiAtual.equals("SWT")){
							if (codigoRealDaPergunta.contains("c1"))
								strSwtC1 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c2"))
								strSwtC2 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c3"))
								strSwtC3 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c4"))
								strSwtC4 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else
								strSwtChapterSemantic += idDaPergunta + "\t"
										+ codigoRealDaPergunta + "\t" + realId
										+ "\n";
						}else if (apiAtual.equals("LINQ")){
							if (codigoRealDaPergunta.contains("c1"))
								strLinqC1 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c2"))
								strLinqC2 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c3"))
								strLinqC3 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c4"))
								strLinqC4 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else
								strLinqChapterSemantic += idDaPergunta + "\t"
										+ codigoRealDaPergunta + "\t" + realId
										+ "\n";
						}else if (apiAtual.equals("QT")){
							if (codigoRealDaPergunta.contains("c1"))
								strQtC1 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c2"))
								strQtC2 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c3"))
								strQtC3 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c4"))
								strQtC4 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else
								strQtChapterSemantic += idDaPergunta + "\t"
										+ codigoRealDaPergunta + "\t" + realId
										+ "\n";
						}
					}
				}

				System.out.println("##############Swt###############");
				System.out.println("**************strSwtChapterSemantic*******************");
				System.out.println(strSwtChapterSemantic);
				System.out.println("**************strSwtC1*******************");
				System.out.println(strSwtC1);
				System.out.println("**************strSwtC2*******************");
				System.out.println(strSwtC2);
				System.out.println("**************strSwtC3*******************");
				System.out.println(strSwtC3);
				System.out.println("**************strSwtC4*******************");
				System.out.println(strSwtC4);

				System.out.println("##############Linq###############");
				System.out.println("**************strLinqChapterSemantic*******************");
				System.out.println(strLinqChapterSemantic);
				System.out.println("**************strLinqC1*******************");
				System.out.println(strLinqC1);
				System.out.println("**************strLinqC2*******************");
				System.out.println(strLinqC2);
				System.out.println("**************strLinqC3*******************");
				System.out.println(strLinqC3);
				System.out.println("**************strLinqC4*******************");
				System.out.println(strLinqC4);

				System.out.println("##############Qt###############");
				System.out.println("**************strQtChapterSemantic*******************");
				System.out.println(strQtChapterSemantic);
				System.out.println("**************strQtC1*******************");
				System.out.println(strQtC1);
				System.out.println("**************strQtC2*******************");
				System.out.println(strQtC2);
				System.out.println("**************strQtC3*******************");
				System.out.println(strQtC3);
				System.out.println("**************strQtC4*******************");
				System.out.println(strQtC4);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/

	/*// metodo para extrair as notas numericas que sao comuns aos tres tipos de
	// questionarios
	private static void extraiNotasNumericasComuns(int surveyId, int tokenId) {
		try{
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD("limeSurveyDB");

			ConexaoDB cbdSO = new ConexaoDB();
			cbdSO.conectaAoBD("stackof");

			String query = "select * from survey_" + surveyId + " where token = '" + tokenId + "' and submitdate IS NOT NULL";
			//Executa a query
			ResultSet rs = cbd.executaQuery(query);

			//Map<String, String> mapNomeDaColunaId = new HashMap<String, String>();
			//Map<String, String> mapIdDaPerguntaValor = new HashMap<String, String>();

			while(rs.next()){
				ResultSetMetaData meta = rs.getMetaData();
				int numeroDeColunas = meta.getColumnCount();

				String codigoRealDaPerguntaAnterior = "";
				boolean isFakeDaPerguntaAnterior = false;
				boolean isCommonDaPerguntaAnterior = false;

				for(int i=0; i< numeroDeColunas; i++){
					String nomeDaColuna = meta.getColumnName(i+1);
					//System.out.println(nomeDaColuna);

					if(i >= 9){
						String idDaPergunta = nomeDaColuna.split("X")[2];
						String codigoRealDaPergunta = "";
						boolean isFake = false;
						boolean isCommon = false;

						if(!idDaPergunta.contains("comment")){
							codigoRealDaPergunta = descobreIdRealDaPergunta(idDaPergunta, cbd);
							isFake = verificaSeEhFake(idDaPergunta, cbd);
							isCommon = verificaSeEhCommon(idDaPergunta, cbd);
						}else{
							codigoRealDaPergunta = codigoRealDaPerguntaAnterior + "comment";
							isFake = isFakeDaPerguntaAnterior;
							isCommon = isCommonDaPerguntaAnterior;
						}
						codigoRealDaPerguntaAnterior = codigoRealDaPergunta;
						isFakeDaPerguntaAnterior = isFake;
						isCommonDaPerguntaAnterior = isCommon;


						if(codigoRealDaPergunta.contains("comment") || codigoRealDaPergunta.endsWith("b"))
							continue;

						//mapNomeDaColunaId.put(nomeDaColuna, codigoRealDaPergunta);
						String valor = rs.getString(nomeDaColuna);

						if(!valor.equals("A1") && !valor.equals("A2") && !valor.equals("A3") && !valor.equals("A4") && !valor.equals("A5")){
							break;
						}

						query = "select answer from answers where qid = " + idDaPergunta + " and code = '" +  valor + "'";
						ResultSet rsInt = cbd.executaQuery(query);
						rsInt.next();
						//System.out.println(query);
						String realId = rsInt.getString("answer");

						if(isCommon)
							System.out.println(idDaPergunta + "\t" + codigoRealDaPergunta + "\t" + realId);
						else{
							int a = 0;
							int b = a;
						}

					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}*/

	//metodo que vai extrair notas numericas, separadas por criterio (pode opcionalmente, considerar ou nao as fakes)
	private static void extraiNotasNumericasComunsPorCriterio(int surveyId, int tokenId) {
		try {
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD("limeSurveyDB");

			String query = "select * from survey_" + surveyId
					+ " where token = '" + tokenId + "' and submitdate IS NOT NULL";
			// Executa a query
			ResultSet rs = cbd.executaQuery(query);
			
			String queryinterna = "select consider_c1, consider_c2, consider_c3, consider_c4, consider_semantic_chap from tokens_" + surveyId
					+ " where token = '" + tokenId + "'";
			ResultSet rsInterno = cbd.executaQuery(queryinterna);
			rsInterno.next();
			boolean consideraC1 = rsInterno.getBoolean("consider_c1");
			boolean consideraC2 = rsInterno.getBoolean("consider_c2");
			boolean consideraC3 = rsInterno.getBoolean("consider_c3");
			boolean consideraC4 = rsInterno.getBoolean("consider_c4");
			boolean consideraChapterSemantic = rsInterno.getBoolean("consider_semantic_chap");
			
			//boolean consideraC1 = true;
			//boolean consideraC2 = true;
			//boolean consideraC3 = true;
			//boolean consideraC4 = true;
			//boolean consideraChapterSemantic = true;
		
		
			// Map<String, String> mapNomeDaColunaId = new HashMap<String,
			// String>();
			// Map<String, String> mapIdDaPerguntaValor = new HashMap<String,
			// String>();

			String strChapterSemantic = "";
			String strC1 = "";
			String strC2 = "";
			String strC3 = "";
			String strC4 = "";

			while (rs.next()) {
				ResultSetMetaData meta = rs.getMetaData();
				int numeroDeColunas = meta.getColumnCount();

				String codigoRealDaPerguntaAnterior = "";

				boolean isFakeDaPerguntaAnterior = false;
				boolean isCommonDaPerguntaAnterior = false;


				for (int i = 0; i < numeroDeColunas; i++) {
					String nomeDaColuna = meta.getColumnName(i + 1);
					// System.out.println(nomeDaColuna);

					if (i >= 9) {
						String idDaPergunta = nomeDaColuna.split("X")[2];
						String codigoRealDaPergunta = "";
						boolean isFake = false;
						boolean isCommon = false;


						if (!idDaPergunta.contains("comment")) {
							codigoRealDaPergunta = descobreIdRealDaPergunta(
									idDaPergunta, cbd);
							isFake = verificaSeEhFake(idDaPergunta, cbd);
							isCommon = verificaSeEhCommon(idDaPergunta, cbd);
						} else {
							codigoRealDaPergunta = codigoRealDaPerguntaAnterior
									+ "comment";
							isFake = isFakeDaPerguntaAnterior;
							isCommon = isCommonDaPerguntaAnterior;
						}
						codigoRealDaPerguntaAnterior = codigoRealDaPergunta;
						isFakeDaPerguntaAnterior = isFake;
						isCommonDaPerguntaAnterior = isCommon;


						if (codigoRealDaPergunta.contains("comment")
								|| codigoRealDaPergunta.endsWith("b"))
							continue;

						// mapNomeDaColunaId.put(nomeDaColuna,
						// codigoRealDaPergunta);
						String valor = rs.getString(nomeDaColuna);

						// esse if eh para desconsiderar (pular) as respostas
						// discursivas
						if (!valor.equals("A1") && !valor.equals("A2")
								&& !valor.equals("A3") && !valor.equals("A4")
								&& !valor.equals("A5")) {
							System.out.println(valor);
							break;
						} else {
							int a = 0;
							int b = a;
						}

						if(!isCommon)
							continue;

						query = "select answer from answers where qid = "
								+ idDaPergunta + " and code = '" + valor + "'";
						ResultSet rsInt = cbd.executaQuery(query);
						rsInt.next();
						// System.out.println(query);
						String realId = rsInt.getString("answer");

						if (codigoRealDaPergunta.contains("c1") && consideraC1)
							strC1 += idDaPergunta + "\t" + codigoRealDaPergunta
							+ "\t" + realId + "\n";
						else if (codigoRealDaPergunta.contains("c2") && consideraC2)
							strC2 += idDaPergunta + "\t" + codigoRealDaPergunta
							+ "\t" + realId + "\n";
						else if (codigoRealDaPergunta.contains("c3") && consideraC3)
							strC3 += idDaPergunta + "\t" + codigoRealDaPergunta
							+ "\t" + realId + "\n";
						else if (codigoRealDaPergunta.contains("c4") && consideraC4)
							strC4 += idDaPergunta + "\t" + codigoRealDaPergunta
							+ "\t" + realId + "\n";
						else if(!codigoRealDaPergunta.contains("c1") && !codigoRealDaPergunta.contains("c2") && !codigoRealDaPergunta.contains("c3") && !codigoRealDaPergunta.contains("c4") && consideraChapterSemantic)
							strChapterSemantic += idDaPergunta + "\t"
									+ codigoRealDaPergunta + "\t" + realId
									+ "\n";

						// mapIdDaPerguntaValor.put(codigoRealDaPergunta,
						// realId);
						// System.out.println(idDaPergunta + "\t" +
						// codigoRealDaPergunta + "\t" + realId);

					}
				}

				System.out
				.println("**************strChapterSemantic*******************");
				System.out.println(strChapterSemantic);
				System.out.println("**************strC1*******************");
				System.out.println(strC1);
				System.out.println("**************strC2*******************");
				System.out.println(strC2);
				System.out.println("**************strC3*******************");
				System.out.println(strC3);
				System.out.println("**************strC4*******************");
				System.out.println(strC4);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*//metodo que vai extrair notas numericas, separadas por API (pode opcionalmente, considerar ou nao as fakes)
	private static void extraiNotasNumericasComunsPorAPI(int surveyId, int tokenId) {
		try {
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD("limeSurveyDB");

			ConexaoDB cbdSO = new ConexaoDB();
			cbdSO.conectaAoBD("stackof");

			String query = "select * from survey_" + surveyId
					+ " where token = '" + tokenId + "'";
			// Executa a query
			ResultSet rs = cbd.executaQuery(query);

			// Map<String, String> mapNomeDaColunaId = new HashMap<String,
			// String>();
			// Map<String, String> mapIdDaPerguntaValor = new HashMap<String,
			// String>();

			String strSwt = "";
			String strLinq = "";
			String strQt = "";

			while (rs.next()) {
				ResultSetMetaData meta = rs.getMetaData();
				int numeroDeColunas = meta.getColumnCount();

				String codigoRealDaPerguntaAnterior = "";
				boolean isFakeDaPerguntaAnterior = false;
				boolean isCommonDaPerguntaAnterior = false;

				for (int i = 0; i < numeroDeColunas; i++) {
					String nomeDaColuna = meta.getColumnName(i + 1);
					// System.out.println(nomeDaColuna);

					if (i >= 9) {
						String idDaPergunta = nomeDaColuna.split("X")[2];
						String codigoRealDaPergunta = "";
						boolean isFake = false;
						boolean isCommon = false;


						if (!idDaPergunta.contains("comment")) {
							codigoRealDaPergunta = descobreIdRealDaPergunta(
									idDaPergunta, cbd);
							isFake = verificaSeEhFake(idDaPergunta, cbd);
							isCommon = verificaSeEhCommon(idDaPergunta, cbd);
						} else {
							codigoRealDaPergunta = codigoRealDaPerguntaAnterior
									+ "comment";
							isFake = isFakeDaPerguntaAnterior;
							isCommon = isCommonDaPerguntaAnterior;
						}
						codigoRealDaPerguntaAnterior = codigoRealDaPergunta;
						isFakeDaPerguntaAnterior = isFake;
						isCommonDaPerguntaAnterior = isCommon;

						if (codigoRealDaPergunta.contains("comment")
								|| codigoRealDaPergunta.endsWith("b"))
							continue;

						if(!isCommon)
							continue;

						// mapNomeDaColunaId.put(nomeDaColuna,
						// codigoRealDaPergunta);
						String valor = rs.getString(nomeDaColuna);

						if (!valor.equals("A1") && !valor.equals("A2")
								&& !valor.equals("A3") && !valor.equals("A4")
								&& !valor.equals("A5")) {
							break;
						}

						query = "select answer from answers where qid = "
								+ idDaPergunta + " and code = '" + valor + "'";
						ResultSet rsInt = cbd.executaQuery(query);
						rsInt.next();
						// System.out.println(query);
						String realId = rsInt.getString("answer");

						String apiAtual = "";
						if (codigoRealDaPergunta.contains("c1")
								|| codigoRealDaPergunta.contains("c2")
								|| codigoRealDaPergunta.contains("c3")
								|| codigoRealDaPergunta.contains("c4")) {
							String idDaPerguntaNoSO = codigoRealDaPergunta
									.split("Q")[1].split("s")[0];
							// String idDaRespostaNoSO =
							// codigoRealDaPergunta.split("Q")[1].split("s")[1].split("c")[0];

							query = "select tags from posts where id = "
									+ idDaPerguntaNoSO;
							// System.out.println(query);
							// Executa a query
							ResultSet rsInterno = cbdSO.executaQuery(query);
							rsInterno.next();
							String tags = rsInterno.getString("tags");

							int count = 0;
							if (tags.contains("<swt>")) {
								apiAtual = "SWT";
								count++;
							}
							if (tags.contains("<linq>")) {
								apiAtual = "LINQ";
								count++;
							}
							if (tags.contains("<qt>")) {
								apiAtual = "QT";
								count++;
							}
							if (count > 1) {
								System.out.println("########DANGER#######");
							}
						} else {
							if (codigoRealDaPergunta.contains("SWT"))
								apiAtual = "SWT";
							if (codigoRealDaPergunta.contains("LINQ"))
								apiAtual = "LINQ";
							if (codigoRealDaPergunta.contains("QT"))
								apiAtual = "QT";
						}

						if (apiAtual.equals("SWT"))
							strSwt += idDaPergunta + "\t"
									+ codigoRealDaPergunta + "\t" + realId
									+ "\n";
						else if (apiAtual.equals("LINQ"))
							strLinq += idDaPergunta + "\t"
									+ codigoRealDaPergunta + "\t" + realId
									+ "\n";
						else if (apiAtual.equals("QT"))
							strQt += idDaPergunta + "\t" + codigoRealDaPergunta
							+ "\t" + realId + "\n";

						// mapIdDaPerguntaValor.put(codigoRealDaPergunta,
						// realId);
						// System.out.println(idDaPergunta + "\t" +
						// codigoRealDaPergunta + "\t" + realId);

					}
				}

				System.out.println("**************SWT*******************");
				System.out.println(strSwt);
				System.out.println("**************LINQ*******************");
				System.out.println(strLinq);
				System.out.println("**************strQt*******************");
				System.out.println(strQt);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/

	/*//metodo que vai extrair notas numericas, separadas por criterio (pode opcionalmente, considerar ou nao as fakes)
	private static void extraiNotasNumericasComunsPorAPIePorCriterio(int surveyId, int tokenId) {
		try {
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD("limeSurveyDB");

			ConexaoDB cbdSO = new ConexaoDB();
			cbdSO.conectaAoBD("stackof");

			String query = "select * from survey_" + surveyId
					+ " where token = '" + tokenId + "' and submitdate IS NOT NULL";
			// Executa a query
			ResultSet rs = cbd.executaQuery(query);

			// Map<String, String> mapNomeDaColunaId = new HashMap<String,
			// String>();
			// Map<String, String> mapIdDaPerguntaValor = new HashMap<String,
			// String>();

			String strSwtChapterSemantic = "";
			String strSwtC1 = "";
			String strSwtC2 = "";
			String strSwtC3 = "";
			String strSwtC4 = "";

			String strLinqChapterSemantic = "";
			String strLinqC1 = "";
			String strLinqC2 = "";
			String strLinqC3 = "";
			String strLinqC4 = "";

			String strQtChapterSemantic = "";
			String strQtC1 = "";
			String strQtC2 = "";
			String strQtC3 = "";
			String strQtC4 = "";


			while (rs.next()) {
				ResultSetMetaData meta = rs.getMetaData();
				int numeroDeColunas = meta.getColumnCount();

				String codigoRealDaPerguntaAnterior = "";

				boolean isFakeDaPerguntaAnterior = false;
				boolean isCommonDaPerguntaAnterior = false;


				for (int i = 0; i < numeroDeColunas; i++) {
					String nomeDaColuna = meta.getColumnName(i + 1);
					// System.out.println(nomeDaColuna);

					if (i >= 9) {
						String idDaPergunta = nomeDaColuna.split("X")[2];
						String codigoRealDaPergunta = "";
						boolean isFake = false;
						boolean isCommon = false;


						if (!idDaPergunta.contains("comment")) {
							codigoRealDaPergunta = descobreIdRealDaPergunta(
									idDaPergunta, cbd);
							isFake = verificaSeEhFake(idDaPergunta, cbd);
							isCommon = verificaSeEhCommon(idDaPergunta, cbd);
						} else {
							codigoRealDaPergunta = codigoRealDaPerguntaAnterior
									+ "comment";
							isFake = isFakeDaPerguntaAnterior;
							isCommon = isCommonDaPerguntaAnterior;
						}
						codigoRealDaPerguntaAnterior = codigoRealDaPergunta;
						isFakeDaPerguntaAnterior = isFake;
						isCommonDaPerguntaAnterior = isCommon;


						if (codigoRealDaPergunta.contains("comment")
								|| codigoRealDaPergunta.endsWith("b"))
							continue;

						// mapNomeDaColunaId.put(nomeDaColuna,
						// codigoRealDaPergunta);
						String valor = rs.getString(nomeDaColuna);

						// esse if eh para desconsiderar (pular) as respostas
						// discursivas
						if (!valor.equals("A1") && !valor.equals("A2")
								&& !valor.equals("A3") && !valor.equals("A4")
								&& !valor.equals("A5")) {
							System.out.println(valor);
							break;
						} else {
							int a = 0;
							int b = a;
						}

						if(!isCommon)
							continue;

						query = "select answer from answers where qid = "
								+ idDaPergunta + " and code = '" + valor + "'";
						ResultSet rsInt = cbd.executaQuery(query);
						rsInt.next();
						// System.out.println(query);
						String realId = rsInt.getString("answer");

						String apiAtual = "";
						if (codigoRealDaPergunta.contains("c1")
								|| codigoRealDaPergunta.contains("c2")
								|| codigoRealDaPergunta.contains("c3")
								|| codigoRealDaPergunta.contains("c4")) {
							String idDaPerguntaNoSO = codigoRealDaPergunta
									.split("Q")[1].split("s")[0];
							// String idDaRespostaNoSO =
							// codigoRealDaPergunta.split("Q")[1].split("s")[1].split("c")[0];

							query = "select tags from posts where id = "
									+ idDaPerguntaNoSO;
							// System.out.println(query);
							// Executa a query
							ResultSet rsInterno = cbdSO.executaQuery(query);
							rsInterno.next();
							String tags = rsInterno.getString("tags");

							int count = 0;
							if (tags.contains("<swt>")) {
								apiAtual = "SWT";
								count++;
							}
							if (tags.contains("<linq>")) {
								apiAtual = "LINQ";
								count++;
							}
							if (tags.contains("<qt>")) {
								apiAtual = "QT";
								count++;
							}
							if (count > 1) {
								System.out.println("########DANGER#######");
							}
						} else {
							if (codigoRealDaPergunta.contains("SWT"))
								apiAtual = "SWT";
							if (codigoRealDaPergunta.contains("LINQ"))
								apiAtual = "LINQ";
							if (codigoRealDaPergunta.contains("QT"))
								apiAtual = "QT";
						}

						if (apiAtual.equals("SWT")){
							if (codigoRealDaPergunta.contains("c1"))
								strSwtC1 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c2"))
								strSwtC2 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c3"))
								strSwtC3 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c4"))
								strSwtC4 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else
								strSwtChapterSemantic += idDaPergunta + "\t"
										+ codigoRealDaPergunta + "\t" + realId
										+ "\n";
						}else if (apiAtual.equals("LINQ")){
							if (codigoRealDaPergunta.contains("c1"))
								strLinqC1 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c2"))
								strLinqC2 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c3"))
								strLinqC3 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c4"))
								strLinqC4 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else
								strLinqChapterSemantic += idDaPergunta + "\t"
										+ codigoRealDaPergunta + "\t" + realId
										+ "\n";
						}else if (apiAtual.equals("QT")){
							if (codigoRealDaPergunta.contains("c1"))
								strQtC1 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c2"))
								strQtC2 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c3"))
								strQtC3 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else if (codigoRealDaPergunta.contains("c4"))
								strQtC4 += idDaPergunta + "\t" + codigoRealDaPergunta
								+ "\t" + realId + "\n";
							else
								strQtChapterSemantic += idDaPergunta + "\t"
										+ codigoRealDaPergunta + "\t" + realId
										+ "\n";
						}
					}
				}

				System.out.println("##############Swt###############");
				System.out.println("**************strSwtChapterSemantic*******************");
				System.out.println(strSwtChapterSemantic);
				System.out.println("**************strSwtC1*******************");
				System.out.println(strSwtC1);
				System.out.println("**************strSwtC2*******************");
				System.out.println(strSwtC2);
				System.out.println("**************strSwtC3*******************");
				System.out.println(strSwtC3);
				System.out.println("**************strSwtC4*******************");
				System.out.println(strSwtC4);

				System.out.println("##############Linq###############");
				System.out.println("**************strLinqChapterSemantic*******************");
				System.out.println(strLinqChapterSemantic);
				System.out.println("**************strLinqC1*******************");
				System.out.println(strLinqC1);
				System.out.println("**************strLinqC2*******************");
				System.out.println(strLinqC2);
				System.out.println("**************strLinqC3*******************");
				System.out.println(strLinqC3);
				System.out.println("**************strLinqC4*******************");
				System.out.println(strLinqC4);

				System.out.println("##############Qt###############");
				System.out.println("**************strQtChapterSemantic*******************");
				System.out.println(strQtChapterSemantic);
				System.out.println("**************strQtC1*******************");
				System.out.println(strQtC1);
				System.out.println("**************strQtC2*******************");
				System.out.println(strQtC2);
				System.out.println("**************strQtC3*******************");
				System.out.println(strQtC3);
				System.out.println("**************strQtC4*******************");
				System.out.println(strQtC4);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/


	// metodo para extrair as notas numericas que sao comuns aos tres tipos de
	// questionarios
	private static void extraiNotasDasPerguntasFake(int surveyId, int tokenId) {
		try{
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD("limeSurveyDB");

			ConexaoDB cbdSO = new ConexaoDB();
			cbdSO.conectaAoBD("stackof");

			String query = "select * from survey_" + surveyId + " where token = '" + tokenId + "' and submitdate IS NOT NULL";
			//Executa a query
			ResultSet rs = cbd.executaQuery(query);

			//Map<String, String> mapNomeDaColunaId = new HashMap<String, String>();
			//Map<String, String> mapIdDaPerguntaValor = new HashMap<String, String>();

			while(rs.next()){
				ResultSetMetaData meta = rs.getMetaData();
				int numeroDeColunas = meta.getColumnCount();

				String codigoRealDaPerguntaAnterior = "";
				boolean isFakeDaPerguntaAnterior = false;
				boolean isCommonDaPerguntaAnterior = false;

				for(int i=0; i< numeroDeColunas; i++){
					String nomeDaColuna = meta.getColumnName(i+1);
					//System.out.println(nomeDaColuna);

					if(i >= 9){
						
						if(nomeDaColuna.contains("10346")){
							int a = 0;
							int b = a;
						}
						
						String idDaPergunta = nomeDaColuna.split("X")[2];
						String codigoRealDaPergunta = "";
						boolean isFake = false;
						boolean isCommon = false;

						if(!idDaPergunta.contains("comment")){
							codigoRealDaPergunta = descobreIdRealDaPergunta(idDaPergunta, cbd);
							isFake = verificaSeEhFake(idDaPergunta, cbd);
							isCommon = verificaSeEhCommon(idDaPergunta, cbd);
						}else{
							codigoRealDaPergunta = codigoRealDaPerguntaAnterior + "comment";
							isFake = isFakeDaPerguntaAnterior;
							isCommon = isCommonDaPerguntaAnterior;
						}
						codigoRealDaPerguntaAnterior = codigoRealDaPergunta;
						isFakeDaPerguntaAnterior = isFake;
						isCommonDaPerguntaAnterior = isCommon;


						if(codigoRealDaPergunta.contains("comment") || codigoRealDaPergunta.endsWith("b"))
							continue;

						//mapNomeDaColunaId.put(nomeDaColuna, codigoRealDaPergunta);
						String valor = rs.getString(nomeDaColuna);

						if(!valor.equals("A1") && !valor.equals("A2") && !valor.equals("A3") && !valor.equals("A4") && !valor.equals("A5")){
							break;
						}

						if(Integer.parseInt(idDaPergunta) == 10798){
							int a =0;
							int b=a;
						}

						query = "select answer from answers where qid = " + idDaPergunta + " and code = '" +  valor + "'";
						ResultSet rsInt = cbd.executaQuery(query);
						rsInt.next();
						//System.out.println(query);
						String realId = rsInt.getString("answer");

						if(isFake)
							System.out.println(idDaPergunta + "\t" + codigoRealDaPergunta + "\t" + realId);
						else{
							int a = 0;
							int b = a;
						}

					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	private static String descobreIdRealDaPergunta(String idDaPergunta,
			ConexaoDB cbd) {
		String id = "";

		try {

			String query = "select title from questions where qid = "
					+ idDaPergunta;
			//System.out.println(query);
			// Executa a query
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			id = rs.getString("title");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return id;
	}

	private static boolean verificaSeEhFake(String idDaPergunta, ConexaoDB cbd) {
		Boolean isFake = false;

		try {

			String query = "select is_fake from questions where qid = "
					+ idDaPergunta;
			// System.out.println(query);
			// Executa a query
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			isFake = rs.getBoolean("is_fake");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return isFake;
	}

	private static boolean verificaSeEhCommon(String idDaPergunta, ConexaoDB cbd) {
		Boolean isCommon = false;

		try {

			String query = "select is_common from questions where qid = "
					+ idDaPergunta;
			// System.out.println(query);
			// Executa a query
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			isCommon = rs.getBoolean("is_common");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return isCommon;
	}
}
