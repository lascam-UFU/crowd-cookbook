package br.ufu.facom.lsal.AnalisaDadosDoSurvey;

/** 
 * 2011 11:52:01 AM
 *
 * The Similarity Library
 * 
 * Copyright (C) Giuseppe  Pirr�, 2010
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */


import it.gonzo.assessor.WordNetAssessor;
import it.gonzo.similarity.utils.SimilarityConstants;


/**
 * @author joe
 *
 */
public class WordWordNetAssessorTest {

	/**
	 * @param args
	 */
	public static void main(String[] args){
		// TODO Auto-generated method stub

		WordNetAssessor wn = new WordNetAssessor();

		System.out.println("Tet VERB similarity "
				+ wn.getWordNetNounSimilarityByIC("kill", "customize",
						SimilarityConstants.FAITH_MEASURE,
						SimilarityConstants.INTRINSIC_IC));

		System.out.println("Tet NOUN similarity "
				+ wn.getWordNetVerbSimilarityByIC("run", "hide",
						SimilarityConstants.FAITH_MEASURE,
						SimilarityConstants.INTRINSIC_IC));

		System.out.println("Tet ADJECTIVE similarity "
				+ wn.getWordNetAdjectiveSimilarityByIC("liberal", "democratic",
						SimilarityConstants.FAITH_MEASURE,
						SimilarityConstants.INTRINSIC_IC));
		
		System.out.println("Tet ADVERB similarity "
				+ wn.getWordNetAdverbSimilarityByIC("often", "always",
						SimilarityConstants.FAITH_MEASURE,
						SimilarityConstants.INTRINSIC_IC));

	}

}
