package br.ufu.facom.lsal.AnalisaDadosDoSurvey;

public class Capitulo {
	private String id;
	private String titulo;
	private String tokenId;
		
	public Capitulo(String id, String titulo) {
		super();
		this.id = id;
		this.titulo = titulo;
	}
	
	public Capitulo(String id, String titulo, String tokenId) {
		super();
		this.id = id;
		this.titulo = titulo;
		this.tokenId = tokenId;
	}
	
	public String getTokenId() {
		return tokenId;
	}

	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	
}
