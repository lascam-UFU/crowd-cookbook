package br.ufu.facom.isel.cookbookgenerator.main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.time.FastDateFormat;

import br.facom.ufu.lsa.GeradorDeCookbooks.FiltrosParaCookbook.Filtros;
import br.ufu.facom.RanqueamentoDePares.ProduzArquivosParaParaLearningToRank;
import br.ufu.facom.isel.cookbookgenerator.lda.LDALauncher;
import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;
import br.ufu.facom.lsa.ExtratorDeCaracteristicasDosPosts.DadosRatingCategoria;
import br.ufu.facom.lsa.GeradorDeCookbooks.ComparatorScoreDoRanqueamento;
import br.ufu.facom.lsa.GeradorDeCookbooks.ComparatorScoreGroundThrough;
import br.ufu.facom.lsa.GeradorDeCookbooks.DadoRanqueamento;
import br.ufu.facom.lsa.GeradorDeCookbooks.Receita;
import br.ufu.facom.lsa.Lda.DocTopicPair;
import br.ufu.facom.lsa.Lda.GerenciadorDeLDA;

import java.io.PrintWriter;

public class GenerationAlgorithm {

	InputConfig config;
	LDAConfig ldaConfig;

	ConexaoDB cdb;
	PrintWriter outFileParametros;

	public GenerationAlgorithm(InputConfig c) {
		config = c;
		ldaConfig = new LDAConfig(config);

	    cdb = new ConexaoDB();
		try {
			cdb.conectaAoBD();
		} catch (SQLException e) {
			e.printStackTrace();
			System.exit(1);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.exit(1);
		}
		
		// Cria um arquivo que contem os valores dos varios parametros
		try {
			outFileParametros = new PrintWriter(ldaConfig.pathForLDAFiles + "/parametros.txt");
			outFileParametros.print(config.toString());
			outFileParametros.flush();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}

	}

	public void generateCookbook() {
//		// map que guardara os scores de todos os posts do SO
//		Map<String, Integer> mapScores = new HashMap<String, Integer>();
//		
//		// Inicializa o map com o score de todos os posts do SO. Esse score sera usado
//		// para calcular o valor da metrica groud through (media ponderada) para o caso
//		// de tipoDeRanqueamento=2
//		inicializaMapScores(mapScores, config.getAPI());
//		System.out.println(mapScores.size());

		// Vamos criar o objeto para conexao com o banco, que sera usado para recuperar
		// o corpo da resposta

		///////////// Aplica LDA /////////////
		LDALauncher ldaLauncher = new LDALauncher(config, ldaConfig, cdb, outFileParametros);
		ldaLauncher.execute();

		////////////// Inicio do Algoritmo ////////////

		Map<String, List<Receita>> cookbook = null;
		String nameAPI = config.getAPI();

		int totalNumberOfRecipes = 0;

		int numberOfChapters = config.getNumberOfChapters();

		do {

			outFileParametros.println("######################### Tentativa posicaoMaximaASerConsiderada = "
					+ config.getMaxNumberThreadsAllowed() + " ####################################");
			outFileParametros.flush();

			// Map que ira guardar para cada capitulo, as receitas selecionadas para
			// constituirem o cookbook;
			// <idDoCapitulo, List<Receita>>
			cookbook = new HashMap<String, List<Receita>>();
			inicializaCookbook(cookbook, numberOfChapters);

			int nroDeParesDescartadosPorNaoTeremRankSuficiente = 0;
			int nroDeParesDescartadosPorNaoTeremPercentSusficente = 0;

			int nroTotalDeParesVerificados = 0;
			// Vamos verificar para cada thread, se existem alguns pares bem colocados no
			// ranking e ao mesmo tempo ir montando o cookbook
			outFileParametros.println("Nro de threads participantes do LDA = mapDocumentoTopicos.size() "
					+ ldaLauncher.getMapDocumentoTopicos().size());
			Iterator it = ldaLauncher.getMapDocumentoTopicos().entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pairs = (Map.Entry) it.next();
				String idDaThread = (String) pairs.getKey();
				// System.out.println(idDaThread);

				// String idDoTopicoDominante = (String)pairs.getValue();
				String idDoTopicoDominante = ((DocTopicPair) (((List<DocTopicPair>) pairs.getValue()).get(0)))
						.getTopicId() + "";
				double percentDoTopicoDominante = ((DocTopicPair) (((List<DocTopicPair>) pairs.getValue()).get(0)))
						.getPercent();

				// int count = 0;
				if (ldaLauncher.getMapDadosRanking().containsKey(idDaThread)) {

					DadoRanqueamento dr = ldaLauncher.getMapDadosRanking().get(idDaThread);
					String idDaResposta = dr.getIdResposta();
					int posicaoNoRanking = dr.getPosicaoNoRank();
					double mediaDoPar = dr.getScoreGoundThrough();

					if (percentDoTopicoDominante < ldaConfig.minAdherenceOfPairToTopic) {
						nroDeParesDescartadosPorNaoTeremPercentSusficente++;
						continue;
					}

					if (posicaoNoRanking <= config.getMaxNumberThreadsAllowed()) {
						List<Receita> listaDeReceitas = cookbook.get(idDoTopicoDominante);
						Receita receita = constroiReceita(Integer.parseInt(idDaThread), Integer.parseInt(idDaResposta),
								posicaoNoRanking, dr.getScoreGoundThrough(), percentDoTopicoDominante);
						listaDeReceitas.add(receita);
					} else
						nroDeParesDescartadosPorNaoTeremRankSuficiente++;

				}
			}

			// ajustaCookbook(cookbook, mapDocumentoTopicos, mapTopicoTopTerms,
			// outFileParametros);
			// Metodo chamado pra excluir os capitulos que ficaram muito pequenos (menos de
			// 3 receitas)
			removeCapitulosPequenos(cookbook, outFileParametros);

			outFileParametros.println("nroDeParesDescartadosPorNaoTeremRankSuficiente: "
					+ nroDeParesDescartadosPorNaoTeremRankSuficiente);
			outFileParametros.println("nroDeParesDescartadosPorNaoTeremPercentSusficente: "
					+ nroDeParesDescartadosPorNaoTeremPercentSusficente);

			outFileParametros.println("nroTotalDeParesVerificados: " + nroTotalDeParesVerificados);

			Map<String, Integer> mapCountReceitasPorCapitulo = new HashMap<String, Integer>();

			// Depois de construido o cookbook vamos verificar qual eh a similaridade
			// (percentual) das receitas com seus respectivos capitulos
			totalNumberOfRecipes = 0;
			it = cookbook.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pairs = (Map.Entry) it.next();
				List<Receita> listaReceitas = (List<Receita>) pairs.getValue();
				String topicoId = (String) pairs.getKey();

				outFileParametros.println("topicId = " + topicoId);
				for (int j = 0; j < listaReceitas.size(); j++) {
					totalNumberOfRecipes++;
					Receita r = listaReceitas.get(j);
					// System.out.println(r.getIdPergunta() + "-" + r.getIdResposta() + "-pos " +
					// r.getPosicaoNoRank());
					outFileParametros.println(r.getIdPergunta() + "-" + r.getIdResposta() + "\t"
							+ r.getPercentDoTopicoDominanteDaThread() + "\t" + r.getScoreDoPar());
					outFileParametros.flush();
				}
			}
			System.out.println("Nro total de receitas (pares selecionados para o cookbook): " + totalNumberOfRecipes);
			outFileParametros
					.println("Nro total de receitas (pares selecionados para o cookbook): " + totalNumberOfRecipes);
			outFileParametros.flush();

			System.out.println("Nro de pares por capitulo");
			outFileParametros.println("Nro de pares por capitulo");
			outFileParametros.flush();
			for (int j = 0; j < numberOfChapters; j++) {
				if (cookbook.containsKey(j + "")) {
					List<Receita> listaReceitas = cookbook.get(j + "");
					System.out.println(j + "\t" + listaReceitas.size());
					outFileParametros.println(j + "\t" + listaReceitas.size());
					outFileParametros.flush();
				}
			}

			System.out.println("Nro de Links por capitulo");
			outFileParametros.println("Nro de Links por capitulo");
			outFileParametros.flush();
			for (int j = 0; j < numberOfChapters; j++) {
				if (cookbook.containsKey(j + "")) {
					List<Receita> listaReceitas = cookbook.get(j + "");
					// System.out.println(j + "\t" + listaReceitas.size());
					List<String> listaIdDePerguntas = new ArrayList<String>();

					for (int k = 0; k < listaReceitas.size(); k++) {
						Receita r = listaReceitas.get(k);

						if (!listaIdDePerguntas.contains(r.getIdPergunta() + "")) {
							listaIdDePerguntas.add(r.getIdPergunta() + "");
						}
					}
					System.out.println(j + "\t" + listaIdDePerguntas.size());
					outFileParametros.println(j + "\t" + listaIdDePerguntas.size());
					outFileParametros.flush();
				}
			}
			// incrementa a posicao maxima a ser considerada
			config.incMaxNumberThreadsAllowed(10);
		} while (totalNumberOfRecipes < config.getMinNumberOfRecipes());

		outFileParametros.close();

		ConexaoDB cbdCookbooks = new ConexaoDB();
		// Conecta ao banco stack_research
		cbdCookbooks.conectaAoBD("stack_research");
		PreparedStatement ps = cbdCookbooks.criaPreparedStatement(
				"insert into recipes(NameApis, NameTopic, TopicId, QuestionId, AnswerId, TitleQuestion, TagsQuestion, BodyQuestion, BodyAnswer, RankingPosition) values(?,?,?,?,?,?,?,?,?,?)");

		PrintWriter sqlScriptForCookbook=null;
		try {
			sqlScriptForCookbook = new PrintWriter(ldaConfig.pathForLDAFiles + "/sqlScriptForCookbook_" + config.getAPI() + ".sql");
			
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		
		int contadorCapitulo = 0;
		Iterator it = ldaLauncher.getMapTopicoTopTerms().entrySet().iterator();
		while (it.hasNext()) {
			contadorCapitulo++;
			Map.Entry pairs = (Map.Entry) it.next();
			String idDoTopico = (String) pairs.getKey();
			String topTermosDoTopico = (String) pairs.getValue();

			if (cookbook.containsKey(idDoTopico)) {
				List<Receita> receitas = cookbook.get(idDoTopico);

				for (int j = 0; j < receitas.size(); j++) {
					Receita r = receitas.get(j);

					try {
						ps.setString(1, nameAPI);
						ps.setString(2, topTermosDoTopico);
						ps.setInt(3, Integer.parseInt(idDoTopico));
						ps.setInt(4, r.getIdPergunta());
						ps.setInt(5, r.getIdResposta());
						ps.setString(6, r.getTitulo());
						ps.setString(7, r.getTags());
						ps.setString(8, r.getCorpoPergunta().replace("<a href=", "<a target=newtab href="));
						ps.setString(9, r.getCorpoResposta().replace("<a href=", "<a target=newtab href="));
						ps.setInt(10, r.getPosicaoNoRank());
						//ps.setShort(11, (short) 0); // Uncomment if database = stackOfCookBooks
						ps.executeUpdate();
						
						sqlScriptForCookbook.println(
								"insert into recipes(NameApis, NameTopic, TopicId, QuestionId, AnswerId, TitleQuestion, TagsQuestion, BodyQuestion, BodyAnswer, RankingPosition) values ("
								+  nameAPI + ", " 
						        + topTermosDoTopico 
						        + idDoTopico + ", " 
						        + r.getIdPergunta()  + ", " 
						        + r.getIdResposta() + ", " 
						        + r.getTitulo() + ", " 
						        + r.getTags() + ", " 
						        + r.getCorpoPergunta().replace("<a href=", "<a target=newtab href=") + ", " 
						        + r.getCorpoResposta().replace("<a href=", "<a target=newtab href=") + ", " 
						        + r.getPosicaoNoRank() + ");" );
					} catch (SQLException e) {
						e.printStackTrace();
						System.exit(1);
					}
				}
			}
			// System.out.println(idDaThread);
		}
		cbdCookbooks.close();
		sqlScriptForCookbook.close();

		// }

		cdb.close();
		System.out.println("Cookbook sucessfully generated!");
		System.exit(0);
	}

	private static void removeCapitulosPequenos(Map<String, List<Receita>> cookbook, PrintWriter outFileParametros) {

		int nroDeCapitulosRemovidos = 0;
		int nroDeReceitasDosCapitulosRemovidos = 0;

		Set<String> setIdCapitulos = cookbook.keySet();
		Object[] idCapVet = setIdCapitulos.toArray();
		for (int j = 0; j < idCapVet.length; j++) {
			String idCap = (String) idCapVet[j];

			List<Receita> cap = cookbook.get(idCap);
			if (cap.size() < 3) {
				nroDeCapitulosRemovidos++;
				nroDeReceitasDosCapitulosRemovidos += cap.size();
				cookbook.remove(idCap);
			}
		}

		outFileParametros.println("nroDeCapitulosRemovidos: " + nroDeCapitulosRemovidos);
		outFileParametros.println("nroDeReceitasDosCapitulosRemovidos: " + nroDeReceitasDosCapitulosRemovidos);
	}

	private static void ajustaCookbook(Map<String, List<Receita>> cookbook,
			Map<String, List<String>> mapDocumentoTopicos, Map<String, String> mapTopicoTopTerms,
			PrintWriter outFileParametros) {
		// Nesse ponto o cookbook ja esta construido mas vamos fazer alguns ajustes para
		// evitar capitulos com apenas 1 link
		Set<String> setIdCapitulos = cookbook.keySet();
		Object[] idCapVet = setIdCapitulos.toArray();
		List<Integer> listIdCap = new ArrayList<Integer>();
		for (int j = 0; j < idCapVet.length; j++) {
			String idCap = (String) idCapVet[j];
			listIdCap.add(Integer.parseInt(idCap));
		}

		for (int j = 0; j < listIdCap.size(); j++) {
			String topicoIdOriginal = listIdCap.get(j) + "";
			List<Receita> listaReceitas = cookbook.get(topicoIdOriginal);
			// Verifica se todas as receitas que estao no topico possuem o mesmo id de
			// pergunta, o que significa que nro de links = 1
			List<String> listaIdDePerguntas = new ArrayList<String>();
			for (int k = 0; k < listaReceitas.size(); k++) {
				Receita r = listaReceitas.get(k);
				if (!listaIdDePerguntas.contains(r.getIdPergunta() + "")) {
					listaIdDePerguntas.add(r.getIdPergunta() + "");
				}
			}

			if (listaIdDePerguntas.size() == 1) {
				int idDaPergunta = listaReceitas.get(0).getIdPergunta();
				List<String> listaDeTopicosDaThread = mapDocumentoTopicos.get(idDaPergunta + "");

				for (int k = 1; k < listaDeTopicosDaThread.size(); k++) {
					// Pega a partir do segundo topico predominante na thread para tentar transferir
					// o link pra la
					String idDoTopico = listaDeTopicosDaThread.get(k);
					List<Receita> listaReceitasDoNovoTopico = cookbook.get(idDoTopico);
					// Nao vamos mover o link para um capitulo vazio para nao correr o risco de
					// deixar esse capitulo so com 1 link
					if (listaReceitasDoNovoTopico.size() == 0)
						continue;
					// adiciona a receita em outro topico
					listaReceitasDoNovoTopico.addAll(listaReceitas);
					// Zera o topico que tinha apenas 1 receitas
					cookbook.put(topicoIdOriginal, new ArrayList<Receita>());
					outFileParametros.println("link " + listaReceitas.get(0).getIdPergunta() + " - topicId: "
							+ topicoIdOriginal + " (" + mapTopicoTopTerms.get(topicoIdOriginal) + ") - movido para "
							+ idDoTopico + " (" + mapTopicoTopTerms.get(idDoTopico) + ")");
					break;
				}
			}
		}
	}

	private static void inicializaDadosApisManual(List<String[]> listaNomeApis, List<Integer> listaNroDeParesPorApi,
			List<Integer> listaCodigoDasRodadas, List<Integer> listaKLda,
			List<Integer> listaThresholdParaRanqueamentoApi) {
		String nameApis[] = { "android" };

		listaNomeApis.add(nameApis);
		listaNroDeParesPorApi.add(30000);
		listaCodigoDasRodadas.add(0);
		listaKLda.add(15);
		listaThresholdParaRanqueamentoApi.add(300);

	}

	private static void inicializaDadosApis(List<String[]> listaNomeApis, List<Integer> listaNroDeParesPorApi,
			List<Integer> listaCodigoDasRodadas, List<Integer> listaKLda,
			List<Integer> listaThresholdParaRanqueamentoApi) {
		try {
			ConexaoDB cbd = new ConexaoDB();
			// Conecta ao banco
			cbd.conectaAoBD("stackOfCookBooks");

			String query = ConsultasBD.consultaQAPairsTable();
			ResultSet rs = cbd.executaQuery(query);
			while (rs.next()) {
				String nameApis[] = rs.getString("NameApis").split("_");
				int qtde = rs.getInt("Qtde");
				int codigoDaRodada = rs.getInt("TestRunCode");
				int k_lda = rs.getInt("lda_k");
				int threshold_for_ranking = rs.getInt("threshold_for_ranking");

				listaNomeApis.add(nameApis);
				listaNroDeParesPorApi.add(qtde);
				listaCodigoDasRodadas.add(codigoDaRodada);
				listaKLda.add(k_lda);
				listaThresholdParaRanqueamentoApi.add(threshold_for_ranking);
			}
			cbd.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void inicializaCookbook(Map<String, List<Receita>> cookbook, int nroDeCapitulos) {

		for (int i = 0; i < nroDeCapitulos; i++) {
			List<Receita> listaDeReceitas = new ArrayList<Receita>();
			cookbook.put(i + "", listaDeReceitas);
		}

	}

	private static Receita constroiReceita(int idPergunta, int idResposta, int posicaoNoRank, double scoreDoPar,
			double percentDoTopicoDominante) {
		Receita r = null;
		try {
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();

			String q1 = ConsultasBD.consultaTitulo(idPergunta);
			ResultSet r1 = cbd.executaQuery(q1);
			r1.next();
			String tituloPergunta = r1.getString("title");

			q1 = ConsultasBD.consultaTags(idPergunta);
			r1 = cbd.executaQuery(q1);
			r1.next();
			String strTags = r1.getString("tags").replace("<", " ").replace(">", " ");

			q1 = ConsultasBD.consultaCorpo(idPergunta);
			r1 = cbd.executaQuery(q1);
			r1.next();
			String corpoPergunta = r1.getString("body");

			q1 = ConsultasBD.consultaCorpo(idResposta);
			r1 = cbd.executaQuery(q1);
			r1.next();
			String corpoResposta = r1.getString("body");

			cbd.close();

			r = new Receita(tituloPergunta, strTags, corpoPergunta, corpoResposta, idPergunta, idResposta,
					posicaoNoRank, scoreDoPar, percentDoTopicoDominante);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return r;
	}
}
