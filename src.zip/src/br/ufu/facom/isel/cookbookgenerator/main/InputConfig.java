package br.ufu.facom.isel.cookbookgenerator.main;

import com.martiansoftware.jsap.FlaggedOption;
import com.martiansoftware.jsap.JSAP;
import com.martiansoftware.jsap.stringparsers.EnumeratedStringParser;
import com.martiansoftware.jsap.stringparsers.FileStringParser;

/**
 * Created by marcmaia
 */
public class InputConfig {

    private LauncherMode launcherMode;
    private String api;
    private int nChapters;
    private int maxNumberThreadsAllowed;
    private int minNumberOfRecipes;
    private String outputDirectoryPath;

    
    
    public InputConfig() {}

    public String getAPI() {
        return api;
    }

    public void setAPI(String api) {
        this.api = api;
    }
    
    public LauncherMode getLauncherMode() {
        return launcherMode;
    }

    public void setLauncherMode(LauncherMode launcherMode) {
        this.launcherMode = launcherMode;
    }

    public int getNumberOfChapters() {
        return nChapters;
    }

    public void setNumberOfChapters(int n) {
        this.nChapters = n;
    }

    public int getMaxNumberThreadsAllowed() {
        return maxNumberThreadsAllowed;
    }

    public void setMaxNumberThreadsAllowed(int max) {
        maxNumberThreadsAllowed = max;
    }
    
    public void incMaxNumberThreadsAllowed(int n) {
        maxNumberThreadsAllowed += n;
    }

    public int getMinNumberOfRecipes() {
        return minNumberOfRecipes;
    }

    public void setMinNumberOfRecipes(int min) {
        minNumberOfRecipes = min;
    }

    public String getOutputDirectoryPath() {
        return outputDirectoryPath;
    }

    public void setOutputDirectoryPath(String outputDirectoryPath) {
        this.outputDirectoryPath = outputDirectoryPath;
    }

    public String toString () {
        return 
        "Launcher Mode              = " + launcherMode + "\n" +
        "API                        = " + api + "\n" +
        "Number of Chapters         = " + nChapters + "\n" +
        "Max number threads allowed = " + maxNumberThreadsAllowed + "\n" +
        "Min number of recipes      = " + minNumberOfRecipes + "\n" +
        "Output Path                = " +  outputDirectoryPath + "\n";
    }
}