package br.ufu.facom.isel.cookbookgenerator.main;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import com.martiansoftware.jsap.FlaggedOption;
import com.martiansoftware.jsap.Switch;
import com.martiansoftware.jsap.JSAP;
import com.martiansoftware.jsap.JSAPException;
import com.martiansoftware.jsap.JSAPResult;
import com.martiansoftware.jsap.stringparsers.EnumeratedStringParser;
import com.martiansoftware.jsap.stringparsers.FileStringParser;

import org.json.JSONObject;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by marcmaia
 */
public class Launcher {
    private static org.slf4j.Logger LOGGER = LoggerFactory.getLogger(Launcher.class);

    private InputConfig config;

    public Launcher(String[] args) throws JSAPException {
        JSAP jsap = this.initJSAP();
        JSAPResult arguments = this.parseArguments(args, jsap);

        this.initConfig(arguments);

        Logger logger = (Logger) LoggerFactory.getLogger("br.facom.ufu.isel");
        logger.setLevel(Level.DEBUG);
    }

    private void showUsage(JSAP jsap) {
        System.err.println();
        System.err.println("Usage: java -jar cookbookgenerator.jar <arguments>");
        System.err.println();
        System.err.println("Arguments:");
        System.err.println();
        System.err.println(jsap.getHelp());
    }

    private JSAPResult parseArguments(String[] args, JSAP jsap) {
        JSAPResult arguments = jsap.parse(args);
        if (!arguments.success()) {
            System.err.println();
            for (Iterator<?> errs = arguments.getErrorMessageIterator(); errs.hasNext();) {
                System.err.println("Error: " + errs.next());
            }
            this.showUsage(jsap);
            return null;
        }
        if (arguments.getBoolean("help"))
        	this.showUsage(jsap);
        return arguments;
    }

    private JSAP initJSAP() throws JSAPException {
        JSAP jsap = new JSAP();

        String launcherModeValues = "";
        for (LauncherMode mode : LauncherMode.values()) {
            launcherModeValues += mode.name()+";";
        }
        launcherModeValues = launcherModeValues.substring(0, launcherModeValues.length()-1);

        Switch s = new Switch("help");
        s.setShortFlag('h');
        s.setLongFlag("help");
        s.setHelp("Help on usage.");
        jsap.registerParameter(s);
        
        FlaggedOption opt = new FlaggedOption("launcherMode");
        opt.setShortFlag('m');
        opt.setLongFlag("launcherMode");
        opt.setRequired(false);
        opt.setDefault("one");
        opt.setAllowMultipleDeclarations(false);
        opt.setUsageName(launcherModeValues);
        opt.setStringParser(EnumeratedStringParser.getParser(launcherModeValues));
        opt.setHelp("Provide the launcher mode, which is the type of the cookbook generation mode: 'one' API or 'multiple' APIs. Only 'one' API available until now.");
        jsap.registerParameter(opt);

        opt = new FlaggedOption("api");
        opt.setLongFlag("api");
        opt.setRequired(true);
        opt.setAllowMultipleDeclarations(true);
        opt.setStringParser(JSAP.STRING_PARSER);
        opt.setHelp("Provide the acronym of the API to generate the cookbook for.");
        jsap.registerParameter(opt);
        
        opt = new FlaggedOption("nChapters");
        opt.setShortFlag('k');
        opt.setLongFlag("nChapters");
        opt.setRequired(false);
        opt.setDefault("15");
        opt.setAllowMultipleDeclarations(false);
        opt.setStringParser(JSAP.STRING_PARSER);
        opt.setHelp("Provide the initial desired number of chapter (Parameter K in the dissertation).");
        jsap.registerParameter(opt);

        opt = new FlaggedOption("minNumberOfRecipes");
        opt.setLongFlag("min_recipes");
        opt.setRequired(false);
        opt.setDefault("64");
        opt.setAllowMultipleDeclarations(true);
        opt.setStringParser(JSAP.STRING_PARSER);
        opt.setHelp("Provide the minimum number of recipes a cookbook should contain (Parameter threshold R in the dissertation).");
        jsap.registerParameter(opt);

        opt = new FlaggedOption("maxNumberThreadsAllowed");
        opt.setLongFlag("max_threads");
        opt.setRequired(false);
        opt.setDefault("200");
        opt.setAllowMultipleDeclarations(true);
        opt.setStringParser(JSAP.STRING_PARSER);
        opt.setHelp("Provide the maximum number of threads to be considered as initial search space (Parameter threshold maximumPositionAllowed in the dissertation).");
        jsap.registerParameter(opt);

        opt = new FlaggedOption("outputDirectory");
        opt.setShortFlag('o');
        opt.setLongFlag("output");
        opt.setRequired(false);
        opt.setDefault(System.getProperty("user.home"));
        opt.setAllowMultipleDeclarations(false);
        opt.setStringParser(FileStringParser.getParser().setMustBeDirectory(true).setMustExist(true));
        opt.setHelp("Provide an existing path to output an SQL file with the recipes");
        jsap.registerParameter(opt);

        return jsap;
    }

    private void initConfig(JSAPResult arguments) {
        this.config = new InputConfig();
        this.config.setAPI(arguments.getString("api"));
        this.config.setLauncherMode(LauncherMode.valueOf(arguments.getString("launcherMode").toUpperCase()));
        this.config.setNumberOfChapters(Integer.parseInt(arguments.getString("nChapters")));
        this.config.setMaxNumberThreadsAllowed(Integer.parseInt(arguments.getString("maxNumberThreadsAllowed")));
        this.config.setMinNumberOfRecipes(Integer.parseInt(arguments.getString("minNumberOfRecipes")));
        if (arguments.getFile("outputDirectory") != null) {
           this.config.setOutputDirectoryPath(arguments.getFile("outputDirectory").getAbsolutePath());
        }
    }

    protected void execute() {
        LOGGER.info("");
        new GenerationAlgorithm(config).generateCookbook();

    }

    public static void main(String[] args) throws Exception {
        Launcher launcher = new Launcher(args);
        launcher.execute();
    }

}
