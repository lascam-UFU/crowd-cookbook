package br.ufu.facom.isel.cookbookgenerator.main;

import java.io.File;

import org.apache.commons.lang3.time.FastDateFormat;

import br.ufu.facom.lsa.Lda.GerenciadorDeLDA;

public class LDAConfig {
	InputConfig inputConfig;
	public String pathForLDAFiles;
	
	public LDAConfig (InputConfig ic){
		inputConfig = ic;

		// Cria a pasta onde serao armazenadas os arquivos que participarao do LDA
		// String nomePasta = caminho + "/" + nomeAPIs + "_" + (consideraCodigo ? "1":
		// "0") + "_" + tipoArquivo + "_" + (consideraApenasComRespostaAceita ? "1":
		// "0") + "_" + (usaPreProcessamentoConvensional ? "1": "0");
		pathForLDAFiles = inputConfig.getOutputDirectoryPath() + "/" + inputConfig.getAPI() + "/lda/";
		pathForLDAFiles += FastDateFormat.getInstance("yyyy-MM-dd HH:mm").format(System.currentTimeMillis());
		File f = new File(pathForLDAFiles);
		f.mkdirs();
	}

	// Variavel que indica como aplicaremos o LDA
	// tipoDeAplicacaoDoLDA = 1 -> todas as threads how-to da api entrarao no LDA
	// tipoDeAplicacaoDoLDA = 2 -> apenas threads que possuem pares no top 30%
	// entrarao no LDA
	// tipoDeAplicacaoDoLDA = 3 -> apenas threads que possuem pares no top
	// menor(0.1*nroDeParesDaApi, 300)
	public int optionForLDACorpus = 1;

	/// Variaveis referentes aos filtros
	public boolean useCodeFilterInAnswer = true;
	public boolean useQuestionSizeFilter = true;
	public boolean useDeadLinkFilter = true;

	// Variavel que indica se serão considerados para cada API a
	// 1 -> valor absoluto, se posicaoMaximaDoParNoRanking = 100, so vai considerar
	// os 100 pares mais bem colocados no ranquamento de cada api
	// 2 -> valor relativo, se posicaoMaximaDoParNoRanking = 10, so vai considerar
	// os 10% pares mais bem colocados no ranquamento de cada api
	// 3 -> o usuario informa um threshold que sera um valor minimo da media
	// ponderada para o par ser considerada para o cookbook. So pode ser usado
	// quando tipoDeRanqueamento=2
	// int tipoDeSelecaoDePares = 2;
	// strParametros += "tipoDeSelecaoDePares: " + tipoDeSelecaoDePares + "\n";

	// Variavel que indica o tipo de ranqueamento que utilizaremos para selecionar
	// os pares para o cookbooks
	// tipoDeRanqueamento = 1 -> ranqueamento feito pelo ranklib
	// tipoDeRanqueamento = 2 -> ranqueamento original (gronud through)
	public int rankingType = 2;

	// Variavel que indica:
	// os top-k pares do ranquemanto que serao considerados para o cookbook
	// (tipoDeSelecaoDePares=1)
	// ou os x% melhores (tipoDeSelecaoDePares=2)
	// ou o threshold para selecao de pares (tipoDeSelecaoDePares=3)
	// double topParesInfo = 10;
	// strParametros += "topParesInfo: " + topParesInfo + "\n";
	public int posicaoMaximaASerConsiderada = 0;

	// Variavel que indica o nroMaximo de pares de uma mesma thread que poderao ser
	// considerados para serem incluidos no cookbook (Integer.maxvalue = sem limite)
	public int maxNumberOfPairsFromAThread = 1;

	// Variaveis referentes ao LDA
	// Caminho do sistema de arquivos onde iremos armazenar os arquivos gerados a
	// partir dos posts
	String path;

	// Variavel booleana para indicar se os trechos de codigo-fonte serao
	// considerados na construcao dos arquivos
	public  Boolean useCodeSnippets = false;

	// Variavel booleana para indicar se serao consideradas apenas as threads com
	// resposta aceita
	public Boolean useOnlyAcceptedAnswers = false;
	// Variavel para indicar a estrategia que adotaremos para construcao dos
	// arquivos (possui um dos valores de constantes definidas na classe)
	public int strategyLDACorpusConstruction = GerenciadorDeLDA.COMPLETE_THREAD;

	// Variavel booleana para indicar se o titulo da pergunta sera considerado na
	// construcao dos arquivos
	public Boolean useTitleInLDACorpus = true;

	// Variavel booleana para indicar se serao considerados bi-grans
	// se for true, os tokens finais produzidos serao tanto bigrans como unigrans
	public Boolean usaBigrams = true;

	// Variavel inteira que indica se iremos aplicar o LDA usando o
	// pre-processamento convencional(1), usando chunking(2) ou pegando apenas os
	// nouns(3)
	// se for true, usaremos o pre-processamento convencional de texto
	public int typeOfTextProcessingInLDA = 1;

	// Variavel boolena que indica se serao consideradas apeans threads do tipo HOW
	// no LDA
	// se for true, usaremos apenas threads cujo tipo da pergunta eh HOW
	public Boolean useOnlyHowtoInLDA = true;

	// Variavel que indica quantas vezes os tokens do titulo serao repetidos no
	// momento de produzir os arquivos para o LDA
	public int numberOfRepetitionsOfTitleInLDA = 1;
	// Variavel que contem o caminho do arquivo contendo o resultado da checkagem de
	// links feita no windows
//		String caminhoDoArquivoComLinkTestados = "/home/lucas/Dropbox/dados_dead_links/SO_links_linq_qt_awt_testados.txt";
	public String pathWithDeadLinks = "";
	// Variavel que indica o percentual (aderencia) minimo que a thread do par deve
	// ter para o mesmo poder ser considerado
	public double minAdherenceOfPairToTopic = 0.51;
	// Variavel que indica o numero de pares minimo requeido para estar num
	// cookbooks
	public int minNumberOfRecipes = 64;
	// Variavel usada para guardar o numero de pares do cookbook atual
}
