package br.ufu.facom.isel.cookbookgenerator.main;

/**
 * Created by marcmaia
 */
public enum LauncherMode {
    ONE, MULTIPLE
}