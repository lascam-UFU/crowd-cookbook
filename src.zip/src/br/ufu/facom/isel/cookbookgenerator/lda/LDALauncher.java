package br.ufu.facom.isel.cookbookgenerator.lda;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.time.FastDateFormat;

import br.facom.ufu.lsa.GeradorDeCookbooks.FiltrosParaCookbook.Filtros;
import br.ufu.facom.RanqueamentoDePares.ProduzArquivosParaParaLearningToRank;
import br.ufu.facom.isel.cookbookgenerator.main.InputConfig;
import br.ufu.facom.isel.cookbookgenerator.main.LDAConfig;
import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;
import br.ufu.facom.lsa.GeradorDeCookbooks.ComparatorScoreDoRanqueamento;
import br.ufu.facom.lsa.GeradorDeCookbooks.ComparatorScoreGroundThrough;
import br.ufu.facom.lsa.GeradorDeCookbooks.DadoRanqueamento;
import br.ufu.facom.lsa.Lda.DocTopicPair;
import br.ufu.facom.lsa.Lda.GerenciadorDeLDA;

public class LDALauncher {
	InputConfig config;
	LDAConfig ldaConfig;
	Filtros filtros;

	ConexaoDB cbd;
	PrintWriter outFileParametros;



	Map<String, Integer> mapScores;
	public Map<String, Integer> getMapScores () {
		return 	mapScores;
	}
	
	Map<String, DadoRanqueamento> mapDadosRanking;
	public Map<String, DadoRanqueamento> getMapDadosRanking () {
	     return mapDadosRanking;
	}
	
	// iteracoes: geralmente utilizadas de 1000-2000
	// <idDaThread, idDoTopicoDominanteNaThread>
	Map<String, List<DocTopicPair>> mapDocumentoTopicos = new HashMap<String, List<DocTopicPair>>();

	public Map<String, List<DocTopicPair>> getMapDocumentoTopicos() {
		return mapDocumentoTopicos;
	}

	// <idDoTopico, topTermsDoTopico>
	Map<String, String> mapTopicoTopTerms = new HashMap<String, String>();

	public Map<String, String> getMapTopicoTopTerms() {
		return mapTopicoTopTerms;
	}

	// Map que guarda para cada topico, a lista de documentos, ordenados de forma
	// decrescente pelo percentual
	Map<String, List<DocTopicPair>> mapTopicoDocumentos = new HashMap<String, List<DocTopicPair>>();

	public Map<String, List<DocTopicPair>> getMapTopicoDocumentos() {
		return mapTopicoDocumentos;
	}

	public LDALauncher(InputConfig inputConfig, LDAConfig ldaConfig, ConexaoDB cdb, PrintWriter p)  {
		this.config = inputConfig;
		this.ldaConfig = ldaConfig;
		this.outFileParametros = p;
		this.cbd = cdb;

		Filtros filtros = new Filtros(ldaConfig.pathWithDeadLinks);
		// map que guardara os scores de todos os posts do SO

		mapScores = new HashMap<String, Integer>();

		// Inicializa o map com o score de todos os posts do SO. Esse score sera usado
		// para calcular o valor da metrica groud through (media ponderada) para o caso
		// de tipoDeRanqueamento=2
		inicializaMapScores(mapScores, config.getAPI()); // modificado para buscar apenas 1 API
		System.out.println(mapScores.size());

		mapDadosRanking = new HashMap<String, DadoRanqueamento>();

		montaMapComDadosDoRanqueamento(mapDadosRanking, config.getAPI(), mapScores, ldaConfig.rankingType, cbd,
				ldaConfig.useCodeFilterInAnswer, ldaConfig.useQuestionSizeFilter, ldaConfig.useDeadLinkFilter, filtros,
				outFileParametros);
		
		cbd.close();

	}

	public void execute() {
		int maxNumberThreadsAllowed = config.getMaxNumberThreadsAllowed();

		// Vamos preencher a lista listaDadosRanqueamento com os pares do map
		// mapDadosRanking (o melhor par da thread que passou nos filtros)
		List<DadoRanqueamento> listaDadosRanqueamento = new ArrayList<DadoRanqueamento>(mapDadosRanking.values());
		fillListWithBestRankedPairs(listaDadosRanqueamento);
System.out.println("Terminei ranqueamento com melhores pares");
		// metodo responsavel por produzir os arquivos referentes aos posts
		// Verifica os pares que estão aptos a participarem do lda.
		// Ex.: se tipoDeAplicacaoDoLDA = 1, todas as threads entrarao no lda
		// Ex.: se tipoDeAplicacaoDoLDA = 2, verifica os pares que estão no top 30% do
		// ranking e as threads desses pares entrarao no lda
		GerenciadorDeLDA.produzArquivosPostsV2(config.getAPI(), ldaConfig.strategyLDACorpusConstruction,
				ldaConfig.useTitleInLDACorpus, ldaConfig.useCodeSnippets, ldaConfig.pathForLDAFiles,
				ldaConfig.useOnlyAcceptedAnswers, ldaConfig.typeOfTextProcessingInLDA, ldaConfig.useOnlyHowtoInLDA,
				ldaConfig.optionForLDACorpus, listaDadosRanqueamento, config.getMinNumberOfRecipes(), outFileParametros,
				ldaConfig.numberOfRepetitionsOfTitleInLDA);
System.out.println("Gerei corpus LDA");
		// outFileLinksTestados.close();

		// Depois de gerados os arquivos, iremos aplicar o LDA
		// alpha: um bom valor heuristicamente conhecido eh 50/numTopicos, por isso
		// passa 50 como alpha
		// beta: um bom valor utilizado eh 0.01

		GerenciadorDeLDA.aplicaLDA(ldaConfig, config.getNumberOfChapters(), 50.0, 0.01, 2000,
				ldaConfig.usaBigrams, mapDocumentoTopicos, mapTopicoDocumentos, mapTopicoTopTerms);
System.out.println("Terminei LDA");
	}

	private  void inicializaMapScores(Map<String, Integer> mapScores, String api) {
		try {
//			String query = ConsultasBD.consultaScoreDePosts();
			// Mudança para otimizar por API
			String query = ConsultasBD.consultaScoreDePostsAPI(api);
			ResultSet rs = cbd.executaQuery(query);
			while (rs.next()) {
				String idPost = rs.getString("id");
				int score = rs.getInt("score");
				mapScores.put(idPost, score);
				
				String queryAnswers = ConsultasBD.consultaScoreDeRespostasDadaAPergunta (Integer.parseInt(idPost));
				ResultSet rs2 = cbd.executaQuery(queryAnswers);
				while (rs2.next()) {
					String idAnswer = rs2.getString("id");
					int scoreAnswer = rs2.getInt("score");
					mapScores.put(idAnswer, scoreAnswer);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void fillListWithBestRankedPairs(List<DadoRanqueamento> listaDadosRanqueamento) {
		System.out.println("listaDadosRanqueamento.size(): " + listaDadosRanqueamento.size());
		outFileParametros.print("listaDadosRanqueamento.size(): " + listaDadosRanqueamento.size());
		outFileParametros.flush();

		// Criar o camparator de acordo com o tipo de ranqueametno considerado (1:score
		// produzido pelo ranklib; 2:score ground through)
		Comparator comp = null;
		if (ldaConfig.rankingType == 1)
			comp = new ComparatorScoreDoRanqueamento();
		else if (ldaConfig.rankingType == 2)
			comp = new ComparatorScoreGroundThrough();

		Collections.sort(listaDadosRanqueamento, comp);

		// Atualiza posicao no ranking
		for (int i = 0; i < listaDadosRanqueamento.size(); i++) {
			listaDadosRanqueamento.get(i).setPosicaoNoRank(i + 1);
		}

	}

	// Vamos montar o map com as informacoes da posicao dos pares no ranqueamento
	// feito usando a RankLib ou o ranqueamento pelo score (ground through)
	// <idPergunta, <dadoRanquemanto d melhor par que passou nos filtros de tamanho,
	// dead links and code>>

	// Monta o map com as informacoes de ranqueamento de cada um dos pares (ate o
	// momento este map tem todos os pares how-to da API)

	private static void montaMapComDadosDoRanqueamento(Map<String, DadoRanqueamento> mapDadosRanking, String nomeAPIs,
			Map<String, Integer> mapScores, int tipoDeRanqueamento, ConexaoDB cbd, boolean usaFiltroDeCodigoNaResposta,
			boolean usaFiltroDeTamanhoDaPergunta, boolean usaFiltroDeLinkMortos, Filtros filtros,
			PrintWriter outFileParametros) {
		try {

			int nroDeParesDescartadosPorFiltroDeCodigoNaResposta = 0;
			int nroDeParesDescartadosPorFiltroDeLinksNaResposta = 0;
			int nroDeParesDescartadosPorFiltroDeLinksNaPergunta = 0;
			int nroDeParesDescartadosPorFiltroDeTamanhoDaPergunta = 0;
			int nroDeParesDescartadosPorLimiteDaThread = 0;
			int nroTotalDeParesHowTODaAPI = 0;

			if (tipoDeRanqueamento == 1) {
				// Consultar codigo antigo da dissertacao
			} else if (tipoDeRanqueamento == 2) {
				ConexaoDB cbdStackCookbooks = new ConexaoDB();

				cbdStackCookbooks.conectaAoBD("stackOfCookBooks");
				String query = ConsultasBD.consultaPerguntasHowTo(nomeAPIs);
				ResultSet rs = cbdStackCookbooks.executaQuery(query);
				while (rs.next()) {
					nroTotalDeParesHowTODaAPI++;

  					String idPergunta = rs.getInt("QuestionId") + "";
					String idResposta = rs.getInt("AnswerId") + "";

					int scoreDaPergunta = mapScores.get(idPergunta);
					int scoreDaResposta = mapScores.get(idResposta);

					double mediaPonderada = ProduzArquivosParaParaLearningToRank.calculaMetricaAlvo(scoreDaPergunta,
							scoreDaResposta);

					// antes de incluir o objeto no ranking, vamos verificar se o mesmo passa nos
					// filtros de codigo-fonte, tamanho pergunta e dead-links
					String queryCorpo = ConsultasBD.consultaCorpo(Integer.parseInt(idResposta));
					ResultSet rsInt = cbd.executaQuery(queryCorpo);
					rsInt.next();
					String corpoDaResposta = rsInt.getString("body");

					queryCorpo = ConsultasBD.consultaCorpo(Integer.parseInt(idPergunta));
					rsInt = cbd.executaQuery(queryCorpo);
					rsInt.next();
					String corpoDaPergunta = rsInt.getString("body");

					if (usaFiltroDeCodigoNaResposta && !filtros.possuiCodigoFonte(corpoDaResposta)) {
						nroDeParesDescartadosPorFiltroDeCodigoNaResposta++;
						continue;
					}

					// Se estiver usando o filtro para verificar a presenca de dead links e a
					// resposta possui dead links, desconsidera o par
					if (usaFiltroDeLinkMortos && filtros.possuiLinksMortos(corpoDaResposta)) {
						nroDeParesDescartadosPorFiltroDeLinksNaResposta++;
						continue;
					}

					// Se estiver usando o filtro para verificar a presenca de dead links e a
					// pergunta possui dead links, desconsidera o par
					if (usaFiltroDeLinkMortos && filtros.possuiLinksMortos(corpoDaPergunta)) {
						nroDeParesDescartadosPorFiltroDeLinksNaPergunta++;
						continue;
					}

					// Se estiver usando o filtro para verificar a presenca de pergutas mto grandes
					// e a pergunta eh mto grande, desconsidera o par
					if (usaFiltroDeTamanhoDaPergunta && filtros.possuiPerguntaGrande(corpoDaPergunta, true)) {
						nroDeParesDescartadosPorFiltroDeTamanhoDaPergunta++;
						continue;
					}

					// caso tenha passado nos filtros, vamos verificar se aquele par eh o melhor ate
					// o momento para a thread
					// Se for e nao tiver nenhum par para a thread, simplesmente coloca o par la
					// Se for e tiver pares para a thread, tem que deixar soh o par com maior score
					DadoRanqueamento dr = new DadoRanqueamento(idResposta, idPergunta, 0, mediaPonderada);

					if (!mapDadosRanking.containsKey(idPergunta)) {
						mapDadosRanking.put(idPergunta, dr);
					} else {
						DadoRanqueamento drOld = mapDadosRanking.get(idPergunta);
						if (mediaPonderada > drOld.getScoreGoundThrough()) {
							// substituimos um par pelo atual pois ele possui score maior
							mapDadosRanking.put(idPergunta, dr);
						}
						// caso ja tenha algum par no map para a thread, ou o par antigo vai sair ou o
						// novo nao vai entrar, por isso incrementa
						nroDeParesDescartadosPorLimiteDaThread++;
					}
				}
			}

			outFileParametros.println("nroTotalDeParesHowTODaAPI: " + nroTotalDeParesHowTODaAPI);
			outFileParametros.println("nroDeParesDescartadosPorFiltroDeCodigoNaResposta: "
					+ nroDeParesDescartadosPorFiltroDeCodigoNaResposta);
			outFileParametros.println("nroDeParesDescartadosPorFiltroDeLinksNaResposta: "
					+ nroDeParesDescartadosPorFiltroDeLinksNaResposta);
			outFileParametros.println("nroDeParesDescartadosPorFiltroDeLinksNaPergunta: "
					+ nroDeParesDescartadosPorFiltroDeLinksNaPergunta);
			outFileParametros.println("nroDeParesDescartadosPorFiltroDeTamanhoDaPergunta: "
					+ nroDeParesDescartadosPorFiltroDeTamanhoDaPergunta);
			outFileParametros
					.println("nroDeParesDescartadosPorLimiteDaThread: " + nroDeParesDescartadosPorLimiteDaThread);
			outFileParametros.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
