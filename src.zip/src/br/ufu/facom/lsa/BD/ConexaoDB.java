/* 
 * Classe que representa a conexao com o banco de dados (MySQL) do Stack Overflow 
 */

package br.ufu.facom.lsa.BD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.sql.PreparedStatement;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import java.util.logging.Logger;
import java.util.logging.Level;

public class ConexaoDB {
	private Connection connect = null;
	// private Statement statement = null;
	private ResultSet resultSet = null;

	// Metodo que vai realizar a conexao com o BD
	public void conectaAoBD() throws SQLException, ClassNotFoundException {
        conectaAoBD("stackoverflow2018");
	}

//Metodo que vai realizar a conexao com o BD
	public void conectaAoBD(String nomeBanco) {//throws Exception {
		String bdUser = "blablabla";
		String bdPassword = "blablabla";
		int assignedPort=SSHConnection.getInstance().getAssignedPort();

		try {
			// This will load the MySQL driver, each DB has its own driver
			Class.forName("com.mysql.jdbc.Driver");
			// Setup the connection with the DB
			String strConnection = "jdbc:mysql://127.0.0.1:" + assignedPort+ "/" + nomeBanco + "?" + "user=" + bdUser +"&password="+bdPassword;
			System.out.println("Connecting to: " + strConnection);
			connect = DriverManager
					.getConnection(strConnection);

			// Statements allow to issue SQL queries to the database
			// statement = connect.createStatement();
		} catch (ClassNotFoundException e) {
			e.printStackTrace(); 
			close();
			System.exit(1);
		} catch (SQLException e) {
			e.printStackTrace();
			close();	
			System.exit(1);
		}
		
	}

	// Metodo responsavel por executar uma query
	public ResultSet executaQuery(String query) {
		try {
			Statement statement = connect.createStatement();
			resultSet = statement.executeQuery(query);
			return resultSet;
		} catch (Exception e) {
			e.printStackTrace();
			close();
		}
		return null;
	} // Result set get the result of the SQL query
		// resultSet = statement
		// .executeQuery("select body from stackOfMar2013.posts limit 10");

	// You need to close the resultSet
	public void close() {
		try {
			if (resultSet != null) {
				resultSet.close();
			}

			// if (statement != null) {
			// statement.close();
			// }

			if (connect != null) {
				connect.close();
			}
			if (SSHConnection.getInstance()!=null)
				SSHConnection.getInstance().disconnect();
		} catch (Exception e) {

		}
	}

	public PreparedStatement criaPreparedStatement(String query) {
		try {
			return connect.prepareStatement(query);
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return null;
	}

}