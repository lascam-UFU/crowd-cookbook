package br.ufu.facom.lsa.BD;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class SSHConnection {
    private static final SSHConnection INSTANCE = new SSHConnection();

    private SSHConnection() {
    	try {
    		jsch = new JSch();
    		Session session = jsch.getSession(hostUser, remoteHost, remotePort);
    		session.setPassword(hostPassword);
    		session.setConfig("StrictHostKeyChecking", "no");
    		System.out.println("Establishing Connection...");
    		session.connect();
    		assignedPort = session.setPortForwardingL(localBDPort, remoteHost, remoteBDPort);
    		System.out.println("localhost:" + assignedPort + " -> " + remoteHost + ":" + remoteBDPort);
    	} catch (Exception e) {
    		System.err.print(e);
    	}		
    }

    public static SSHConnection getInstance() {
        return INSTANCE;
    }

    public int getAssignedPort() {
    	return assignedPort;
    }
    
    public void disconnect () {
    	session.disconnect(); 
    }
    
    JSch jsch;
    Session session;
    int localBDPort = 4351;
	String hostUser = "user";
	String hostPassword = "password";
	String remoteHost = "200.131.206.140";
	int remotePort = 1026;
	int remoteBDPort = 3306;
	int assignedPort=0;
}
