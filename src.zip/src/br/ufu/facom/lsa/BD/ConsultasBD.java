/* 
 * Classe resposavel por manter as strings que representam as consultas que serao executadas no BD 
 */

package br.ufu.facom.lsa.BD;

import java.util.List;

import br.ufu.facom.lsa.Lda.GerenciadorDeLDA;
import br.ufu.facom.lsa.Lda.Main;

public class ConsultasBD {
	
	//metodo que ira retornar uma string contendo um select ao BD. A string sera formada com base nos parametros do metodo 
	public static String queryQuestions(String nameAPI, int docType, Boolean onlyWithAcceptedAnswer){
		
		String srtCats = "p.tags LIKE '%<" + nameAPI + ">%'";
		
		//Documento = Pergunta + Todas Respostas
		if(docType == GerenciadorDeLDA.COMPLETE_THREAD){
			
			if(!onlyWithAcceptedAnswer)
			
			return "SELECT p.id AS id_pergunta, p.id AS id_post, p.PostTypeId AS tipo_post , p.Body AS body , p.Body AS corpo_pergunta, p.Title AS titulo_pergunta " +
					"FROM posts p " +
					"WHERE p.PostTypeId = 1 AND " + srtCats;

			else
				return "(SELECT p.id AS id_pergunta, p.id AS id_post, p.PostTypeId AS tipo_post , p.Body AS body, p.Body AS corpo_pergunta, p.Title AS titulo_pergunta  " +
				"FROM posts p " +
				"WHERE p.PostTypeId = 1 AND " + srtCats + " AND p.AcceptedAnswerId IS NOT NULL) " +  
				"UNION " +
				"(SELECT pa.parentid AS id_pergunta, pa.id AS id_post, pa.PostTypeId AS tipo_post , pa.Body AS body , pq.Body AS corpo_pergunta, pq.Title AS titulo_pergunta " +
				"FROM posts pa INNER JOIN posts pq ON pa.parentid = pq.id " +
				"WHERE pq.PostTypeId = 1 AND pa.PostTypeId = 2 AND " + srtCats.replace("p.tags", "pq.tags") + ") "+
				" ORDER BY id_pergunta ";
		}
		
		
		return null;
		
	}
	
	public static String queryAnswersFromQuestion(String nameAPI, int idQuestion, int docType, Boolean onlyWithAcceptedAnswer){
		
		String srtCats = "p.tags LIKE '%<" + nameAPI + ">%'";
		
		//Documento = Pergunta + Todas Respostas
		if(docType == GerenciadorDeLDA.COMPLETE_THREAD){
			
			if(!onlyWithAcceptedAnswer)
			
			return "SELECT pa.id AS id_post, pa.PostTypeId AS tipo_post , pa.Body AS body " +
					"FROM posts pa  " +
					"WHERE pa.parentid = " + idQuestion + " AND pa.PostTypeId = 2  " ;

			else
				return "(SELECT p.id AS id_pergunta, p.id AS id_post, p.PostTypeId AS tipo_post , p.Body AS body, p.Body AS corpo_pergunta, p.Title AS titulo_pergunta  " +
				"FROM posts p " +
				"WHERE p.PostTypeId = 1 AND " + srtCats + " AND p.AcceptedAnswerId IS NOT NULL) " +  
				"UNION " +
				"(SELECT pa.parentid AS id_pergunta, pa.id AS id_post, pa.PostTypeId AS tipo_post , pa.Body AS body , pq.Body AS corpo_pergunta, pq.Title AS titulo_pergunta " +
				"FROM posts pa INNER JOIN posts pq ON pa.parentid = pq.id " +
				"WHERE pq.PostTypeId = 1 AND pa.PostTypeId = 2 AND " + srtCats.replace("p.tags", "pq.tags") + ") "+
				" ORDER BY id_pergunta ";
		}
		
		
		return null;
		
	}

	//metodo que ira retornar uma string contendo um select ao BD. A string sera formada com base nos parametros do metodo 
	public static String consultaThreads(String nomeAPI, int tipoDoc, Boolean consideraApenasComRespostaAceita){
		
		String srtCats = "p.tags LIKE '%<" + nomeAPI + ">%'";
		
		//Documento = Pergunta + Todas Respostas
		if(tipoDoc == GerenciadorDeLDA.COMPLETE_THREAD){
			
			if(!consideraApenasComRespostaAceita)
			
			return "(SELECT p.id AS id_pergunta, p.id AS id_post, p.PostTypeId AS tipo_post , p.Body AS body , p.Body AS corpo_pergunta, p.Title AS titulo_pergunta " +
					"FROM posts p " +
					"WHERE p.PostTypeId = 1 AND " + srtCats + ") " +  
					"UNION " +
					"(SELECT pa.parentid AS id_pergunta, pa.id AS id_post, pa.PostTypeId AS tipo_post , pa.Body AS body , pq.Body AS corpo_pergunta, pq.Title AS titulo_pergunta " +
					"FROM posts pa INNER JOIN posts pq ON pa.parentid = pq.id " +
					"WHERE pq.PostTypeId = 1 AND pa.PostTypeId = 2 AND " + srtCats.replace("p.tags", "pq.tags") + ") "+
					" ORDER BY id_pergunta "; 
			else
				return "(SELECT p.id AS id_pergunta, p.id AS id_post, p.PostTypeId AS tipo_post , p.Body AS body, p.Body AS corpo_pergunta, p.Title AS titulo_pergunta  " +
				"FROM posts p " +
				"WHERE p.PostTypeId = 1 AND " + srtCats + " AND p.AcceptedAnswerId IS NOT NULL) " +  
				"UNION " +
				"(SELECT pa.parentid AS id_pergunta, pa.id AS id_post, pa.PostTypeId AS tipo_post , pa.Body AS body , pq.Body AS corpo_pergunta, pq.Title AS titulo_pergunta " +
				"FROM posts pa INNER JOIN posts pq ON pa.parentid = pq.id " +
				"WHERE pq.PostTypeId = 1 AND pa.PostTypeId = 2 AND " + srtCats.replace("p.tags", "pq.tags") + ") "+
				" ORDER BY id_pergunta ";
		}
		
		
		return null;
		
	}
	
	public static String consultaThreadsPorIdsDePerguntas(int tipoArquivo,
			Boolean consideraApenasComRespostaAceita,
			List<String> listIdThreadsQuePossuemParesBemColocados) {

		String idPerguntas = " ('";
		for(int i=0; i< listIdThreadsQuePossuemParesBemColocados.size(); i++){
			idPerguntas += listIdThreadsQuePossuemParesBemColocados.get(i);
			if(i != listIdThreadsQuePossuemParesBemColocados.size()-1)
				idPerguntas += "','";
			else
				idPerguntas += "')";
		}
		
		// TODO Auto-generated method stub
		//Documento = Pergunta + Todas Respostas
		if(tipoArquivo == GerenciadorDeLDA.COMPLETE_THREAD){
			
			if(!consideraApenasComRespostaAceita)
			
			return "(SELECT p.id AS id_pergunta, p.id AS id_post, p.PostTypeId AS tipo_post , p.Body AS body , p.Body AS corpo_pergunta, p.Title AS titulo_pergunta " +
					"FROM posts p " +
					"WHERE p.PostTypeId = 1 AND p.id IN " + idPerguntas + ") " +  
					"UNION " +
					"(SELECT pa.parentid AS id_pergunta, pa.id AS id_post, pa.PostTypeId AS tipo_post , pa.Body AS body , pq.Body AS corpo_pergunta, pq.Title AS titulo_pergunta " +
					"FROM posts pa INNER JOIN posts pq ON pa.parentid = pq.id " +
					"WHERE pq.PostTypeId = 1 AND pa.PostTypeId = 2 AND pq.id IN " + idPerguntas + ") "+
					" ORDER BY id_pergunta "; 
			else
				return "(SELECT p.id AS id_pergunta, p.id AS id_post, p.PostTypeId AS tipo_post , p.Body AS body, p.Body AS corpo_pergunta, p.Title AS titulo_pergunta  " +
				"FROM posts p " +
				"WHERE p.PostTypeId = 1 AND p.id IN " + idPerguntas + " AND p.AcceptedAnswerId IS NOT NULL) " +  
				"UNION " +
				"(SELECT pa.parentid AS id_pergunta, pa.id AS id_post, pa.PostTypeId AS tipo_post , pa.Body AS body , pq.Body AS corpo_pergunta, pq.Title AS titulo_pergunta " +
				"FROM posts pa INNER JOIN posts pq ON pa.parentid = pq.id " +
				"WHERE pq.PostTypeId = 1 AND pa.PostTypeId = 2 AND pq.id IN " + idPerguntas + ") " +
				" ORDER BY id_pergunta ";
		}
		
		return null;
	}

	//Com how no titulo
	public static String consultaPerguntasComHowNoTitulo(String nomeAPI) {
		return "SELECT Id " +
		"FROM posts p " +
		"WHERE (p.PostTypeId = 1 AND p.AcceptedAnswerId IS NOT NULL AND p.title LIKE '%how%'  AND p.tags LIKE '%<" + nomeAPI + ">%')";
	}
	
	//Com how no corpo
	public static String consultaPerguntasComHowNoCorpo(String nomeAPI) {
		return "SELECT Id " +
		"FROM posts p " +
		"WHERE (p.PostTypeId = 1 AND p.AcceptedAnswerId IS NOT NULL AND p.body LIKE '%how%'  AND p.tags LIKE '%<" + nomeAPI + ">%')";
	}

	//Sem How no titulo e no corpo
	public static String consultaPerguntasSemHow(String nomeAPI) {
		return "SELECT Id " +
		"FROM posts p " +
		"WHERE (p.PostTypeId = 1 AND p.AcceptedAnswerId IS NOT NULL AND p.title NOT LIKE '%how%' AND p.body NOT LIKE '%how%' AND p.tags LIKE '%<" + nomeAPI + ">%')";

	}
	
	//Select para recuperar todas as perguntas relacionadas a API em questao
	public static String consultaPerguntas(String nomeAPI) {
		return "SELECT Id, Title, Body " +
		"FROM posts p " +
		"WHERE (p.PostTypeId = 1 AND p.tags LIKE '%<" + nomeAPI + ">%')";

	}

	//Select para recuperar os corpos dos posts que contem codigo fonte
	public static String consultaCorpoComCodigo(String nomeAPI) {
		String condicaoAPI = "";
		if(!nomeAPI.equals(""))
			condicaoAPI = "AND p.tags LIKE '%<" + nomeAPI + ">%'";
		
		//return "SELECT Id, Body, PostTypeId, Score " + 
		//"FROM posts p " + 
		//"WHERE p.Body like '%<pre><code>%' " + condicaoAPI;
		
		
		return "(SELECT p.id id_pergunta, p.id id_post, p.Body body, p.PostTypeId tipo_post , p.Score score, p.Tags tags, p.Title title, p.ViewCount viewcount, u.Reputation reputation " +
		"FROM posts p LEFT JOIN users u ON p.OwnerUserId = u.id " +
		"WHERE p.PostTypeId = 1 " + condicaoAPI + ")" +  
		"UNION " +
		"(SELECT pa.parentid id_pergunta, pa.id id_post, pa.Body body, pa.PostTypeId tipo_post, pa.Score score, pq.Tags tags, pq.Title title, pq.ViewCount viewcount, u.Reputation reputation " +
		"FROM posts pa INNER JOIN posts pq ON pa.parentid = pq.id LEFT JOIN users u ON pa.OwnerUserId = u.id " +
		"WHERE pq.PostTypeId = 1 AND pa.PostTypeId = 2 " + condicaoAPI.replace("p.tags", "pq.tags") + ")" + 
		" ORDER BY id_pergunta ";
	}

	//Select para recuperar todos os ids de perguntas que possuem resposta
	public static String consultaPerguntasComResposta() {
		return "SELECT p.id id " +
		"FROM posts p " +
		"WHERE p.PostTypeId = 1 AND p.id IN " +
		"(SELECT p1.parentid " +
		"FROM posts p1 " + 
		"WHERE p1.PostTypeId = 2)";
	}
	
	//Select para recuperar, dado o id de uma pergunta o tempo (em segundos) gasto para a primeira resposta
	public static String consultaTempoAtePrimeiraResposta(int idPergunta) {
		return "SELECT TIMESTAMPDIFF(SECOND, (SELECT p.creationdate FROM posts p WHERE id = " + idPergunta + "), MIN(p.creationdate)) tempo " +
		"FROM posts p " +
		"WHERE p.PostTypeId = 2 AND p.parentid = " + idPergunta;
	}

	public static String consultaPerguntasComRespostaAceita() {
		return "SELECT p.id id, p.AcceptedAnswerId idResposta " +
		"FROM posts p " +
		"WHERE p.PostTypeId = 1 AND p.AcceptedAnswerId IS NOT NULL";
	}

	public static String consultaTempoAteRespostaAceita(int idPergunta, int idResposta) {
		return "SELECT TIMESTAMPDIFF(SECOND, (SELECT p.creationdate FROM posts p WHERE id = " + idPergunta + "), p.creationdate) tempo " +
		"FROM posts p " +
		"WHERE p.PostTypeId = 2 AND p.id = " + idResposta;
	}

	public static String consultaVerificaPerguntasEditadasPorUsuarioComAltaReputacao(int idPergunta, int thresholdReputacao) {
		return "SELECT count(DISTINCT ph.postid) contador " +
		"FROM posthistory ph INNER JOIN users u ON ph.userid = u.id INNER JOIN posts p ON ph.postid = p.id " +
		"WHERE p.id = " + idPergunta + " AND p.posttypeid = 1 AND u.reputation >= " + thresholdReputacao + " AND ph.userid <> p.owneruserid";
	}
	
	public static String consultaCorpo(int idPost) {
		return "SELECT p.body body " +
		"FROM posts p " +
		"WHERE p.id = " + idPost;
	}
	
	public static String consultaTitulo(int idPost) {
		return "SELECT p.title title " +
		"FROM posts p " +
		"WHERE p.id = " + idPost;
	}
	
	public static String consultaTags(int idPost) {
		return "SELECT p.tags tags " +
		"FROM posts p " +
		"WHERE p.id = " + idPost;
	}
	
	public static String consultaOwneruserid(int idPost) {
		return "SELECT owneruserid " +
				"FROM posts " +
				"where id = " + idPost;
	}

	public static String consultaFavoriteCount(int idPost) {
		return "SELECT p.favoriteCount favoriteCount " +
		"FROM posts p " +
		"WHERE p.id = " + idPost;
	}

	public static String consultaScore(int idPost) {
		return "SELECT p.score score " +
		"FROM posts p " +
		"WHERE p.id = " + idPost;
	}

	public static String consultaComentarios(int idPost) {
		return "SELECT c.text comentario " +
		"FROM comments c " +
		"WHERE c.postid = " + idPost;
	}

	//Select para recuperar um nro aleatorios de comentarios
	public static String consultaComentariosAleatorios(int nroComentarios) {
		return "SELECT c.text texto, c.postid postid " +
		"FROM comments c " +
		"ORDER BY RAND() " +
		"LIMIT " + nroComentarios;
	}
	
	//Select para calcular o nro de dias desde o registro de um usuario autor do post cujo id eh recebido como parametro
	public static String consultaNroDeDiasDesdeORegistro(int idUser){
		return "SELECT TIMESTAMPDIFF(DAY, u.creationdate, (SELECT r.referencedate FROM referencedate r)) tempo " + 
		"FROM users u " +
		"WHERE u.id = " + idUser;
	}
	
	//Select para calcular o nro de dias desde o ultimo acesso de um usuario autor do post cujo id eh recebido como parametro
	public static String consultaNroDeDiasDesdeOUltimoAcesso(int idUser){
		return "SELECT TIMESTAMPDIFF(DAY, u.lastaccessdate, (SELECT r.referencedate FROM referencedate r)) tempo " + 
		"FROM users u " +
		"WHERE u.id = " + idUser;
	}

	public static String consultaNroDeBadges(int idUser) {
		return "SELECT count(*) nroBadges " + 
		"FROM badges b " +
		"WHERE b.userid = " + idUser;
	}

	public static String consultaNroTotalDeComentarios(int idUser) {
		return "SELECT count(*) nroComentarios " + 
		"FROM comments c " +
		"WHERE c.userid = " + idUser;
	}

	public static String consultaNroDeEdicoesAPerguntas(int idUser) {
		//estou considerando como edicao de resposta apenas (5 - Edit body)
		return "SELECT count(*) nroEdicoesAPerguntas " + 
		"FROM posthistory ph INNER JOIN posts p ON p.id = ph.postid " +
		"WHERE ph.userid = " + idUser + " AND  (ph.PostHistoryTypeId = 4 OR ph.PostHistoryTypeId = 5 OR ph.PostHistoryTypeId = 6) AND p.PostTypeId = 1";
	}
	
	public static String consultaNroDeEdicoesARespostas(int idUser) {
		//estou considerando como edicao de resposta apenas (5 - Edit body)
		return "SELECT count(*) nroEdicoesARespostas " + 
		"FROM posthistory ph INNER JOIN posts p ON p.id = ph.postid " +
		"WHERE ph.userid = " + idUser + " AND ph.PostHistoryTypeId = 5 AND p.PostTypeId = 2";
	}

	public static String consultaNroDeRespostasPostadas(int idUser) {
		return "SELECT count(*) nroRespostasPostadas " + 
		"FROM posts p " +
		"WHERE p.owneruserid = " + idUser + " AND p.PostTypeId = 2";
	}

	public static String consultaNroDePerguntasPostadas(int idUser) {
		return "SELECT count(*) nroPerguntasPostadas " + 
		"FROM posts p " +
		"WHERE p.owneruserid = " + idUser + " AND p.PostTypeId = 1";
	}

	public static String consultaNroDePerguntasPostadasComRespostaAceita(int idUser) {
		return "SELECT count(*) nroPerguntasPostadasComRespostaAceita " + 
		"FROM posts p " +
		"WHERE p.owneruserid = " + idUser + " AND p.PostTypeId = 1 AND p.acceptedanswerid IS NOT NULL";
	}

	public static String consultaRankingPerguntas() {
		return "SELECT p.owneruserid idUser, COUNT(*) AS contagem " +
		"FROM posts p " +
		"WHERE p.PostTypeId = 1 AND p.owneruserid IS NOT NULL " +
		"GROUP BY p.owneruserid " +
		"ORDER BY contagem DESC";
	}

	public static String consultaRankingRespostas() {
		return "SELECT p.owneruserid idUser, COUNT(*) AS contagem " +
		"FROM posts p " +
		"WHERE p.PostTypeId = 2 AND p.owneruserid IS NOT NULL " +
		"GROUP BY p.owneruserid " +
		"ORDER BY contagem DESC";
	}

	public static String consultaTagsDosPosts() {
		return "SELECT DISTINCT(tagid) " +
		"FROM tags_new";
	}

	public static String consultaNumeroDeCategoriasRepondidasPorUsuarios() {
		return "SELECT p.owneruserid idUser, COUNT(DISTINCT t.tagid) nroCats " +
			"FROM tags_new t INNER JOIN posts p ON t.postid = p.parentid AND p.owneruserid IS NOT NULL " +
			"GROUP BY p.owneruserid";
	}
	
	public static String consultaNumeroDeCategoriasPerguntadasPorUsuarios() {
		return "SELECT p.owneruserid idUser, COUNT(DISTINCT t.tagid) nroCats " +
			"FROM tags_new t INNER JOIN posts p ON t.postid = p.id AND p.owneruserid IS NOT NULL " +
			"GROUP BY p.owneruserid";
	}

	public static String consultaNroEdicoesNaResposta(int idResposta) {
		return "SELECT count(*) nroEdicoesNAResposta " + 
		"FROM posthistory ph " +
		"WHERE ph.postid = " + idResposta + " AND ph.PostHistoryTypeId = 5";
	}
	
	public static String consultaNroEdicoesNaPergunta(int idPergunta) {
		return "SELECT count(*) nroEdicoesNAPergunta " + 
		"FROM posthistory ph " +
		"WHERE ph.postid = " + idPergunta + " AND (ph.PostHistoryTypeId = 4 OR ph.PostHistoryTypeId = 5 OR ph.PostHistoryTypeId = 6)";
	}

	public static String consultaIdadePost(int idPost) {
		return "SELECT TIMESTAMPDIFF(DAY, p.creationdate, (select r.referencedate from referencedate r)) idade " + 
		"FROM posts p " +
		"WHERE p.id = " + idPost;
	}

	public static String consultaNroUsuariosQueEditaramAResposta(int idResposta) {
		return "SELECT count(DISTINCT ph.userid) nroUsers " + 
		"FROM posthistory ph " +
		"WHERE ph.postid = " + idResposta + " AND ph.PostHistoryTypeId = 5";
	}
	
	public static String consultaNroUsuariosQueEditaramAPergunta(int idResposta) {
		return "SELECT count(DISTINCT ph.userid) nroUsers " + 
		"FROM posthistory ph " +
		"WHERE ph.postid = " + idResposta + " AND (ph.PostHistoryTypeId = 4 OR ph.PostHistoryTypeId = 5 OR ph.PostHistoryTypeId = 6)";
	}

	public static String consultaNroDeEdicoesPorUsuarioNaPergunta(int idPergunta) {
		return "SELECT ph.userid userid, COUNT(*) nroEdicoesUser " +
		"FROM posthistory ph " + 
		"WHERE ph.postid = " + idPergunta + " AND (ph.PostHistoryTypeId = 4 OR ph.PostHistoryTypeId = 5 OR ph.PostHistoryTypeId = 6) " +
		"GROUP BY ph.userid";  
	}
	
	public static String consultaNroDeEdicoesPorUsuarioNaResposta(int idResposta) {
		return "SELECT ph.userid userid, COUNT(*) nroEdicoesUser " +
		"FROM posthistory ph " + 
		"WHERE ph.postid = " + idResposta + " AND ph.PostHistoryTypeId = 5 " +
		"GROUP BY ph.userid";  
	}

	public static String consultaNroDeRespostasPostadasAntes(int idPergunta, int idResposta) {
		return "SELECT COUNT(*) nroRespostas " +
		"FROM posts p " +
		"WHERE p.parentid = " + idPergunta + " AND p.creationdate < (SELECT creationdate FROM posts WHERE id = " + idResposta + ")";
	}

	public static String consultaNroDeRespostasPostadasAPergunta(int idPergunta) {
		return "SELECT COUNT(*) nroRespostas " +
		"FROM posts p " +
		"WHERE p.parentid = " + idPergunta;
	}

	public static String consultaNroDeComentariosDoPost(int idPost) {
		return "SELECT COUNT(*) nroComentarios " + 
		"FROM comments " +
		"WHERE postid = " + idPost;
	}

	public static String consultaNroDeUsuariosQuemComentaramPost(int idPost) {
		return "SELECT COUNT(DISTINCT userid) nroUsuarios " + 
		"FROM comments " +
		"WHERE postid = " + idPost;
	}

	public static String consultaNroDeComentariosPorResposta(int idAnswerer) {
		return "SELECT COUNT(*) nroComentarios " +
		"FROM comments c INNER JOIN posts p ON c.postid = p.id " +  
		"WHERE p.owneruserid = " + idAnswerer + " AND p.posttypeid = 2 " +
		"GROUP BY p.id";
	}

	public static String consultaNroDeComentariosPorPergunta(int idAnswerer) {
		return "SELECT COUNT(*) nroComentarios " +
		"FROM comments c INNER JOIN posts p ON c.postid = p.id " +  
		"WHERE p.owneruserid = " + idAnswerer + " AND p.posttypeid = 1 " +
		"GROUP BY p.id";
	}

	public static String consultaNroDeRespostasPorPergunta(int idAnswerer) {
		return "SELECT COUNT(*) nroRespostas " +
		"FROM posts pa INNER JOIN posts pq ON pa.parentid = pq.id " +
		"WHERE pq.owneruserid = " + idAnswerer + " " +
		"GROUP BY pq.id";
	}

	public static String consultaCategoriasDaPergunta(int idPergunta) {
		return "SELECT tagid " +
		"FROM tags_new " +
		"WHERE postid = " + idPergunta;
	}

	public static String consultaNroDePerguntasPostadasPorCategoria(int idAnswerer, String categoria) {
		return "SELECT COUNT(*) nroPerguntas " +
		"FROM posts " + 
		"WHERE owneruserid = " + idAnswerer + " AND tags LIKE '%<" + categoria + ">%'"; 
	}

	public static String consultaNroDeRespostasPostadasPorCategoria(int idAnswerer, String categoria) {
		return "SELECT COUNT(*) nroRespostas " +
		"FROM posts pa INNER JOIN posts pq ON pa.parentid = pq.id " +
		"WHERE pa.owneruserid = " + idAnswerer + " AND pq.tags LIKE '%<" + categoria + ">%'"; 
	}

	public static String consultaNroDeRespostasDeUsuarioQueForamAceitas(int idAnswerer) {
		return "SELECT COUNT(*) nroRespostasQueForamAceitas " +
		 "FROM posts pa INNER JOIN posts pq ON pa.id = pq.acceptedanswerid " +
		 "WHERE pa.owneruserid = " + idAnswerer; 
	}

	public static String consultaNroDeUpvotesEmPerguntasDeUsuario(int idAnswerer) {
		return "SELECT COUNT(*) nroUpvotes " +
		"FROM posts p INNER JOIN votes v  ON p.id = v.postid " +
		"WHERE p.owneruserid = " + idAnswerer + " AND p.posttypeid = 1 AND v.votetypeid = 2";
	}

	public static String consultaNroDeDownvotesEmPerguntasDeUsuario(int idAnswerer) {
		return "SELECT COUNT(*) nroDownvotes " +
		"FROM posts p INNER JOIN votes v  ON p.id = v.postid " +
		"WHERE p.owneruserid = " + idAnswerer + " AND p.posttypeid = 1 AND v.votetypeid = 3";
	}

	public static String consultaNroDeUpvotesEmRespostasDeUsuario(int idAnswerer) {
		return "SELECT COUNT(*) nroUpvotes " +
		"FROM posts p INNER JOIN votes v  ON p.id = v.postid " +
		"WHERE p.owneruserid = " + idAnswerer + " AND p.posttypeid = 2 AND v.votetypeid = 2";
	}

	public static String consultaNroDeDownvotesEmRespostasDeUsuario(int idAnswerer) {
		return "SELECT COUNT(*) nroDownvotes " +
		"FROM posts p INNER JOIN votes v  ON p.id = v.postid " +
		"WHERE p.owneruserid = " + idAnswerer + " AND p.posttypeid = 2 AND v.votetypeid = 3";
	}

	public static String consultaIdUsuarios() {
		return "SELECT DISTINCT id " +
		"FROM users";
	}
	
	public static String consultaNroDeRespostasQueForamAceitasGeral() {
		return "SELECT pa.owneruserid idUser, COUNT(*) nroRespostasQueForamAceitasPorUsuario " +
		 "FROM posts pa INNER JOIN posts pq ON pa.id = pq.acceptedanswerid " +
		 "WHERE pa.owneruserid IS NOT NULL " +
		 "GROUP BY pa.owneruserid"; 
	}
	
	public static String consultaNroDeUpvotesEmPerguntaGeral() {
		return "SELECT p.owneruserid idUser, COUNT(*) nroUpvotesPorUsuario " +
		"FROM posts p INNER JOIN votes v  ON p.id = v.postid " +
		"WHERE p.owneruserid IS NOT NULL AND p.posttypeid = 1 AND v.votetypeid = 2 " +
		"GROUP BY p.owneruserid";
	}
	
	public static String consultaNroDeDownvotesEmPerguntasGeral() {
		return "SELECT p.owneruserid idUser, COUNT(*) nroDownvotesPorUsuario " +
		"FROM posts p INNER JOIN votes v  ON p.id = v.postid " +
		"WHERE p.owneruserid IS NOT NULL AND p.posttypeid = 1 AND v.votetypeid = 3 " +
		"GROUP BY p.owneruserid";
	}

	public static String consultaNroDeUpvotesEmRespostasGeral() {
		return "SELECT p.owneruserid idUser, COUNT(*) nroUpvotesPorUsuario " +
		"FROM posts p INNER JOIN votes v  ON p.id = v.postid " +
		"WHERE p.owneruserid IS NOT NULL AND p.posttypeid = 2 AND v.votetypeid = 2 " +
		"GROUP BY p.owneruserid";
	}

	public static String consultaNroDeDownvotesEmRespostasGeral() {
		return "SELECT p.owneruserid idUser, COUNT(*) nroDownvotesPorUsuario " +
		"FROM posts p INNER JOIN votes v  ON p.id = v.postid " +
		"WHERE p.owneruserid IS NOT NULL AND p.posttypeid = 2 AND v.votetypeid = 3 " +
		"GROUP BY p.owneruserid";
	}

	public static String consultaNroDeRespostasQueForamAceitasPorCat(String categoria) {
		return "SELECT pa.owneruserid idUser, COUNT(*) nroRespostasQueForamAceitasPorUsuario " +
		"FROM tags_new t INNER JOIN posts pa ON t.postid = pa.parentid INNER JOIN posts pq ON pa.parentid = pq.id " +
		"WHERE t.tagid = '" + categoria + "' AND pa.owneruserid IS NOT NULL AND pq.acceptedanswerid = pa.id " +
		"GROUP BY pa.owneruserid";  
	}
	
	public static String consultaNroDeUpvotesEmPerguntaPorCat(String categoria) {
		return "SELECT p.owneruserid idUser, COUNT(*) nroUpvotesPorUsuario " +
		"FROM posts p INNER JOIN votes v  ON p.id = v.postid " +
		"WHERE p.owneruserid IS NOT NULL AND p.posttypeid = 1 AND v.votetypeid = 2 AND p.tags LIKE '%<" + categoria + ">%'" +
		"GROUP BY p.owneruserid";
	}
	
	public static String consultaNroDeDownvotesEmPerguntasPorCat(String categoria) {
		return "SELECT p.owneruserid idUser, COUNT(*) nroDownvotesPorUsuario " +
		"FROM posts p INNER JOIN votes v  ON p.id = v.postid " +
		"WHERE p.owneruserid IS NOT NULL AND p.posttypeid = 1 AND v.votetypeid = 3 AND p.tags LIKE '%<" + categoria + ">%'" +
		"GROUP BY p.owneruserid";
	}

	public static String consultaNroDeUpvotesEmRespostasPorCat(String categoria) {
		return "SELECT pa.owneruserid idUser, COUNT(*) nroUpvotesPorUsuario " +
		"FROM posts pa INNER JOIN votes v  ON pa.id = v.postid INNER JOIN posts pq ON pa.parentid = pq.id " +
		"WHERE pa.owneruserid IS NOT NULL AND pa.posttypeid = 2 AND v.votetypeid = 2 AND pq.tags LIKE '%<" + categoria + ">%'" +
		"GROUP BY pa.owneruserid";
	}

	public static String consultaNroDeDownvotesEmRespostasPorCat(String categoria) {
		return "SELECT pa.owneruserid idUser, COUNT(*) nroDownvotesPorUsuario " +
		"FROM posts pa INNER JOIN votes v  ON pa.id = v.postid INNER JOIN posts pq ON pa.parentid = pq.id " +
		"WHERE pa.owneruserid IS NOT NULL AND pa.posttypeid = 2 AND v.votetypeid = 3 AND pq.tags LIKE '%<" + categoria + ">%'" +
		"GROUP BY pa.owneruserid";
	}

	public static String consultaNroDeEditSugeridos(int idAnswerer) {
		return "SELECT count(*) nroEditsSugeridos " +
		"FROM suggestededits " +
		"WHERE proposinguser = " + idAnswerer;
	}

	public static String consultaNroDeEditSugeridosAprovados(int idAnswerer) {
		return "SELECT count(*) nroEditsSugeridos " +
		"FROM suggestededits " +
		"WHERE proposinguser = " + idAnswerer + " AND approvaldate <> -1";
	}

	public static String consultaNroDeEditSugeridosRejeitados(int idAnswerer) {
		return "SELECT count(*) nroEditsSugeridos " +
		"FROM suggestededits " +
		"WHERE proposinguser = " + idAnswerer + " AND rejectiondate <> -1";
	}

	public static String consultaNroDeEditSugeridosAPost(int idPost) {
		return "SELECT count(*) nroEditsSugeridos " +
		"FROM suggestededits " +
		"WHERE postid = " + idPost;
	}

	public static String consultaNroDeUsuariosQueSugeriramEdicoes(int idResposta, int idPergunta) {
		return "SELECT count(DISTINCT proposinguser) nroUsuarios " +
		"FROM suggestededits " +
		"WHERE (postid = " + idResposta + " OR postid = " + idPergunta + ") AND proposinguser <> -2";
	}

	public static String consultaNroDeEditsSugeridosAprovadosPorPost(int idPost) {
		return "SELECT count(*) nroEditsSugeridos " +
		"FROM suggestededits " +
		"WHERE postid = " + idPost + " AND approvaldate <> -1";
	}
	
	public static String consultaNroDeEditsSugeridosRejeitadosPorPost(int idPost) {
		return "SELECT count(*) nroEditsSugeridos " +
		"FROM suggestededits " +
		"WHERE postid = " + idPost + " AND rejectiondate <> -1";
	}

	public static String consultaScoreRecebidoPorPerguntar(int idUsuario) {
		return "SELECT SUM(score) score " +
		"FROM posts " +
		"WHERE owneruserid = " + idUsuario + " AND posttypeid = 1";
	}
	
	public static String consultaScoreRecebidoPorResponder(int idUsuario) {
		return "SELECT SUM(score) score " +
		"FROM posts " +
		"WHERE owneruserid = " + idUsuario + " AND posttypeid = 2";
	}

	public static String consultaScoreRecebidoPorPerguntarGeral() {
		return "SELECT owneruserid, SUM(score) score " +
		"FROM posts " +
		"WHERE posttypeid = 1 " + 
		"GROUP BY owneruserid";
	}
	
	public static String consultaScoreRecebidoPorResponderGeral() {
		return "SELECT owneruserid, SUM(score) score " +
		"FROM posts " +
		"WHERE posttypeid = 2 " + 
		"GROUP BY owneruserid";
	}
	
	public static String consultaScoreRecebidoPorPerguntarPorCat(String categoria) {
		return "SELECT pq.owneruserid idUser, SUM(pq.score) score " +
		"FROM tags_new t INNER JOIN posts pq ON t.postid = pq.id " +
		"WHERE t.tagid = '" + categoria + "' AND pq.owneruserid IS NOT NULL " +
		"GROUP BY pq.owneruserid " + 
		"ORDER BY score DESC";
	}
	
	public static String consultaScoreRecebidoPorResponderPorCat(String categoria) {
		return "SELECT pa.owneruserid idUser, SUM(pa.score) score " +
		"FROM tags_new t INNER JOIN posts pq ON t.postid = pq.id INNER JOIN posts pa ON pq.id = pa.parentid " +
		"WHERE t.tagid = '" + categoria + "' AND pa.owneruserid IS NOT NULL " +
		"GROUP BY pa.owneruserid " + 
		"ORDER BY score DESC";
	}

	public static String consultaReputacaoDeEditoresDeResposta(int idResposta) {
		return "SELECT DISTINCT u.id idUser, u.reputation reputacao " +
		"FROM posthistory ph INNER JOIN users u ON ph.userid = u.id " +
		"WHERE ph.postid = " + idResposta + " AND ph.PostHistoryTypeId = 5"; 
	}
	
	public static String consultaReputacaoDeEditoresDePergunta(int idPergunta) {
		return "SELECT DISTINCT u.id idUser, u.reputation reputacao " +
		"FROM posthistory ph INNER JOIN users u ON ph.userid = u.id " +
		"WHERE ph.postid = " + idPergunta + " AND (ph.PostHistoryTypeId = 4 OR ph.PostHistoryTypeId = 5 OR ph.PostHistoryTypeId = 6)"; 
	}
	
	public static String consultaReputacaoDeUsuario(int idUser) {
		return "SELECT u.reputation reputacao " +
		"FROM users u " +
		"WHERE u.id = " + idUser; 
	}

	public static String consultaEhRespostaAceita(int idResposta) {
		return "SELECT COUNT(*) ehAceita " +
		"FROM  posts " + 
		"WHERE acceptedanswerid = " + idResposta; 
	}

	public static String consultaViewCount(int idPergunta) {
		return "SELECT viewCount " +
		"FROM posts " +
		"WHERE id = " + idPergunta;
	}

	public static String consultaPerguntasAleatoria() {
		return "SELECT id, title, body, owneruserid " + 
		"FROM posts " + 
		"WHERE posttypeid = 1 AND answercount > 1 " + 
		"ORDER BY RAND()";
	}

	public static String consultaRespostasDePergunta(int idPergunta) {
		return "SELECT id, body, owneruserid, score " + 
		"FROM posts " + 
		"WHERE parentid = " +  idPergunta;
	}
	
	public static String consultaRespostasDePerguntaComOrdemAleatoria(int idPergunta) {
		return "SELECT id, body, owneruserid " + 
		"FROM posts " + 
		"WHERE parentid = " +  idPergunta + " " + 
		"ORDER BY RAND()";
	}

	public static String consultaTagsLib() {
		return "SELECT TagName " +
		"FROM tagsdescription " +
		"WHERE Desciption LIKE '%library%' OR Desciption LIKE '%framework%' OR Desciption LIKE '%API%' OR Desciption LIKE '%toolkit%'";
	}

	public static String consultaPerguntasAleatoriasEmCategorias(List<String> listaTagsLib) {
		
		String srtCats = "";
		for(int i=0;i<listaTagsLib.size(); i++){
			if(i != listaTagsLib.size() - 1)
				srtCats += "p.tags LIKE '%<" + listaTagsLib.get(i) + ">%' AND ";
			else
				srtCats += "p.tags LIKE '%<" + listaTagsLib.get(i) + ">%'";
		}
				
		return "SELECT Id postid, title, body, owneruserid " +
		"FROM posts p " +
		"WHERE " + srtCats + " " +
		"ORDER BY RAND()";
	}
	public static String consultaPerguntasPorTags(List<String> listaTagsLib) {
		
		String srtCats = "";
		for(int i=0;i<listaTagsLib.size(); i++){
			if(i != listaTagsLib.size() - 1)
				srtCats += "p.tags LIKE '%<" + listaTagsLib.get(i) + ">%' AND ";
			else
				srtCats += "p.tags LIKE '%<" + listaTagsLib.get(i) + ">%'";
		}
				
		return "SELECT Id postid, title, body, owneruserid " +
		"FROM posts p " +
		"WHERE " + srtCats;
	}
	
	public static String consultaPostsEmCategorias(String[] vetAPIs) {

		String srtCats = "";
		for(int i=0;i<vetAPIs.length; i++){
			if(i != vetAPIs.length - 1)
				srtCats += "p.tags LIKE '%<" + vetAPIs[i] + ">%' AND ";
			else
				srtCats += "p.tags LIKE '%<" + vetAPIs[i] + ">%'";
		}
		
		return "(SELECT p.Body AS body " +
		"FROM posts p " +
		"WHERE p.PostTypeId = 1 AND " + srtCats + ") " +  
		"UNION " +
		"(SELECT pa.Body AS body " +
		"FROM posts pa INNER JOIN posts pq ON pa.parentid = pq.id " +
		"WHERE pq.PostTypeId = 1 AND pa.PostTypeId = 2 AND " + srtCats.replace("p.tags", "pq.tags") + ")";
	}
	
public static String consultaPerguntasEmCategorias(List<String> listaTagsLib) {
		
		String srtCats = "";
		for(int i=0;i<listaTagsLib.size(); i++){
			if(i != listaTagsLib.size() - 1)
				srtCats += "p.tags LIKE '%<" + listaTagsLib.get(i) + ">%' AND ";
			else
				srtCats += "p.tags LIKE '%<" + listaTagsLib.get(i) + ">%'";
		}
				
		return "SELECT p.id postid, title, body, owneruserid " +
		"FROM posts p " +
		"WHERE " + srtCats;
	}

	public static String consultaPerguntas() {
		return "SELECT p.id postid, p.score score " +
		"FROM posts p " +
		"WHERE p.posttypeid = 1";
	}

	//adaptada
	public static String consultaScoreDePosts() {
		return "SELECT id ,  score " +
		"FROM posts p";
	}
	
	// novo para consultar apenas API a ser gerada
	public static String consultaScoreDePostsAPI(String API) {
		return "SELECT id ,  score " +
		"FROM posts WHERE tags LIKE '%<" + API + ">%'";
	}

	public static String consultaScoreDeRespostasDadaAPergunta (int ParentId) {
		return "SELECT id ,  score " +
		"FROM posts WHERE ParentId = " + ParentId;		
	}

	public static String consultaQAPairsTable() {
		return "SELECT qa.NameApis, qa.Qtde, qa.TestRunCode, qa.lda_k, qa.threshold_for_ranking " +
				"FROM qa_pairs_count qa";
	}

	public static String consultaQAPairsTableManual() {
		return "SELECT qa.NameApis, qa.Qtde, qa.TestRunCode" +
				"FROM qa_pairs_count qa";
	}

	public static String consultaPerguntasHowTo(String nomeAPIs) {
		return "SELECT QuestionId, AnswerId " +
		"FROM how_to_pairs " +
		"WHERE NameApis = '" + nomeAPIs + "'";
	}
}
