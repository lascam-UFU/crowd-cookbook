/* 
 * Classe responsavel por testar o ClassificadorHowTo.java
 */

package br.ufu.facom.lsa.TesteHowTo;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;

public class TestaClassificador {
	public final static void main(String[] args) {
		
	try{
		//Essa lista guardará os ids das perguntas que já foram usadas na base de treinamento, na qual observamos 
		//os padroes para classificar uma pergunta como how to.
		//Essas perguntas não poderão fazer parte da base de teste
		List<String> listaPerguntasUsadasNaBaseDeTeste = new ArrayList<String>();
		
		//String vetPerguntasBaseDeTestes[]= {"10241230","8823959","14395983","2116951","1054714","13080773","9398431","9935092","12533870","5104186","8969373","7768160","3855120","13414171","6263469","1333377","11006223","7646975","11964829","975919","3976342","1608534","3186340","6168780","12482069","3388500","3844608","13296209","2272967","1792828","3861484","12986912","6550141","10352767","13957562","12517230","13863945","5786907","3186340","2996055","7255880","4022008","602939","6943791","5230893","3499349","12352995","12975909","9033292","11818005","12930114","11717303","12356220","14111489","8802413","13891948","13044357","12936985","10969640","9268011","3049395","76300","12966863","5096299","7007532","11555343","5121313","14919762","8064219","8432635"};
		//String vetPerguntasJaSorteadas[]= {"9717649","14144232","5862338","5007932","2963998","10749874","11073432","3012834","14151872","4080852","7881814","6095231","221568","9908304","7319969","6439086","4032342","1045362","8653617","300246","734540","8338113","8637978","13089211","10378087","7331614","7836788","1041532","3326557","14230927","6690704","1838837","10925496","6459931","6724061","10090742","12431481","8398532","640019","3311078","5456008","7045611","1830058","9440096","10528080","3852103","14028738","11844119","11727129","13568736","9532993","5244948","9959080","11157301","8030381","771078","530938","10902527","6463595","13496697","12741208","6621076","566877","4619704","11847959","15026807","13857614","8382512","11476270","7576131","6621922","558555","9094655","13357736","1333614","13526503","6321517","7706785","4660399","6125164","12094653","12718971","8881141","9892692","8358312","10967517","2415501","5879608","9679567","8699998"};
		
		/*SELECT p.`Id`
		FROM posts p
		WHERE p.`PostTypeId` = 1 AND p.`Tags` LIKE '%<swing>%'
		ORDER BY RAND()
		LIMIT 30*/
		
		String vetPerguntasBaseDeTestes[]= {"5951428","5922718","12308168","9854628","9125249","14608854","7863982","6969783","9667231","9055602","5225025","13409279","11933241","14874038","8372095","12811794","525430","5535395","11687988","3094195","13131035","13799227","14489121","14714888","10523343","14283192","1450383","7050972","4317918","14275219"};
		
		ConexaoDB cbd = new ConexaoDB();
		cbd.conectaAoBD();
		
		ClassificadorHowTo classificador = new ClassificadorHowTo();
				
		for(int i=0; i< vetPerguntasBaseDeTestes.length;i++){
			
			String queryCorpo = ConsultasBD.consultaCorpo(Integer.parseInt(vetPerguntasBaseDeTestes[i]));
			ResultSet rs = cbd.executaQuery(queryCorpo);
			rs.next();
			String corpoDaPergunta = rs.getString("body");
			
			String q1 = ConsultasBD.consultaTitulo(Integer.parseInt(vetPerguntasBaseDeTestes[i]));
			ResultSet r1 = cbd.executaQuery(q1);
			r1.next();
			String tituloPergunta = r1.getString("title");
			
			System.out.println(vetPerguntasBaseDeTestes[i] + " " + classificador.classficaComoHowTO(tituloPergunta, corpoDaPergunta) + " " + classificador.classficaComoHowTO_old(tituloPergunta, corpoDaPergunta));
		}
	
		//String vetPerguntasJaSorteadas[]= {};
				
		/*for(int i=0; i< vetPerguntasBaseDeTestes.length; i++){
			listaPerguntasUsadasNaBaseDeTeste.add(vetPerguntasBaseDeTestes[i]);
		}
		
		for(int i=0; i< vetPerguntasJaSorteadas.length; i++){
			listaPerguntasUsadasNaBaseDeTeste.add(vetPerguntasJaSorteadas[i]);
		}*/
		
		/*Set<String> set = new HashSet<String>(listaPerguntasUsadasNaBaseDeTeste);
		
		
		
		//Recupera a querry para consutlar todas as perguntas relacionadas aquela API (independente de ter how ou nao)
		String query = ConsultasBD.consultaPerguntas("swt");
		
		Map<String, String> mapIdTitulo = new HashMap<String, String>();
		Map<String, String> mapIdCorpo = new HashMap<String, String>();
		List<String> listaIdsPossiveis = new ArrayList<String>();
		
		//Executa a query
		ResultSet rs = cbd.executaQuery(query);
		
		int count = 0;
		ClassificadorHowTo classificador = new ClassificadorHowTo();
		
		while (rs.next()) {
			int idPergunta = Integer.parseInt(rs.getString("Id"));
			String corpoOriginal = rs.getString("Body");
			String tituloOriginal = rs.getString("Title");
			
			boolean ehHowTo = classificador.classficaComoHowTO(tituloOriginal, corpoOriginal);
			if(ehHowTo)
				System.out.println(idPergunta + " " + ehHowTo);
			
			count++;
			
			if(!listaPerguntasUsadasNaBaseDeTeste.contains(idPergunta+"")){
				listaIdsPossiveis.add(idPergunta+"");
				mapIdTitulo.put(idPergunta+"", tituloOriginal);
				mapIdCorpo.put(idPergunta+"", corpoOriginal);
			}
		}
		
		//fecha a conexao com o BD
		cbd.close();
		
		System.out.println("tamanho da lista de possiveis ID que estao aptos a serem sorteados para fazerem parte da nossa base de testes: " + listaIdsPossiveis.size());
		System.out.println(count);
		
		//Iremos sortear algumas perguntas que irao compor a base de testes do classificador
		Random randomGenerator = new Random();
		
		System.out.println("Perguntas sorteadas para fazerem parte da base de testes: ");
		for(int i=0; i< 10; i++){
			int indice = randomGenerator.nextInt(listaIdsPossiveis.size());
			String idPergunta = Integer.parseInt(listaIdsPossiveis.get(indice))  + "";
			
			boolean ehHowTo = classificador.classficaComoHowTO(mapIdTitulo.get(idPergunta), mapIdCorpo.get(idPergunta));
			System.out.println(idPergunta + " " + ehHowTo);
		}*/
	}
	catch(Exception e){
		e.printStackTrace();
	}
}
}
