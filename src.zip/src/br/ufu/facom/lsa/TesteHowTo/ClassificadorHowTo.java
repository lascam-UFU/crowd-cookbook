/* 
 * Classe que dada uma pergunta, diz se a mesma é um HOW-TO (classificador binário) 
 * Atualmente o classificador considera uma pergunta como HOW TO, se:
 * 1- A pergunta possui o token 'how' no titulo, ou 
 * 2- A pergunta possui o token 'how' no corpo e nao possui termos relacionados a erros (ex.: problemm, error) no corpo
 * e nao possui as string 'error' e 'exception' nos codigos fontes 
*/

package br.ufu.facom.lsa.TesteHowTo;

import java.util.ArrayList;
import java.util.List;

import br.ufu.facom.lsa.Lda.ManipuladorDeTexto;

public class ClassificadorHowTo {
	
	private ManipuladorDeTexto mt;
	//Lista que guardara os termos que estao associados a perguntas do tipo debug-corrective
	private List<String> listaTermosErro;

	public ClassificadorHowTo() {
		this.mt = new ManipuladorDeTexto("", true);
		this.listaTermosErro = new ArrayList<String>();
		listaTermosErro.add("fail");
		//Exception nao sera considerado como ligado a erro
		//listaTermosErro.add("exception");
		listaTermosErro.add("problem");
		listaTermosErro.add("error");
		listaTermosErro.add("wrong");
		listaTermosErro.add("fix");
		listaTermosErro.add("bug");
		listaTermosErro.add("issue");
		listaTermosErro.add("solve");
		//nova:
		listaTermosErro.add("trouble");
		listaTermosErro = mt.stemmizaListaDePalavras(listaTermosErro);
	}
	
	public boolean classficaComoHowTO_old(String tituloPergunta, String corpoPergunta){
		String tituloTratado = mt.removeTagsIndesejadas(tituloPergunta, false);
		String corpoTratado = mt.removeTagsIndesejadas(corpoPergunta, false);
		
		List<String> tokensTitulo = mt.recuperaTokens(tituloTratado);
		List<String> tokensCorpo = mt.recuperaTokens(corpoTratado);
		
		if(tokensTitulo.contains("how"))
			return true;
		else if(tokensCorpo.contains("how")){
			boolean temPalavrasLigadasAErros = false;
			
			List<String> listIntersecao = new ArrayList<String>(tokensCorpo);
			listIntersecao.retainAll(listaTermosErro);
			//Caso nao possua palavras relacionadas a erro no corpo e possua o token how no corpo tbm sera considerada HOW TO
			if(listIntersecao.size() > 0)
				temPalavrasLigadasAErros =  true;
			
			String textoCodigos = mt.getCodigo(corpoPergunta).toLowerCase();
			//Caso nao possua palavras relacionadas a erro no codigo e possua o token how no corpo tbm sera considerada HOW TO
			if(textoCodigos.contains("error") || textoCodigos.contains("exception"))
				temPalavrasLigadasAErros =  true;
			
			if(!temPalavrasLigadasAErros)
				return true;
		}
		
		return false;
		
		
	}
	
	public boolean classficaComoHowTO(String tituloPergunta, String corpoPergunta){
		String tituloTratado = mt.removeTagsIndesejadas(tituloPergunta, false);
		String corpoTratado = mt.removeTagsIndesejadas(corpoPergunta, false);
		
		List<String> tokensTitulo = mt.recuperaTokens(tituloTratado);
		List<String> tokensCorpo = mt.recuperaTokens(corpoTratado);
		
		if(tokensTitulo.contains("how") || tokensCorpo.contains("how")){
			boolean temPalavrasLigadasAErros = false;
			
			List<String> listIntersecao = new ArrayList<String>(tokensCorpo);
			listIntersecao.retainAll(listaTermosErro);
			//Caso nao possua palavras relacionadas a erro no corpo e possua o token how no corpo tbm sera considerada HOW TO
			if(listIntersecao.size() > 0)
				temPalavrasLigadasAErros =  true;
			
			String textoCodigos = mt.getCodigo(corpoPergunta).toLowerCase();
			//Caso nao possua palavras relacionadas a erro no codigo e possua o token how no corpo tbm sera considerada HOW TO
			if(textoCodigos.contains("error")/* || textoCodigos.contains("exception")*/)
				temPalavrasLigadasAErros =  true;
			
			if(!temPalavrasLigadasAErros)
				return true;
		}
		
		return false;
		
		
	}
	
	
}
