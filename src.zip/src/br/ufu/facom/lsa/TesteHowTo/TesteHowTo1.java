/* 
 * Classe responsavel por selecionar as threads que farao parte do teste para analisar como sao as questoes HOW-TO 
 */

package br.ufu.facom.lsa.TesteHowTo;

import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;

public class TesteHowTo1 {
	//Vamos considerar 4 APIs: GWT, SWT, Swing e JQuery 
	//Para cada uma, camos selecionar 10 perguntas sem a string how-to e 10 com essa string
	//Todas perguntas escolhidas, deverao ter respostas aceita
	
	public final static void main(String[] args) {
		try{
			//APIs que serao consideradas no estudo 
			String apis[] = {"swt","gwt","swing","jquery"};
			//String apis[] = {"swt"};
			
			//Conecta ao BD do Stack Overflow para em seguida executar a query
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();
			
			List<String> listaIdsComHowTitulo = null;
			List<String> listaIdsComHowBody = null;
			List<String> listaIdsSemHowTo = null;

			for(int i=0; i <apis.length; i++){
				//Recupera a querry para consutlar os IDs das perguntas com HOW no titulo, de acordo com a API
				String query = ConsultasBD.consultaPerguntasComHowNoTitulo(apis[i]);
				//Executa a query
				ResultSet rs = cbd.executaQuery(query);
				
				//Lista para gurdar os ids das perguntas sorteadas com how
				listaIdsComHowTitulo = new ArrayList<String>();
				
				while (rs.next()) {
					int idPergunta = Integer.parseInt(rs.getString("Id"));
					listaIdsComHowTitulo.add(idPergunta+"");
				}
				
				//Recupera a querry para consutlar os IDs das perguntas com HOW no corpo, de acordo com a API
				query = ConsultasBD.consultaPerguntasComHowNoCorpo(apis[i]);
				rs = cbd.executaQuery(query);
				
				//Lista para gurdar os ids das perguntas sorteadas sem how-to
				listaIdsComHowBody = new ArrayList<String>();
				
				while (rs.next()) {
					int idPergunta = Integer.parseInt(rs.getString("Id"));
					listaIdsComHowBody.add(idPergunta+"");
				}
				
				//Recupera a querry para consutlar os IDs das perguntas sem HOW, de acordo com a API
				query = ConsultasBD.consultaPerguntasSemHow(apis[i]);
				rs = cbd.executaQuery(query);
				
				//Lista para gurdar os ids das perguntas sorteadas sem how-to
				listaIdsSemHowTo = new ArrayList<String>();
				
				while (rs.next()) {
					int idPergunta = Integer.parseInt(rs.getString("Id"));
					listaIdsSemHowTo.add(idPergunta+"");
				}
				
				System.out.println("API " + apis[i]);
				//Variavel para fazer o serteio dos ids das perguntas (10 com how e 10 sem how)
				System.out.println("Com how no titulo");
				Random randomGenerator = new Random();
				//Lista para guardar os ids das perguntas ja sortedas
				List<String> listSorteados = new ArrayList<String>();
				while(listSorteados.size() < 10){
					 int indice = randomGenerator.nextInt(listaIdsComHowTitulo.size());
					 if(listSorteados.contains(listaIdsComHowTitulo.get(indice)))
						 continue;
					 listSorteados.add(listaIdsComHowTitulo.get(indice));
					 System.out.println(listaIdsComHowTitulo.get(indice));
				}
				
				listSorteados.clear();
				System.out.println("Com how no corpo");
				while(listSorteados.size() < 10){
					 int indice = randomGenerator.nextInt(listaIdsComHowBody.size());
					 if(listSorteados.contains(listaIdsComHowBody.get(indice)))
						 continue;
					 listSorteados.add(listaIdsComHowBody.get(indice));
					 System.out.println(listaIdsComHowBody.get(indice));
				}
				
				listSorteados.clear();
				System.out.println("Sem how");
				while(listSorteados.size() < 10){
					 int indice = randomGenerator.nextInt(listaIdsSemHowTo.size());
					 if(listSorteados.contains(listaIdsSemHowTo.get(indice)))
						 continue;
					 listSorteados.add(listaIdsSemHowTo.get(indice));
					 System.out.println(listaIdsSemHowTo.get(indice));
				}
				
			}
			
			//fecha a conexao com o BD
			cbd.close();
			
			
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
