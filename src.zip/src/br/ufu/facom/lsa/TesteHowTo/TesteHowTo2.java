/* 
 * Classe responsavel por selecionar as threads que farao parte do teste para analisar como sao as questoes HOW-TO, porem 
 * ao contrario da classe Main, para verificar a ocorrencia da palavra HOW, vamos verificar pelo depois de tokenizar o text
 * e nao diretamente pelo select
*/

package br.ufu.facom.lsa.TesteHowTo;

import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;
import br.ufu.facom.lsa.Lda.ManipuladorDeTexto;

public class TesteHowTo2 {
	//Vamos considerar 4 APIs: GWT, SWT, Swing e JQuery 
	//Para cada uma, camos selecionar 10 perguntas sem o token how, 10 com esse token no titulo  e 10 com esse token no corpo da pergunta
	
	public final static void main(String[] args) {
		try{
			//APIs que serao consideradas no estudo 
			//String apis[] = {"swt","gwt","swing","jquery"};
			String apis[] = {"swt"};
			
			//Conecta ao BD do Stack Overflow para em seguida executar a query
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();
			
			List<String> listaIdsComHowTitulo = null;
			List<String> listaIdsComHowBody = null;
			List<String> listaIdsSemHow = null;
			
			//Lista que guardara o id de todas as perguntas do tipo HOW-TO. Por enquanto estamos considerando uma pergunta
			//como do tipo how to se a mesma se enquandra em uma duas duas situacoes a seguir:
			//1- possui o token how no titulo
			//2- possui o token how no corpo e nao possui palavras que estao relacionadas a erros (ex.: problem, error) no corpo e nem no codigo
			List<String> listaPerguntasHOW_TO = null;
			
			ManipuladorDeTexto mt = new ManipuladorDeTexto("", true);
			
			//Lista que guardara os termos que estao associados a perguntas do tipo debug-corrective
			List<String> listaTermosErro = new ArrayList<String>();
			listaTermosErro.add("fail");
			//Exception nao sera considerado como ligado a erro
			//listaTermosErro.add("exception");
			listaTermosErro.add("problem");
			listaTermosErro.add("error");
			listaTermosErro.add("wrong");
			listaTermosErro.add("fix");
			listaTermosErro.add("bug");
			listaTermosErro.add("issue");
			listaTermosErro.add("solve");
			
			listaTermosErro = mt.stemmizaListaDePalavras(listaTermosErro);

			for(int i=0; i <apis.length; i++){
				
				//Recupera a querry para consutlar todas as perguntas relacionadas aquela API (independente de ter how ou nao)
				String query = ConsultasBD.consultaPerguntas(apis[i]);
				//Executa a query
				ResultSet rs = cbd.executaQuery(query);
				
				//Listas para guardar os ids das perguntas sorteadas com how no titulo, no corpo, e sem how 
				listaIdsComHowTitulo = new ArrayList<String>();
				listaIdsComHowBody = new ArrayList<String>();
				listaIdsSemHow = new ArrayList<String>();
				
				listaPerguntasHOW_TO = new ArrayList<String>();
				
				while (rs.next()) {
					int idPergunta = Integer.parseInt(rs.getString("Id"));
					
					String corpoOriginal = rs.getString("Body");
					String titulo = mt.removeTagsIndesejadas(rs.getString("Title"), false);
					String corpo = mt.removeTagsIndesejadas(rs.getString("Body"), false);
					
					List<String> tokensTitulo = mt.recuperaTokens(titulo);
					List<String> tokensCorpo = mt.recuperaTokens(corpo);
					
					if(tokensTitulo.contains("how")){
						//Caso tenha o token how no titulo ja sera considerada HOW TO
						listaIdsComHowTitulo.add(idPergunta + "");
						listaPerguntasHOW_TO.add(idPergunta + "");
					}
					
					if(tokensCorpo.contains("how") && !tokensTitulo.contains("how")){
						listaIdsComHowBody.add(idPergunta + "");
						
						boolean temPalavrasLigadasAErros = false;
						
						List<String> listIntersecao = new ArrayList<String>(tokensCorpo);
						listIntersecao.retainAll(listaTermosErro);
						//Caso nao possua palavras relacionadas a erro no corpo e possua o token how no corpo tbm sera considerada HOW TO
						if(listIntersecao.size() > 0)
							temPalavrasLigadasAErros =  true;
							
						String textoCodigos = mt.getCodigo(corpoOriginal).toLowerCase();
						//Caso nao possua palavras relacionadas a erro no codigo e possua o token how no corpo tbm sera considerada HOW TO
						if(textoCodigos.contains("error") || textoCodigos.contains("exception"))
							temPalavrasLigadasAErros =  true;
						
						if(!temPalavrasLigadasAErros && !listaPerguntasHOW_TO.contains(idPergunta + ""))
							listaPerguntasHOW_TO.add(idPergunta + "");
						
					}	
					if(!tokensTitulo.contains("how") && !tokensCorpo.contains("how"))
						listaIdsSemHow.add(idPergunta + "");
				}
				
				//Imprime o nro de preguntas que forma consideradas do tipo HOW TO
				System.out.println("Nro de perguntas que foram consideradas HOW TO: " + listaPerguntasHOW_TO.size());
				
				//Agora vamos imprimir od id's de todas as peguntas que tem how no titulo (por enquanto consideraremos apenas essas perguntas como how-to). 
				//Esses id's serao usados no select para recuperar valores das metricas das perguntas (ex.: view count, socre, etc)
				for(int j=0; j< listaIdsComHowTitulo.size(); j++){
					System.out.print(listaIdsComHowTitulo.get(j) + ",");
					
				}
				
				System.out.println("API " + apis[i]);
				//Variavel para fazer o serteio dos ids das perguntas 
				System.out.println("Com how no titulo");
				Random randomGenerator = new Random();
				//Lista para guardar os ids das perguntas ja sortedas
				List<String> listSorteados = new ArrayList<String>();
				while(listSorteados.size() < 10){
					 int indice = randomGenerator.nextInt(listaIdsComHowTitulo.size());
					 if(listSorteados.contains(listaIdsComHowTitulo.get(indice)))
						 continue;
					 listSorteados.add(listaIdsComHowTitulo.get(indice));
					 System.out.println(listaIdsComHowTitulo.get(indice));
				}
				
				listSorteados.clear();
				System.out.println("Com how no corpo e sem how no titulo");
				while(listSorteados.size() < 10){
					 int indice = randomGenerator.nextInt(listaIdsComHowBody.size());
					 if(listSorteados.contains(listaIdsComHowBody.get(indice)))
						 continue;
					 listSorteados.add(listaIdsComHowBody.get(indice));
					 System.out.println(listaIdsComHowBody.get(indice));
				}
				
				listSorteados.clear();
				System.out.println("Sem how");
				while(listSorteados.size() < 10){
					 int indice = randomGenerator.nextInt(listaIdsSemHow.size());
					 if(listSorteados.contains(listaIdsSemHow.get(indice)))
						 continue;
					 listSorteados.add(listaIdsSemHow.get(indice));
					 System.out.println(listaIdsSemHow.get(indice));
				}
				
			}
			
			//fecha a conexao com o BD
			cbd.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}

