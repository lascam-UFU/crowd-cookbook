/* Essa classe sera responsavel por determinar quais perguntas sao how-to`s, para as api requeridas
 * 
 * */

package br.ufu.facom.lsa.TesteHowTo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;

public class DeterminaPerguntasHowTo {
	public final static void main(String[] args) {
		try {

			List<String[]> listaApis = new ArrayList<String[]>();
			/*
			 * String api1[] = {"jquery", "asp.net"}; listaApis.add(api1); String api2[] =
			 * {"swing"}; listaApis.add(api2); String api3[] = {"swt"}; listaApis.add(api3);
			 * String api4[] = {"stl"}; listaApis.add(api4); String api5[] = {"qt4"};
			 * listaApis.add(api5); String api6[] = {"log4net", "c#"}; listaApis.add(api6);
			 * String api7[] = {"awt"}; listaApis.add(api7); String api8[] = {"boost"};
			 * listaApis.add(api8); String api9[] = {"matplotlib"}; listaApis.add(api9);
			 * String api10[] = {"backbone.js"}; listaApis.add(api10);
			 * 
			 * //List<String[]> listaApis = new ArrayList<String[]>(); //String api1[] =
			 * {"weka"}; //listaApis.add(api1);
			 * 
			 * String api11[] = {"linq"}; listaApis.add(api11);
			 */

			//String api12[] = { "backbone.js", "matplotlib", "junit", "jdbc", "awt", "slf4j", "apache-commons", "nltk", "numpy", "pygame", "sqlalchemy", "python-requests", "beautifulsoup" };
			String api12[] = { "swing"};
			listaApis.add(api12);

			ConexaoDB cbd;
			cbd = new ConexaoDB();
			cbd.conectaAoBD("stackoverflow2018");

			ClassificadorHowTo classificador;
			classificador = new ClassificadorHowTo();

			ConexaoDB cbdStackCookbooks = new ConexaoDB();
			// Conecta ao banco stack_research
			cbdStackCookbooks.conectaAoBD("stackOfCookBooks");
			PreparedStatement ps = cbdStackCookbooks
					.criaPreparedStatement("insert into how_to_pairs(NameApis, QuestionId, AnswerId) values(?,?,?)");
			PreparedStatement ps2 = cbdStackCookbooks
					.criaPreparedStatement("insert into qa_pairs_count(NameApis, Qtde, DumpYear) values(?,?,?)");

			for (int j = 0; j < listaApis.size(); j++) {
				String vetAPIs[] = listaApis.get(j);
				// Lista que armazenara o id de perguntas que possuem a tag (categoria)
				List<String> listaTagsLib = new ArrayList<String>();
				String nomeApis = "";
				for (int i = 0; i < vetAPIs.length; i++) {
					listaTagsLib.add(vetAPIs[i]);
					nomeApis += vetAPIs[i];
					if (i != vetAPIs.length - 1)
						nomeApis += "_";
				}
				String query = ConsultasBD.consultaPerguntasPorTags(listaTagsLib);
				System.out.println(query);
				ResultSet rs = cbd.executaQuery(query);
				int countParesApi = 0;

				int rowCount = 0;
				if (rs.last()) {// make cursor to point to the last row in the ResultSet object
					rowCount = rs.getRow();
					rs.beforeFirst(); // make cursor to point to the front of the ResultSet object, just before the
										// first row.
				}
				System.out.println("Total number of rows in " + nomeApis + " API = " + rowCount);

				while (rs.next()) {
					int postid = rs.getInt("postid");

					String q1 = ConsultasBD.consultaCorpo(postid);
					ResultSet r1 = cbd.executaQuery(q1);
					r1.next();
					String corpoPergunta = r1.getString("body");

					q1 = ConsultasBD.consultaTitulo(postid);
					r1 = cbd.executaQuery(q1);
					r1.next();
					String tituloPergunta = r1.getString("title");
					if (!classificador.classficaComoHowTO(tituloPergunta, corpoPergunta)) {
						// System.out.println((indiceAtual-1) + " nao eh howto");
						continue;
					} else {

						String query1 = ConsultasBD.consultaRespostasDePergunta(postid);
						ResultSet rsInterno = cbd.executaQuery(query1);
						while (rsInterno.next()) {
							countParesApi++;
							int idResposta = rsInterno.getInt("id");

							ps.setString(1, nomeApis);
							ps.setInt(2, postid);
							ps.setInt(3, idResposta);

							ps.executeUpdate();
						}
					}
				}
				ps2.setString(1, nomeApis);
				ps2.setInt(2, countParesApi);
				ps2.setInt(3,  2018);
				ps2.executeUpdate();
			}
			cbd.close();
			cbdStackCookbooks.close();
			System.out.println("FIM!!!");
			System.exit(0);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
