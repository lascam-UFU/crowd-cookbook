/* 
 * Classe responsavel por testar o 
 */

package br.ufu.facom.lsa.TesteAnaliseDeSentimentos;

import java.io.File;
import java.sql.ResultSet;

import com.aliasi.classify.ConditionalClassification;
import com.aliasi.classify.LMClassifier;
import com.aliasi.util.AbstractExternalizable;

import uk.ac.wlv.sentistrength.SentiStrength;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;

public class Main {

	public static void main(String[] args) {
		try{
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();
			
			String query = ConsultasBD.consultaComentariosAleatorios(50);
			//Executa a query
			ResultSet rs = cbd.executaQuery(query);
			
			LMClassifier classificador = (LMClassifier) AbstractExternalizable.readObject(new File("/media/HDii-2x3Tb/Lucas/lucas2/workspace2/ProjetoMestrado/libs/classifier.txt"));;
			while (rs.next()) {
				String comentario = rs.getString("texto");
				String postid = rs.getString("postid");
				
				//default
				String ssthInitialisation[] = {"sentidata", "/media/HDii-2x3Tb/Lucas/lucas2/workspace2/ProjetoMestrado/libs/sentStrength/SentStrength_Data_Sept2011/","explain"};
				SentiStrength sentiStrength = new SentiStrength(); 
				sentiStrength.initialise(ssthInitialisation); //Initialise
				String sentiStrengthRes1Vet[] = sentiStrength.computeSentimentScores(comentario).split(" ");
				String sentiStrengthRes1 =  sentiStrengthRes1Vet[0] + " " + sentiStrengthRes1Vet[1];
				
				//trinary
				String ssthInitialisation2[] = {"sentidata", "/media/HDii-2x3Tb/Lucas/lucas2/workspace2/ProjetoMestrado/libs/sentStrength/SentStrength_Data_Sept2011/", "explain", "trinary"};
				SentiStrength sentiStrength2 = new SentiStrength(); 
				sentiStrength2.initialise(ssthInitialisation2); //Initialise
				String sentiStrengthRes2Vet[] = sentiStrength2.computeSentimentScores(comentario).split(" ");
				String sentiStrengthRes2 =  sentiStrengthRes2Vet[0] + " " + sentiStrengthRes2Vet[1] + " " + sentiStrengthRes2Vet[2];
				
				int fatorPos = Integer.parseInt(sentiStrengthRes2Vet[0]);
				int fatorNeg = Integer.parseInt(sentiStrengthRes2Vet[1]);
				
				if((fatorPos + fatorNeg) < 0)
					sentiStrengthRes2 = "neg";
				else if((fatorPos + fatorNeg) == 0)
					sentiStrengthRes2 = "neu";
				else if((fatorPos + fatorNeg) > 0)
					sentiStrengthRes2 = "pos";
					
				//binary
				String ssthInitialisation3[] = {"sentidata", "/media/HDii-2x3Tb/Lucas/lucas2/workspace2/ProjetoMestrado/libs/sentStrength/SentStrength_Data_Sept2011/", "explain", "binary"};
				SentiStrength sentiStrength3 = new SentiStrength(); 
				sentiStrength3.initialise(ssthInitialisation3); //Initialise
				String sentiStrengthRes3Vet[] = sentiStrength3.computeSentimentScores(comentario).split(" ");
				String sentiStrengthRes3 =  sentiStrengthRes3Vet[0] + " " + sentiStrengthRes3Vet[1] + " " + sentiStrengthRes3Vet[2];
				
				//scale
				String ssthInitialisation4[] = {"sentidata", "/media/HDii-2x3Tb/Lucas/lucas2/workspace2/ProjetoMestrado/libs/sentStrength/SentStrength_Data_Sept2011/", "explain", "scale"};
				SentiStrength sentiStrength4 = new SentiStrength(); 
				sentiStrength4.initialise(ssthInitialisation4); //Initialise
				String sentiStrengthRes4Vet[] = sentiStrength4.computeSentimentScores(comentario).split(" ");
				String sentiStrengthRes4 =  sentiStrengthRes4Vet[0] + " " + sentiStrengthRes4Vet[1] + " " + sentiStrengthRes4Vet[2];
				
				//LingPipe
				ConditionalClassification classification = classificador.classify(comentario);
				String resultadoLingPipe = classification.bestCategory();
				
				if(sentiStrengthRes2.equals("pos") || resultadoLingPipe.equals("pos"))
					System.out.println(postid + "\t" + comentario + "\t" + sentiStrengthRes1 + "\t" + sentiStrengthRes3 + "\t" + sentiStrengthRes4 + "\t" + sentiStrengthRes2 + "\t" + resultadoLingPipe);
			}
			
			
			//fecha a conexao com o BD
			cbd.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		

	}

}
