package br.ufu.facom.lsa.ExtratorDeCaracteristicasDosPosts;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.htmlcleaner.HtmlCleaner;
import org.htmlcleaner.TagNode;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;
import br.ufu.facom.lsa.Lda.ManipuladorDeTexto;
public class ExtratorDeCaracteristicasDePar {
 
	//Variavel para manter a conexao com o banco de dados
	private  ConexaoDB cbd;
	
	private  boolean ehPrimeiraVez;
	
	private  Map<Integer, Integer> mapRankingAskers;
	private  int ultimaPosicaoNoRankingDeAskers;
	private  Map<Integer, Integer> mapRankingAnswerers;
	private  int ultimaPosicaoNoRankingDeAnswerers;
	
	private  List<String> listaTags;
	private  List<String> listaIdUsers; 

	//Map para ranking de usuarios
	private  List<DadosUsuario> listaParaRankingDeRating; 
	//Map para ranking de usuarios de usuarios
	//<idUSer, DadosUsaurio>
	private  Map<String, DadosUsuario> mapParaRankingDeRating = new HashMap<String, DadosUsuario>();

	//Map<tag, <usu, posicao>>
	private  Map<String, Map<String, Integer>> mapRankingDeAnswerersCategorias;
	private  Map<String, Map<String, Integer>> mapRankingDeAskersCategorias;
	//Map<cat, ultimaPosicao>
	private  Map<String, Integer> mapUltimaPosicaoRankingDeRespostasPorCat; 
	private  Map<String, Integer> mapUltimaPosicaoRankingDePerguntasPorCat ;

	private  boolean normalizaEntropa = true;

	//Set para guardar os nomes de tags que ja fizemos o ranqueamento
	private  Set<String> setCategoriasJaProcessadas;
	private  int ultimaPosicaoDoRankingDePerguntas;
	private  int ultimaPosicaoDoRankingDeRespostas;
	//Map<cat, ultimaPosicaoRankingDeScoreDePergOuResp>
	private  Map<String, Integer> mapUltimaPosicaoRankingDeScoreDeRespostasPorCat; 
	private  Map<String, Integer> mapUltimaPosicaoRankingDeScoreDePerguntasPorCat;
	
	private ManipuladorDeTexto mt;
	
	//Map que associa a cada nome de API um id numerico
	Map<String, Integer> mapCategoriaId = new HashMap<String, Integer>();
	
	public ExtratorDeCaracteristicasDePar(String caminhoArquivoIdCategoria, boolean ehPrimeiraVez, boolean normalizaEntropa){
		try{
			this.cbd = new ConexaoDB();
			//Conecta ao banco
			cbd.conectaAoBD();
			mt = new ManipuladorDeTexto("", true);
			
			this.ehPrimeiraVez = ehPrimeiraVez;
			this.normalizaEntropa = normalizaEntropa;
			restauraVariaveisPreprocessadas();
			
			//Monta o map que vai associar a cada categoria um id
			inicializaMapCategoriaId(mapCategoriaId, caminhoArquivoIdCategoria);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private static void inicializaMapCategoriaId(
			Map<String, Integer> mapCategoriaId,
			String caminhoArquivoIdCategoria) {
		try{
			
			BufferedReader bufferedReaderArquivoResult = new BufferedReader(new InputStreamReader(new FileInputStream(caminhoArquivoIdCategoria)));
			
			String line = "";
			while ((line = bufferedReaderArquivoResult.readLine()) != null) {
				String partes[] = line.split(" ");
				
				if(partes.length > 2)
					System.out.println("ERRO");
				
				String categoria = partes[1];
				int id = Integer.parseInt(partes[0]);
				mapCategoriaId.put(categoria, id);
			}
			
			bufferedReaderArquivoResult.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public  List<Double> calculaFeatures(int idPergunta, int idResposta, int idAsker, int idAnswerer, String corpoPergunta, String corpoResposta) {
		List<Double> listaValoresFeatures = new ArrayList<Double>();
		try{
					String textoSaida = idPergunta + "-" + idResposta; 
					System.out.println(textoSaida);
					textoSaida = "";
					
					/*******************************************************User features (Answer + Asker)*************************************************************/
					
					//int idAtualFeature = 1;
					
					//Calcula o número de dias desde o registro do anwerer até a data atual
					int Udayca = calculaUdayca(idAnswerer); 
					////textoSaida += idAtualFeature++ + ":" +Udayca + " ";
					listaValoresFeatures.add(Udayca + .0);
					
					//Calcula o número de dias desde o registro do asker até a data atual
					int Udaycq = calculaUdaycq(idAsker);
					////textoSaida += idAtualFeature++ + ":" + Udaycq + " ";;
					listaValoresFeatures.add(Udaycq + .0);
					
					//Calcula o número de dias desde o ultimo acesso do anwerer até a data atual
					int Ulaca = calculaUlaca(idAnswerer);
					////textoSaida += idAtualFeature++ + ":" +  Ulaca+ " ";
					listaValoresFeatures.add(Ulaca + .0);
					
					//Calcula o número de dias desde o ultimo acesso do asker até a data atual
					int Ulacq = calculaUlacq(idAsker); 
					////textoSaida += idAtualFeature++ + ":" +  Ulacq+ " ";
					listaValoresFeatures.add(Ulacq + .0);
					
					//Calcula o número de badges do answerer
					int Ubdga = calculaUbdga(idAnswerer);
					////textoSaida += idAtualFeature++ + ":" + Ubdga+ " ";
					listaValoresFeatures.add(Ubdga + .0);
					
					//Calcula o número de badges do asker
					int Ubdgq = calculaUbdgq(idAsker); 
					//textoSaida += idAtualFeature++ + ":" + Ubdgq+ " ";
					listaValoresFeatures.add(Ubdgq + .0);
					
					//Calcula o número de respotas postadas pelo Answerer
					int Uapa = calculaUapa(idAnswerer);
					//textoSaida += idAtualFeature++ + ":" + Uapa+ " ";
					listaValoresFeatures.add(Uapa + .0);
					
					//Calcula o número de respotas postadas pelo Asker
					int Uapq  = calculaUapq(idAsker);
					//textoSaida += idAtualFeature++ + ":" + Uapq+ " ";
					listaValoresFeatures.add(Uapq+.0);
					
					//Calcula o número de perguntas postadas pelo answerer
					int Uqpa = calculaUqpa(idAnswerer); 
					//textoSaida += idAtualFeature++ + ":" + Uqpa+ " ";
					listaValoresFeatures.add(Uqpa+.0);
					
					//Calcula o número de perguntas postadas pelo asker
					int Uqpq = calculaUqpq(idAsker); 
					//textoSaida += idAtualFeature++ + ":" + Uqpq+ " ";
					listaValoresFeatures.add(Uqpq+.0);
					
					//Calcula o nro medio, max e min de comentarios presentes em respostas daquele usuario (answerer)
					List<Integer> listaNroDeComentariosPorResposta = encontraNroDeComentariosPorResposta(idAnswerer);
					double Uacaa = calculaUacaa(listaNroDeComentariosPorResposta, Uapa);
					//textoSaida += idAtualFeature++ + ":" + Uacaa+ " ";
					listaValoresFeatures.add(Uacaa + .0);
					double Uxcaa = calculaUxcaa(listaNroDeComentariosPorResposta);
					//textoSaida += idAtualFeature++ + ":" + Uxcaa+ " ";
					listaValoresFeatures.add(Uxcaa + .0);
					double Umcaa = calculaUmcaa(listaNroDeComentariosPorResposta, Uapa);
					//textoSaida += idAtualFeature++ + ":" + Umcaa+ " ";
					listaValoresFeatures.add(Umcaa + .0);
					
					
					//Calcula o nro medio, max e min de comentarios presentes em respostas daquele usuario (asker)
					//VERIFICADAS
					listaNroDeComentariosPorResposta = encontraNroDeComentariosPorResposta(idAsker);
					//System.out.println("u-acaq = " + calculaMedia(listaNroDeComentariosPorResposta, nroRespostasPostadas));
					//textoSaida += idAtualFeature++ + ":" + calculaMedia(listaNroDeComentariosPorResposta, Uapq) + " ";
					listaValoresFeatures.add(calculaMedia(listaNroDeComentariosPorResposta, Uapq));
					//System.out.println("u-xcaq = " + calculaMax(listaNroDeComentariosPorResposta));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaNroDeComentariosPorResposta) + " ";
					listaValoresFeatures.add(calculaMax(listaNroDeComentariosPorResposta));
					if(listaNroDeComentariosPorResposta.size() != Uapq){
						//System.out.println("u-mcaq = " + 0);
						//textoSaida += idAtualFeature++ + ":" + 0 + " ";
						listaValoresFeatures.add(.0);
					}
					else{
						//System.out.println("u-mca = " + calculaMin(listaNroDeComentariosPorResposta));
						//textoSaida += idAtualFeature++ + ":" + calculaMin(listaNroDeComentariosPorResposta)+ " ";
						listaValoresFeatures.add(calculaMin(listaNroDeComentariosPorResposta));
					}
						
					
					//Calcula o nro medio, max e min de comentarios presentes em perguntas daquele usuario (answerer)
					//VERIFICADAS
					List<Integer> listaNroDeComentariosPorPergunta = encontraNroDeComentariosPorPergunta(idAnswerer);
					//System.out.println("u-acqa = " + calculaMedia(listaNroDeComentariosPorPergunta, nroPerguntasPostadas));
					//textoSaida += idAtualFeature++ + ":" + calculaMedia(listaNroDeComentariosPorPergunta, Uqpa)+ " ";
					listaValoresFeatures.add(calculaMedia(listaNroDeComentariosPorPergunta, Uqpa));
					//System.out.println("u-xcqa = " + calculaMax(listaNroDeComentariosPorPergunta));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaNroDeComentariosPorPergunta)+ " ";
					listaValoresFeatures.add(calculaMax(listaNroDeComentariosPorPergunta));
					if(listaNroDeComentariosPorPergunta.size() != Uqpa){
						//System.out.println("u-icqa = " + 0);
						//textoSaida += idAtualFeature++ + ":" + 0+ " ";
						listaValoresFeatures.add(.0);
					}
					else{
						//System.out.println("u-icq = " + calculaMin(listaNroDeComentariosPorPergunta));
						//textoSaida += idAtualFeature++ + ":" +  calculaMin(listaNroDeComentariosPorPergunta)+ " ";
						listaValoresFeatures.add(calculaMin(listaNroDeComentariosPorPergunta));
					}
					
					//Calcula o nro medio, max e min de comentarios presentes em perguntas daquele usuario (asker)
					//VERIFICADAS
					listaNroDeComentariosPorPergunta = encontraNroDeComentariosPorPergunta(idAsker);
					//System.out.println("u-acqq = " + calculaMedia(listaNroDeComentariosPorPergunta, nroPerguntasPostadas));
					//textoSaida += idAtualFeature++ + ":" +  calculaMedia(listaNroDeComentariosPorPergunta, Uqpq)+ " ";
					listaValoresFeatures.add(calculaMedia(listaNroDeComentariosPorPergunta, Uqpq));
					//System.out.println("u-xcqq = " + calculaMax(listaNroDeComentariosPorPergunta));
					//textoSaida += idAtualFeature++ + ":" + calculaMax(listaNroDeComentariosPorPergunta)+ " ";
					listaValoresFeatures.add(calculaMax(listaNroDeComentariosPorPergunta));
					if(listaNroDeComentariosPorPergunta.size() != Uqpq){
						//System.out.println("u-icqq = " + 0);
						//textoSaida += idAtualFeature++ + ":" + 0+ " ";
						listaValoresFeatures.add(.0);
					}
					else{
						//System.out.println("u-icq = " + calculaMin(listaNroDeComentariosPorPergunta));
						//textoSaida += idAtualFeature++ + ":" +  calculaMin(listaNroDeComentariosPorPergunta)+ " ";
						listaValoresFeatures.add(calculaMin(listaNroDeComentariosPorPergunta));
					}
						
								
					//Calcula o número de comentarios postados pelo answerer a perguntas e respostas
					//VERIFICADA
					int nroCommentariosTotal = calculaNroDeComentariosPostadosPorUsuario(idAnswerer);
					//System.out.println("u-aqca = " + nroCommentariosTotal);
					//textoSaida += idAtualFeature++ + ":" +nroCommentariosTotal+ " ";
					listaValoresFeatures.add(nroCommentariosTotal + .0);
					
					//Calcula o número de comentarios postados pelo asker a perguntas e respostas
					//VERIFICADA
					nroCommentariosTotal = calculaNroDeComentariosPostadosPorUsuario(idAsker);
					//System.out.println("u-aqcq = " + nroCommentariosTotal);
					//textoSaida += idAtualFeature++ + ":" + nroCommentariosTotal+ " ";
					listaValoresFeatures.add(nroCommentariosTotal + .0);
					
					//Calcula o nro de edicoes sugeridas pelo answerer
					//VERIFICADA
					int nroSugestoesDeEdicao = calculaNroDeEditsSugeridos(idAnswerer);
					//System.out.println("u-sea = " + nroSugestoesDeEdicao);
					//textoSaida +=  idAtualFeature++ + ":" + nroSugestoesDeEdicao + " ";
					listaValoresFeatures.add(nroSugestoesDeEdicao + .0);
					
					//Calcula o nro de edicoes sugeridas pelo asker
					//VERIFICADA
					nroSugestoesDeEdicao = calculaNroDeEditsSugeridos(idAsker);
					//System.out.println("u-seq = " + nroSugestoesDeEdicao);
					//textoSaida += idAtualFeature++ + ":" +nroSugestoesDeEdicao+ " ";
					listaValoresFeatures.add(nroSugestoesDeEdicao + .0);
					
					//Calcula o nro de edicoes sugeridas pelo answerer que forma aprovadas
					//VERIFICADA
					int nroSugestoesDeEdicaoAprovadas = calculaNroDeEditsAprovadosPropostosPorUsuario(idAnswerer);
					//System.out.println("u-asea = " + nroSugestoesDeEdicaoAprovadas);
					//textoSaida += idAtualFeature++ + ":" +nroSugestoesDeEdicaoAprovadas+ " ";
					listaValoresFeatures.add(nroSugestoesDeEdicaoAprovadas + .0);
					
					//Calcula o nro de edicoes sugeridas pelo asker que forma aprovadas
					//VERIFICADA
					nroSugestoesDeEdicaoAprovadas = calculaNroDeEditsAprovadosPropostosPorUsuario(idAsker);
					//System.out.println("u-aseq = " + nroSugestoesDeEdicaoAprovadas);
					//textoSaida += idAtualFeature++ + ":" +nroSugestoesDeEdicaoAprovadas+ " ";
					listaValoresFeatures.add(nroSugestoesDeEdicaoAprovadas + .0);
					
					//Calcula o nro de edicoes sugeridas pelo answerer que forma rejeitadas
					//VERIFICADA
					int nroSugestoesDeEdicaoRejeitadas = calculaNroDeEditsRejeitadosPropostosPorUsuario(idAnswerer);
					//System.out.println("u-sera = " + nroSugestoesDeEdicaoRejeitadas);
					//textoSaida +=  idAtualFeature++ + ":" +nroSugestoesDeEdicaoRejeitadas+ " ";
					listaValoresFeatures.add(nroSugestoesDeEdicaoRejeitadas + .0);
					
					//Calcula o nro de edicoes sugeridas pelo asker que forma rejeitadas
					//VERIFICADA
					nroSugestoesDeEdicaoRejeitadas = calculaNroDeEditsRejeitadosPropostosPorUsuario(idAsker);
					//System.out.println("u-serq = " + nroSugestoesDeEdicaoRejeitadas);
					//textoSaida += idAtualFeature++ + ":" +nroSugestoesDeEdicaoRejeitadas+ " ";
					listaValoresFeatures.add(nroSugestoesDeEdicaoRejeitadas + .0);
					
					//Calcula o número de edicoes feitas em respostas pelo answerer
					//VERIFICADA
					int nroEdicoesRespostas = calculaNroDeEdtisFeitosEmRespostas(idAnswerer);
					//System.out.println("u-edtaa = " + nroEdicoesRespostas);
					//textoSaida += idAtualFeature++ + ":" +nroEdicoesRespostas+ " ";
					listaValoresFeatures.add(nroEdicoesRespostas + .0);
					
					//Calcula o número de edicoes feitas em respostas pelo asker
					//VERIFICADA
					nroEdicoesRespostas = calculaNroDeEdtisFeitosEmRespostas(idAsker);
					//System.out.println("u-edtaq = " + nroEdicoesRespostas);
					//textoSaida += idAtualFeature++ + ":" +nroEdicoesRespostas+ " ";
					listaValoresFeatures.add(nroEdicoesRespostas + .0);
					
					
					//Calcula o número de edicoes feitas em perguntas pelo answerer
					//VERIFICADA
					int nroEdicoesPerguntas = calculaNroDeEdtisFeitosEmPerguntas(idAnswerer);
					//System.out.println("u-edtaa = " + nroEdicoesRespostas);
					//textoSaida += idAtualFeature++ + ":" +nroEdicoesPerguntas+ " ";
					listaValoresFeatures.add(nroEdicoesPerguntas + .0);
					
					//Calcula o número de edicoes feitas em perguntas pelo asker
					//VERIFICADA
					nroEdicoesPerguntas = calculaNroDeEdtisFeitosEmPerguntas(idAsker);
					//System.out.println("u-edtaq = " + nroEdicoesRespostas);
					//textoSaida += idAtualFeature++ + ":" +nroEdicoesPerguntas+ " ";
					listaValoresFeatures.add(nroEdicoesPerguntas + .0);
					
					//Calcula o nro medio, max e min de respostas presentes em perguntas daquele usuario (answerer)
					//VERIFICADAS
					List<Integer> listaNroDeRespostasPorPergunta = encontraNroDeRespostasPorPergunta(idAnswerer);
					//System.out.println("u-apqa = " + calculaMedia(listaNroDeRespostasPorPergunta, nroPerguntasPostadas));
					//textoSaida += idAtualFeature++ + ":" +calculaMedia(listaNroDeRespostasPorPergunta, Uqpa)+ " ";
					listaValoresFeatures.add(calculaMedia(listaNroDeRespostasPorPergunta, Uqpa));
					//System.out.println("u-xpqa = " + calculaMax(listaNroDeRespostasPorPergunta));
					//textoSaida += idAtualFeature++ + ":" + calculaMax(listaNroDeRespostasPorPergunta)+ " ";
					listaValoresFeatures.add(calculaMax(listaNroDeRespostasPorPergunta));
					if(listaNroDeRespostasPorPergunta.size() != Uqpa){
						//System.out.println("u-ipqa = " + 0);
						//textoSaida += idAtualFeature++ + ":" + 0+ " ";
						listaValoresFeatures.add(.0);
					}
					else{
						//System.out.println("u-ipqa = " + calculaMin(listaNroDeRespostasPorPergunta));
						//textoSaida += idAtualFeature++ + ":" + calculaMin(listaNroDeRespostasPorPergunta)+ " ";
						listaValoresFeatures.add(calculaMin(listaNroDeRespostasPorPergunta));
					}
					
					//Calcula o nro medio, max e min de respostas presentes em perguntas daquele usuario (asker)
					//VERIFICADAS
					listaNroDeRespostasPorPergunta = encontraNroDeRespostasPorPergunta(idAsker);
					//System.out.println("u-apqq = " + calculaMedia(listaNroDeRespostasPorPergunta, nroPerguntasPostadas));
					//textoSaida += idAtualFeature++ + ":" + calculaMedia(listaNroDeRespostasPorPergunta, Uqpq)+ " ";
					listaValoresFeatures.add(calculaMedia(listaNroDeRespostasPorPergunta, Uqpq));
					//System.out.println("u-xpqq = " + calculaMax(listaNroDeRespostasPorPergunta));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaNroDeRespostasPorPergunta)+ " ";
					listaValoresFeatures.add(calculaMax(listaNroDeRespostasPorPergunta));
					if(listaNroDeRespostasPorPergunta.size() != Uqpq){
						//System.out.println("u-ipqq = " + 0);
						//textoSaida += idAtualFeature++ + ":" +0+ " ";
						listaValoresFeatures.add(.0);
					}
					else{
						//System.out.println("u-ipqq = " + calculaMin(listaNroDeRespostasPorPergunta));
						//textoSaida += idAtualFeature++ + ":" +calculaMin(listaNroDeRespostasPorPergunta)+ " ";
						listaValoresFeatures.add(calculaMin(listaNroDeRespostasPorPergunta));
					}
						
					
					//Calcula o número de perguntas postadas pelo answerer com resposta aceita 
					//VERIFICADA
					int nrPerguntasPostadasComRespostaAceita = calculaNroDePerguntasPostadasQueForamResolvidas(idAnswerer);
					//System.out.println("u-selaa = " + nrPerguntasPostadasComRespostaAceita);
					//textoSaida += idAtualFeature++ + ":" +nrPerguntasPostadasComRespostaAceita+ " ";
					listaValoresFeatures.add(nrPerguntasPostadasComRespostaAceita + .0);
					
					//Calcula o número de perguntas postadas pelo asker com resposta aceita 
					//VERIFICADA
					nrPerguntasPostadasComRespostaAceita = calculaNroDePerguntasPostadasQueForamResolvidas(idAsker);
					//System.out.println("u-selaq = " + nrPerguntasPostadasComRespostaAceita);
					//textoSaida += idAtualFeature++ + ":" +nrPerguntasPostadasComRespostaAceita+ " ";
					listaValoresFeatures.add(nrPerguntasPostadasComRespostaAceita+.0);
					
					//Calcula a posicao do answerer no rank dos usuarios que mais fizeram perguntas
					//VERIFICADA
					//Caso o usuario nao tenha feito nenhuma pergunta, sua posicao sera a ultima do ranking +1
					int posicaoNoRankPerguntas = 0;
					if(mapRankingAskers.containsKey(idAnswerer))
						posicaoNoRankPerguntas = mapRankingAskers.get(idAnswerer);
					else
						posicaoNoRankPerguntas = ultimaPosicaoNoRankingDeAskers + 1;
					//System.out.println("u-rknqa = " + posicaoNoRankPerguntas);
					//textoSaida += idAtualFeature++ + ":" +posicaoNoRankPerguntas+ " ";
					listaValoresFeatures.add(posicaoNoRankPerguntas+.0);
					
					//Calcula a posicao do asker no rank dos usuarios que mais fizeram perguntas
					//VERIFICADA
					//Caso o usuario nao tenha feito nenhuma pergunta, sua posicao sera a ultima do ranking +1
					posicaoNoRankPerguntas = 0;
					if(mapRankingAskers.containsKey(idAsker))
						posicaoNoRankPerguntas = mapRankingAskers.get(idAsker);
					else
						posicaoNoRankPerguntas = ultimaPosicaoNoRankingDeAskers + 1;
					//System.out.println("u-rknqq = " + posicaoNoRankPerguntas);
					//textoSaida += idAtualFeature++ + ":" +posicaoNoRankPerguntas+ " ";
					listaValoresFeatures.add(posicaoNoRankPerguntas+.0);
				
					//Calcula a posicao do answerer no rank dos usuarios que mais fizeram respostas
					//VERIFICADA
					//Caso o usuario nao tenha feito nenhuma resposta, sua posicao sera a ultima do ranking +1
					int posicaoNoRankRespostas = 0;
					if(mapRankingAnswerers.containsKey(idAnswerer))
						posicaoNoRankRespostas = mapRankingAnswerers.get(idAnswerer);
					else
						posicaoNoRankRespostas = ultimaPosicaoNoRankingDeAnswerers + 1;
					//System.out.println("u-rknaa = " + posicaoNoRankRespostas);
					//textoSaida += idAtualFeature++ + ":" +posicaoNoRankRespostas+ " ";
					listaValoresFeatures.add(posicaoNoRankRespostas+.0);
					
					//Calcula a posicao do askers no rank dos usuarios que mais fizeram respostas
					//VERIFICADA
					//Caso o usuario nao tenha feito nenhuma resposta, sua posicao sera a ultima do ranking +1
					posicaoNoRankRespostas = 0;
					if(mapRankingAnswerers.containsKey(idAsker))
						posicaoNoRankRespostas = mapRankingAnswerers.get(idAsker);
					else
						posicaoNoRankRespostas = ultimaPosicaoNoRankingDeAnswerers + 1;
					//System.out.println("u-rknaq = " + posicaoNoRankRespostas);
					//textoSaida += idAtualFeature++ + ":" +posicaoNoRankRespostas+ " ";
					listaValoresFeatures.add(posicaoNoRankRespostas+.0);
					
					//Calcula a media do nro de perguntas postadas pelo answerer nas categorias de T, max e min
					//VERIFICADAS
					List<String> listaCategoriasDoPar = descobreCategoriasDaPergunta(idPergunta);
					List<Integer> listaNroPerguntasPostadasPorCategoriaPeloAnswerer = calculaNroDePerguntasPostadasPorCategoria(listaCategoriasDoPar, idAnswerer);
					//System.out.println("u-avqta = " + calculaMedia(listaNroPerguntasPostadasPorCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMedia(listaNroPerguntasPostadasPorCategoriaPeloAnswerer)+ " ";
					listaValoresFeatures.add(calculaMedia(listaNroPerguntasPostadasPorCategoriaPeloAnswerer)+.0);
					//System.out.println("u-xqta = " + calculaMax(listaNroPerguntasPostadasPorCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaNroPerguntasPostadasPorCategoriaPeloAnswerer)+ " ";
					listaValoresFeatures.add(calculaMax(listaNroPerguntasPostadasPorCategoriaPeloAnswerer)+.0);
					//System.out.println("u-mqta = " + calculaMin(listaNroPerguntasPostadasPorCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaNroPerguntasPostadasPorCategoriaPeloAnswerer)+ " ";
					listaValoresFeatures.add(calculaMin(listaNroPerguntasPostadasPorCategoriaPeloAnswerer)+.0);
					
					//Calcula a media do nro de perguntas postadas pelo asker nas categorias de T, max e min
					//VERIFICADAS
					//List<String> listaCategoriasDoPar = descobreCategoriasDaPergunta(idPergunta);
					List<Integer> listaNroPerguntasPostadasPorCategoriaPeloAsker = calculaNroDePerguntasPostadasPorCategoria(listaCategoriasDoPar, idAsker);
					//System.out.println("u-avqtq = " + calculaMedia(listaNroPerguntasPostadasPorCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMedia(listaNroPerguntasPostadasPorCategoriaPeloAsker)+ " ";
					listaValoresFeatures.add(calculaMedia(listaNroPerguntasPostadasPorCategoriaPeloAsker)+.0);
					//System.out.println("u-xqtq = " + calculaMax(listaNroPerguntasPostadasPorCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaNroPerguntasPostadasPorCategoriaPeloAsker)+ " ";
					listaValoresFeatures.add(calculaMax(listaNroPerguntasPostadasPorCategoriaPeloAsker)+.0);
					//System.out.println("u-mqtq = " + calculaMin(listaNroPerguntasPostadasPorCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaNroPerguntasPostadasPorCategoriaPeloAsker)+ " ";
					listaValoresFeatures.add(calculaMin(listaNroPerguntasPostadasPorCategoriaPeloAsker)+.0);
					
					//Calcula a media do nro de respostas postadas pelo answerer nas categorias de T, max e min
					//VERIFICADA
					List<Integer> listaNroRespostasPostadasPorCategoriaPeloAnswerer = calculaNroDeRespostasPostadasPorCategoria(listaCategoriasDoPar, idAnswerer);
					//System.out.println("u-aata = " + calculaMedia(listaNroRespostasPostadasPorCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMedia(listaNroRespostasPostadasPorCategoriaPeloAnswerer)+ " ";
					listaValoresFeatures.add(calculaMedia(listaNroRespostasPostadasPorCategoriaPeloAnswerer)+.0);
					//System.out.println("u-xata = " + calculaMax(listaNroRespostasPostadasPorCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaNroRespostasPostadasPorCategoriaPeloAnswerer)+ " ";
					listaValoresFeatures.add(calculaMax(listaNroRespostasPostadasPorCategoriaPeloAnswerer)+.0);
					//System.out.println("u-mata = " + calculaMin(listaNroRespostasPostadasPorCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaNroRespostasPostadasPorCategoriaPeloAnswerer)+ " ";
					listaValoresFeatures.add(calculaMin(listaNroRespostasPostadasPorCategoriaPeloAnswerer)+.0);
					
					//Calcula a media do nro de respostas postadas pelo asker nas categorias de T, max e min
					//VERIFICADA
					List<Integer> listaNroRespostasPostadasPorCategoriaPeloAsker = calculaNroDeRespostasPostadasPorCategoria(listaCategoriasDoPar, idAsker);
					//System.out.println("u-aatq = " + calculaMedia(listaNroRespostasPostadasPorCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMedia(listaNroRespostasPostadasPorCategoriaPeloAsker)+ " ";
					listaValoresFeatures.add(calculaMedia(listaNroRespostasPostadasPorCategoriaPeloAsker)+.0);
					//System.out.println("u-xatq = " + calculaMax(listaNroRespostasPostadasPorCategoria));
					//textoSaida += idAtualFeature++ + ":" + calculaMax(listaNroRespostasPostadasPorCategoriaPeloAsker) + " ";
					listaValoresFeatures.add(calculaMax(listaNroRespostasPostadasPorCategoriaPeloAsker)+.0);
					//System.out.println("u-matq = " + calculaMin(listaNroRespostasPostadasPorCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaNroRespostasPostadasPorCategoriaPeloAsker)+ " ";
					listaValoresFeatures.add(calculaMin(listaNroRespostasPostadasPorCategoriaPeloAsker)+.0);
					
					//Calcula a media do ranking de anwerers da posicao do answerer nas categorias de T, max e min
					//VERIFICADAS
					List<Integer> listaPosicoesRankingAnswerers = calculaListaComPosicoesNosRankings(idAnswerer, listaCategoriasDoPar, mapRankingDeAnswerersCategorias, mapUltimaPosicaoRankingDeRespostasPorCat);
					//System.out.println("u-arkata = " + calculaMedia(listaPosicoesRankingAnswerers));
					//textoSaida += idAtualFeature++ + ":" +calculaMedia(listaPosicoesRankingAnswerers)+ " ";
					listaValoresFeatures.add(calculaMedia(listaPosicoesRankingAnswerers)+.0);
					//System.out.println("u-mrkata = " + calculaMax(listaPosicoesRankingAnswerers));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaPosicoesRankingAnswerers)+ " ";
					listaValoresFeatures.add(calculaMax(listaPosicoesRankingAnswerers)+.0);
					//System.out.println("u-xrkata = " + calculaMin(listaPosicoesRankingAnswerers));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaPosicoesRankingAnswerers)+ " ";
					listaValoresFeatures.add(calculaMin(listaPosicoesRankingAnswerers)+.0);
					
					//Calcula a media do ranking de anwerers da posicao do asker nas categorias de T, max e min
					//VERIFICADAS
					listaPosicoesRankingAnswerers = calculaListaComPosicoesNosRankings(idAsker, listaCategoriasDoPar, mapRankingDeAnswerersCategorias, mapUltimaPosicaoRankingDeRespostasPorCat);
					//System.out.println("u-arkatq = " + calculaMedia(listaPosicoesRankingAnswerers));
					//textoSaida += idAtualFeature++ + ":" +calculaMedia(listaPosicoesRankingAnswerers)+ " ";
					listaValoresFeatures.add(calculaMedia(listaPosicoesRankingAnswerers)+.0);
					//System.out.println("u-mrkatq = " + calculaMax(listaPosicoesRankingAnswerers));
					//textoSaida += idAtualFeature++ + ":" + calculaMax(listaPosicoesRankingAnswerers)+ " ";
					listaValoresFeatures.add(calculaMax(listaPosicoesRankingAnswerers)+.0);
					//System.out.println("u-xrkatq = " + calculaMin(listaPosicoesRankingAnswerers));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaPosicoesRankingAnswerers)+ " ";
					listaValoresFeatures.add(calculaMin(listaPosicoesRankingAnswerers)+.0);
					
					//Calcula a media do ranking de askers da posicao do answerer nas categorias de T, max e min
					//VERIFICADAS
					List<Integer> listaPosicoesRankingAnskers = calculaListaComPosicoesNosRankings(idAnswerer, listaCategoriasDoPar, mapRankingDeAskersCategorias, mapUltimaPosicaoRankingDePerguntasPorCat);
					//System.out.println("u-arkqta = " + calculaMedia(listaPosicoesRankingAnskers));
					//textoSaida += idAtualFeature++ + ":" + calculaMedia(listaPosicoesRankingAnskers)+ " ";
					listaValoresFeatures.add(calculaMedia(listaPosicoesRankingAnskers)+.0);
					//System.out.println("u-xrkqta = " + calculaMax(listaPosicoesRankingAnskers));
					//textoSaida += idAtualFeature++ + ":" + calculaMax(listaPosicoesRankingAnskers)+ " ";
					listaValoresFeatures.add(calculaMax(listaPosicoesRankingAnskers)+.0);
					//System.out.println("u-mrkqta = " + calculaMin(listaPosicoesRankingAnskers));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaPosicoesRankingAnskers)+ " ";
					listaValoresFeatures.add(calculaMin(listaPosicoesRankingAnskers)+.0);
					
					//Calcula a media do ranking de askers da posicao do asker nas categorias de T, max e min
					//VERIFICADAS
					listaPosicoesRankingAnskers = calculaListaComPosicoesNosRankings(idAsker, listaCategoriasDoPar, mapRankingDeAskersCategorias, mapUltimaPosicaoRankingDePerguntasPorCat);
					//System.out.println("u-arkqtq = " + calculaMedia(listaPosicoesRankingAnskers));
					//textoSaida += idAtualFeature++ + ":" +calculaMedia(listaPosicoesRankingAnskers)+ " ";
					listaValoresFeatures.add(calculaMedia(listaPosicoesRankingAnskers)+.0);
					//System.out.println("u-xrkqtq = " + calculaMax(listaPosicoesRankingAnskers));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaPosicoesRankingAnskers)+ " ";
					listaValoresFeatures.add(calculaMax(listaPosicoesRankingAnskers)+.0);
					//System.out.println("u-mrkqtq = " + calculaMin(listaPosicoesRankingAnskers));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaPosicoesRankingAnskers)+ " ";
					listaValoresFeatures.add(calculaMin(listaPosicoesRankingAnskers)+.0);
					
					//Calcula a entropia do numero de posts (perguntas + respostas) postadas pelo answerer em cada uma das categorias
					//VERIFICADA
					double entropiaDePerguntasERespostas = calculaEntropiaDePerguntasERespostas(listaNroPerguntasPostadasPorCategoriaPeloAnswerer, listaNroRespostasPostadasPorCategoriaPeloAnswerer, normalizaEntropa);
					//System.out.println("u-etpta = " + entropiaDePerguntasERespostas);
					//textoSaida += idAtualFeature++ + ":" +entropiaDePerguntasERespostas+ " ";
					listaValoresFeatures.add(entropiaDePerguntasERespostas+.0);
					
					//Calcula a entropia do numero de posts (perguntas + respostas) postadas pelo asker em cada uma das categorias
					//VERIFICADA
					entropiaDePerguntasERespostas = calculaEntropiaDePerguntasERespostas(listaNroPerguntasPostadasPorCategoriaPeloAsker, listaNroRespostasPostadasPorCategoriaPeloAsker, normalizaEntropa);
					//System.out.println("u-etptq = " + entropiaDePerguntasERespostas);
					//textoSaida += idAtualFeature++ + ":" +entropiaDePerguntasERespostas+ " ";
					listaValoresFeatures.add(entropiaDePerguntasERespostas+.0);
					
					//Calcula a entropia do numero de perguntas postadas pelo answerer em cada uma das categorias
					//VERIFICADA
					double entropiaDePerguntas = calculaEntropia(listaNroPerguntasPostadasPorCategoriaPeloAnswerer, normalizaEntropa);
					//System.out.println("u-etata = " + entropiaDePerguntas);
					//textoSaida += idAtualFeature++ + ":" +entropiaDePerguntas+ " ";
					listaValoresFeatures.add(entropiaDePerguntas+.0);
					
					//Calcula a entropia do numero de perguntas postadas pelo asker em cada uma das categorias
					//VERIFICADA
					entropiaDePerguntas = calculaEntropia(listaNroPerguntasPostadasPorCategoriaPeloAsker, normalizaEntropa);
					//System.out.println("u-etatq = " + entropiaDePerguntas);
					//textoSaida += idAtualFeature++ + ":" + entropiaDePerguntas+ " ";
					listaValoresFeatures.add(entropiaDePerguntas+.0);
					
					//Calcula a entropia do numero de respostas postadas pelo answerer em cada uma das categorias
					//VERIFICADA
					double entropiaDeRespostas = calculaEntropia(listaNroRespostasPostadasPorCategoriaPeloAnswerer, normalizaEntropa);
					//System.out.println("u-etqta = " + entropiaDeRespostas);
					//textoSaida += idAtualFeature++ + ":" + entropiaDeRespostas+ " ";
					listaValoresFeatures.add(entropiaDeRespostas+.0);
					
					//Calcula a entropia do numero de respostas postadas pelo asker em cada uma das categorias
					//VERIFICADA
					entropiaDeRespostas = calculaEntropia(listaNroRespostasPostadasPorCategoriaPeloAsker, normalizaEntropa);
					//System.out.println("u-etqtq = " + entropiaDeRespostas);
					//textoSaida += idAtualFeature++ + ":" + entropiaDeRespostas+ " ";
					listaValoresFeatures.add(entropiaDeRespostas+.0);
					
					//Calcula o nro de categorias que o answerer é um top3 answerer
					//VERIFICADA
					int nroDeCategoriasQueOAnswererEhTop3Answerer = mapParaRankingDeRating.get(idAnswerer+"").getCategoriasEmQueEhTop3Answerer().size(); 
					//System.out.println("u-t3qa = " + nroDeCategoriasQueOUsuarioEhTop3Answerer);
					//textoSaida +=  idAtualFeature++ + ":" + nroDeCategoriasQueOAnswererEhTop3Answerer+ " ";
					listaValoresFeatures.add(nroDeCategoriasQueOAnswererEhTop3Answerer+.0);
					
					//Calcula o nro de categorias que o sker é um top3 answerer
					//VERIFICADA
					int nroDeCategoriasQueOAskerEhTop3Answerer = mapParaRankingDeRating.get(idAsker+"").getCategoriasEmQueEhTop3Answerer().size(); 
					//System.out.println("u-t3qq = " + nroDeCategoriasQueOUsuarioEhTop3Answerer);
					//textoSaida += idAtualFeature++ + ":" + nroDeCategoriasQueOAskerEhTop3Answerer+ " ";
					listaValoresFeatures.add(nroDeCategoriasQueOAskerEhTop3Answerer+.0);
					
					//Calcula o nro de categorias que o answerer é um top3 asker
					//VERIFICADA
					int nroDeCategoriasQueOAnswererEhTop3Asker = mapParaRankingDeRating.get(idAnswerer+"").getCategoriasEmQueEhTop3Asker().size(); 
					//System.out.println("u-t3aa = " + nroDeCategoriasQueOUsuarioEhTop3Asker);
					//textoSaida += idAtualFeature++ + ":" + nroDeCategoriasQueOAnswererEhTop3Asker+ " ";
					listaValoresFeatures.add(nroDeCategoriasQueOAnswererEhTop3Asker+.0);
					
					//Calcula o nro de categorias que o asker é um top3 asker
					//VERIFICADA
					int nroDeCategoriasQueOAskerEhTop3Asker = mapParaRankingDeRating.get(idAsker+"").getCategoriasEmQueEhTop3Asker().size(); 
					//System.out.println("u-t3aq = " + nroDeCategoriasQueOUsuarioEhTop3Asker);
					//textoSaida += idAtualFeature++ + ":" + nroDeCategoriasQueOAskerEhTop3Asker+ " ";
					listaValoresFeatures.add(nroDeCategoriasQueOAskerEhTop3Asker+.0);
								
					//Calcula u-t3qa / n. of categories answerer answered 
					//VERIFICADA
					//System.out.println("u-t3qna  = " + nroDeCategoriasQueOUsuarioEhTop3Answerer/(double)mapParaRankingDeRating.get(idAnswerer+"").getNroDeCategoriasQueJaRespondeu());
					double denominador = (double)mapParaRankingDeRating.get(idAnswerer+"").getNroDeCategoriasQueJaRespondeu();
					if(denominador == 0){
						//textoSaida += idAtualFeature++ + ":" + 0+ " ";
						listaValoresFeatures.add(.0);
					}else{
						//textoSaida += idAtualFeature++ + ":" + nroDeCategoriasQueOAnswererEhTop3Answerer/denominador + " ";
						listaValoresFeatures.add(nroDeCategoriasQueOAnswererEhTop3Answerer/denominador+.0);
					}
					
					//Calcula u-t3qq / n. of categories asker answered 
					//VERIFICADA
					//System.out.println("u-t3qnq  = " + nroDeCategoriasQueOUsuarioEhTop3Answerer/(double)mapParaRankingDeRating.get(idAnswerer+"").getNroDeCategoriasQueJaRespondeu());
					denominador = (double)mapParaRankingDeRating.get(idAsker+"").getNroDeCategoriasQueJaRespondeu();
					if(denominador == 0){
						//textoSaida += idAtualFeature++ + ":" + 0+ " ";
						listaValoresFeatures.add(.0);
					}else{
						//textoSaida += idAtualFeature++ + ":" +nroDeCategoriasQueOAskerEhTop3Answerer/denominador+ " ";
						listaValoresFeatures.add(nroDeCategoriasQueOAskerEhTop3Answerer/denominador+.0);
					}
					
					//Calcula u-t3aa / n. of categories answerer asked)
					//VERIFICADA
					//System.out.println("u-t3ana  = " + nroDeCategoriasQueOUsuarioEhTop3Asker/(double)mapParaRankingDeRating.get(idAnswerer+"").getNroDeCategoriasQueJaPerguntou());
					denominador = (double)mapParaRankingDeRating.get(idAnswerer+"").getNroDeCategoriasQueJaPerguntou();
					if(denominador == 0){
						//textoSaida += idAtualFeature++ + ":" + 0+ " ";
						listaValoresFeatures.add(.0);
					}else{
						//textoSaida += idAtualFeature++ + ":" + nroDeCategoriasQueOAnswererEhTop3Asker/denominador+ " ";
						listaValoresFeatures.add(nroDeCategoriasQueOAnswererEhTop3Asker/denominador+.0);
					}
					
					//u-t3aq / n. of categories asker asked
					//VERIFICADA
					//System.out.println("u-t3anq  = " + nroDeCategoriasQueOUsuarioEhTop3Asker/(double)mapParaRankingDeRating.get(idAnswerer+"").getNroDeCategoriasQueJaPerguntou());
					denominador = (double)mapParaRankingDeRating.get(idAsker+"").getNroDeCategoriasQueJaPerguntou();
					if(denominador == 0){
						//textoSaida += idAtualFeature++ + ":" + 0+ " ";
						listaValoresFeatures.add(.0);
					}else{
						//textoSaida += idAtualFeature++ + ":" +nroDeCategoriasQueOAskerEhTop3Asker/denominador+ " ";
						listaValoresFeatures.add(nroDeCategoriasQueOAskerEhTop3Asker/denominador+.0);
					}
					
					//Vamos preencher o map mapParaRankingDeRating com o score recebido a partir de perguntas e respostas para cada usuario dentro de cada uma das categorias
					//preencheMapParaRankingDeRatingPorCategoria(mapParaRankingDeRating, listaParaRankingDeRating, setCategoriasJaProcessadas, listaCategoriasDoPar);
					//Caso alguma categoria do par Q&A ainda nao tenha sido processado, preecehmos as informacoes para esta categoria
					preencheMapParaRankingDeScorePorCategoria(mapParaRankingDeRating, listaParaRankingDeRating, setCategoriasJaProcessadas, listaCategoriasDoPar, mapUltimaPosicaoRankingDeScoreDeRespostasPorCat, mapUltimaPosicaoRankingDeScoreDePerguntasPorCat, mapCategoriaId, listaCategoriasDoPar);
					
					//List<Integer> listaRatingRecebidoPorPerguntarEmCategorias = calculaRatingRecebidoPorPerguntarEmCategorias(idAnswerer, listaCategoriasDoPar, mapParaRankingDeRating);
					//System.out.println("u-artqt = " + calculaMedia(listaRatingRecebidoPorPerguntarEmCategorias));
					//System.out.println("u-xrtqt = " + calculaMax(listaRatingRecebidoPorPerguntarEmCategorias));
					//System.out.println("u-mrtqt = " + calculaMin(listaRatingRecebidoPorPerguntarEmCategorias));
					
					//Calcula a media do score recebido pelo answerer em cada uma das categoria por perguntar, max e min
					//VERIFICADAS
					List<Integer> listaScoreRecebidoPeloAnswererPorPerguntarEmCategorias = calculaScoreRecebidoPorPerguntarEmCategorias(idAnswerer, listaCategoriasDoPar, mapParaRankingDeRating);
					//System.out.println("u-artqta = " + calculaMedia(listaScoreRecebidoPorPerguntarEmCategorias));
					//textoSaida +=  idAtualFeature++ + ":" + calculaMedia(listaScoreRecebidoPeloAnswererPorPerguntarEmCategorias)+ " ";
					listaValoresFeatures.add(calculaMedia(listaScoreRecebidoPeloAnswererPorPerguntarEmCategorias)+.0);
					//System.out.println("u-xrtqta = " + calculaMax(listaScoreRecebidoPorPerguntarEmCategorias));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaScoreRecebidoPeloAnswererPorPerguntarEmCategorias)+ " ";
					listaValoresFeatures.add(calculaMax(listaScoreRecebidoPeloAnswererPorPerguntarEmCategorias)+.0);
					//System.out.println("u-mrtqta = " + calculaMin(listaScoreRecebidoPorPerguntarEmCategorias));
					//textoSaida += idAtualFeature++ + ":" + calculaMin(listaScoreRecebidoPeloAnswererPorPerguntarEmCategorias)+ " ";
					listaValoresFeatures.add(calculaMin(listaScoreRecebidoPeloAnswererPorPerguntarEmCategorias)+.0);
					
					//Calcula a media do score recebido pelo asker em cada uma das categoria por perguntar, max e min
					//VERIFICADAS
					List<Integer> listaScoreRecebidoPeloAskerPorPerguntarEmCategorias = calculaScoreRecebidoPorPerguntarEmCategorias(idAsker, listaCategoriasDoPar, mapParaRankingDeRating);
					//System.out.println("u-artqtq = " + calculaMedia(listaScoreRecebidoPorPerguntarEmCategorias));
					//textoSaida += idAtualFeature++ + ":" +calculaMedia(listaScoreRecebidoPeloAskerPorPerguntarEmCategorias)+ " ";
					listaValoresFeatures.add(calculaMedia(listaScoreRecebidoPeloAskerPorPerguntarEmCategorias)+.0);
					//System.out.println("u-xrtqtq = " + calculaMax(listaScoreRecebidoPorPerguntarEmCategorias));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaScoreRecebidoPeloAskerPorPerguntarEmCategorias)+ " ";
					listaValoresFeatures.add(calculaMax(listaScoreRecebidoPeloAskerPorPerguntarEmCategorias)+.0);
					//System.out.println("u-mrtqtq = " + calculaMin(listaScoreRecebidoPorPerguntarEmCategorias));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaScoreRecebidoPeloAskerPorPerguntarEmCategorias)+ " ";
					listaValoresFeatures.add(calculaMin(listaScoreRecebidoPeloAskerPorPerguntarEmCategorias)+.0);
					
					//List<Integer> listaRatingRecebidoPorResponderEmCategorias = calculaRatingRecebidoPorResponderEmCategorias(idAnswerer, listaCategoriasDoPar, mapParaRankingDeRating);
					//System.out.println("u-artat = " + calculaMedia(listaRatingRecebidoPorResponderEmCategorias));
					//System.out.println("u-xrtat = " + calculaMax(listaRatingRecebidoPorResponderEmCategorias));
					//System.out.println("u-mrtat = " + calculaMin(listaRatingRecebidoPorResponderEmCategorias));
					
					//Calcula a media do score recebido pelo answerer em cada uma das categoria por responder, max e min
					//VERIFICADAS
					List<Integer> listaScoreRecebidoPeloAnswererPorResponderEmCategorias = calculaScoreRecebidoPorResponderEmCategorias(idAnswerer, listaCategoriasDoPar, mapParaRankingDeRating);
					//System.out.println("u-artata = " + calculaMedia(listaScoreRecebidoPorResponderEmCategorias));
					//textoSaida += idAtualFeature++ + ":" + calculaMedia(listaScoreRecebidoPeloAnswererPorResponderEmCategorias)+ " ";
					listaValoresFeatures.add(calculaMedia(listaScoreRecebidoPeloAnswererPorResponderEmCategorias)+.0);
					//System.out.println("u-xrtaat = " + calculaMax(listaScoreRecebidoPorResponderEmCategorias));
					//textoSaida += idAtualFeature++ + ":" + calculaMax(listaScoreRecebidoPeloAnswererPorResponderEmCategorias)+ " ";
					listaValoresFeatures.add(calculaMax(listaScoreRecebidoPeloAnswererPorResponderEmCategorias)+.0);
					//System.out.println("u-mrtata = " + calculaMin(listaScoreRecebidoPorResponderEmCategorias));
					//textoSaida += idAtualFeature++ + ":" + calculaMin(listaScoreRecebidoPeloAnswererPorResponderEmCategorias)+ " ";
					listaValoresFeatures.add(calculaMin(listaScoreRecebidoPeloAnswererPorResponderEmCategorias)+.0);
					
					//Calcula a media do score recebido pelo asker em cada uma das categoria por responder, max e min
					//VERIFICADAS
					List<Integer> listaScoreRecebidoPeloAskerPorResponderEmCategorias = calculaScoreRecebidoPorResponderEmCategorias(idAsker, listaCategoriasDoPar, mapParaRankingDeRating);
					//System.out.println("u-artatq = " + calculaMedia(listaScoreRecebidoPorResponderEmCategorias));
					//textoSaida += idAtualFeature++ + ":" +calculaMedia(listaScoreRecebidoPeloAskerPorResponderEmCategorias)+ " ";
					listaValoresFeatures.add(calculaMedia(listaScoreRecebidoPeloAskerPorResponderEmCategorias)+.0);
					//System.out.println("u-xrtatq = " + calculaMax(listaScoreRecebidoPorResponderEmCategorias));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaScoreRecebidoPeloAskerPorResponderEmCategorias)+ " ";
					listaValoresFeatures.add(calculaMax(listaScoreRecebidoPeloAskerPorResponderEmCategorias)+.0);
					//System.out.println("u-mrtatq = " + calculaMin(listaScoreRecebidoPorResponderEmCategorias));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaScoreRecebidoPeloAskerPorResponderEmCategorias)+ " ";
					listaValoresFeatures.add(calculaMin(listaScoreRecebidoPeloAskerPorResponderEmCategorias)+.0);
					
					//Calcula o score conquistado pelo answerer por perguntar nas categorias de T
					//VERIFICADA
					int ratingRecebidoPorPerguntarNasCategoriasDeT = calculaSomaDeLista(listaScoreRecebidoPeloAnswererPorPerguntarEmCategorias);
					//System.out.println("u-srtqta = " + ratingRecebidoPorPerguntarNasCategoriasDeT);
					//textoSaida += idAtualFeature++ + ":" +ratingRecebidoPorPerguntarNasCategoriasDeT+ " ";
					listaValoresFeatures.add(ratingRecebidoPorPerguntarNasCategoriasDeT+.0);
					
					//Calcula o score conquistado pelo asker por perguntar nas categorias de T
					//VERIFICADA
					ratingRecebidoPorPerguntarNasCategoriasDeT = calculaSomaDeLista(listaScoreRecebidoPeloAskerPorPerguntarEmCategorias);
					//System.out.println("u-srtqtq = " + ratingRecebidoPorPerguntarNasCategoriasDeT);
					//textoSaida += idAtualFeature++ + ":" +ratingRecebidoPorPerguntarNasCategoriasDeT+ " ";
					listaValoresFeatures.add(ratingRecebidoPorPerguntarNasCategoriasDeT+.0);
					
					//int ratingRecebidoPorPerguntarNasCategoriasDeT = calculaSomaDeLista(listaRatingRecebidoPorPerguntarEmCategorias);
					//System.out.println("u-srtqt = " + ratingRecebidoPorPerguntarNasCategoriasDeT);
					
					//Calcula o score conquistado pelo answerer por responder nas categorias de T
					//VERIFICADA
					int ratingRecebidoPorResponderNasCategoriasDeT = calculaSomaDeLista(listaScoreRecebidoPeloAnswererPorResponderEmCategorias);
					//System.out.println("u-srtata = " + ratingRecebidoPorResponderNasCategoriasDeT);
					//textoSaida += idAtualFeature++ + ":" +ratingRecebidoPorResponderNasCategoriasDeT+ " ";
					listaValoresFeatures.add(ratingRecebidoPorResponderNasCategoriasDeT+.0);
					
					//Calcula o score conquistado pelo asker por responder nas categorias de T
					//VERIFICADA
					ratingRecebidoPorResponderNasCategoriasDeT = calculaSomaDeLista(listaScoreRecebidoPeloAskerPorResponderEmCategorias);
					//System.out.println("u-srtatq = " + ratingRecebidoPorResponderNasCategoriasDeT);
					//textoSaida += idAtualFeature++ + ":" +ratingRecebidoPorResponderNasCategoriasDeT+ " ";
					listaValoresFeatures.add(ratingRecebidoPorResponderNasCategoriasDeT+.0);
					
					//int ratingRecebidoPorResponderNasCategoriasDeT = calculaSomaDeLista(listaRatingRecebidoPorResponderEmCategorias);
					//System.out.println("u-srtat = " + ratingRecebidoPorResponderNasCategoriasDeT);
				
					//Calcula posicao do answerer no rank de usuarios de acordo com o score recebido por perguntar
					//VERIFICADA
					//ComparatorRatingPerguntas comparatorPerguntas = new ComparatorRatingPerguntas();
					//System.out.println(listaParaRankingDeRating.get(0).getScoreRecebidoPorPerguntar() + " " + listaParaRankingDeRating.get(listaParaRankingDeRating.size()-1).getScoreRecebidoPorPerguntar() );
					//determinaOrdenacaoPorRatingDePerguntas(listaParaRankingDeRating);
					int posicaoDoRankingDeScoreDePerguntas = ultimaPosicaoDoRankingDePerguntas;
					if(mapParaRankingDeRating.containsKey(idAnswerer+""))
						posicaoDoRankingDeScoreDePerguntas = mapParaRankingDeRating.get(idAnswerer+"").getPosicaoNoRankingDeScoreDePerguntas();
					//System.out.println("u-rkqa = " + posicaoDoRankingDeScoreDePerguntas);
					//textoSaida += idAtualFeature++ + ":" +posicaoDoRankingDeScoreDePerguntas+ " ";
					listaValoresFeatures.add(posicaoDoRankingDeScoreDePerguntas+.0);
					
					//Calcula posicao do asker no rank de usuarios de acordo com o score recebido por perguntar
					//VERIFICADA
					//ComparatorRatingPerguntas comparatorPerguntas = new ComparatorRatingPerguntas();
					//System.out.println(listaParaRankingDeRating.get(0).getScoreRecebidoPorPerguntar() + " " + listaParaRankingDeRating.get(listaParaRankingDeRating.size()-1).getScoreRecebidoPorPerguntar() );
					//determinaOrdenacaoPorRatingDePerguntas(listaParaRankingDeRating);
					posicaoDoRankingDeScoreDePerguntas = ultimaPosicaoDoRankingDePerguntas;
					if(mapParaRankingDeRating.containsKey(idAsker+""))
						posicaoDoRankingDeScoreDePerguntas = mapParaRankingDeRating.get(idAsker+"").getPosicaoNoRankingDeScoreDePerguntas();
					//System.out.println("u-rkqq = " + posicaoDoRankingDeScoreDePerguntas);
					//textoSaida += idAtualFeature++ + ":" +posicaoDoRankingDeScoreDePerguntas + " ";
					listaValoresFeatures.add(posicaoDoRankingDeScoreDePerguntas+.0);
					
					//Calcula posicao do answerer no rank de usuarios de acordo com o score recebido por responder
					//VERIFICADA
					//determinaOrdenacaoPorRatingDeRespostas(listaParaRankingDeRating);
					int posicaoDoRankingDeScoreDeRespostas = ultimaPosicaoDoRankingDeRespostas;
					if(mapParaRankingDeRating.containsKey(idAnswerer+""))
						posicaoDoRankingDeScoreDeRespostas = mapParaRankingDeRating.get(idAnswerer+"").getPosicaoNoRankingDeScoreDeRespostas(); 
					//System.out.println("u-rkaa = " + posicaoDoRankingDeScoreDeRespostas);
					//textoSaida += idAtualFeature++ + ":" +posicaoDoRankingDeScoreDeRespostas+ " ";
					listaValoresFeatures.add(posicaoDoRankingDeScoreDeRespostas+.0);
					
					//Calcula posicao do asker no rank de usuarios de acordo com o score recebido por responder
					//VERIFICADA
					//determinaOrdenacaoPorRatingDeRespostas(listaParaRankingDeRating);
					posicaoDoRankingDeScoreDeRespostas = ultimaPosicaoDoRankingDeRespostas;
					if(mapParaRankingDeRating.containsKey(idAsker+""))
						posicaoDoRankingDeScoreDeRespostas = mapParaRankingDeRating.get(idAsker+"").getPosicaoNoRankingDeScoreDeRespostas(); 
					//System.out.println("u-rkaq = " + posicaoDoRankingDeScoreDeRespostas);
					//textoSaida += idAtualFeature++ + ":" +posicaoDoRankingDeScoreDeRespostas+ " ";
					listaValoresFeatures.add(posicaoDoRankingDeScoreDeRespostas+.0);
					
					//Calcula o rating (score) recebido pelo answerer por perguntar
					//VERIFICADA
					//int reputacaoRecebidaPorPerguntar = calculaReputacaoRecebidaPorPerguntar(idAnswerer);
					int scoreRecebidoPorPerguntar = mapParaRankingDeRating.get(idAnswerer+"").getScoreRecebidoPorPerguntar();
					if(scoreRecebidoPorPerguntar == Integer.MIN_VALUE)
						scoreRecebidoPorPerguntar = 0;
					//System.out.println("u-rtqa = " + scoreRecebidoPorPerguntar);
					//textoSaida += idAtualFeature++ + ":" +scoreRecebidoPorPerguntar+ " ";
					listaValoresFeatures.add(scoreRecebidoPorPerguntar+.0);
					
					//Calcula o rating (score) recebido pelo asker por perguntar
					//VERIFICADA
					//int reputacaoRecebidaPorPerguntar = calculaReputacaoRecebidaPorPerguntar(idAnswerer);
					scoreRecebidoPorPerguntar = mapParaRankingDeRating.get(idAsker+"").getScoreRecebidoPorPerguntar();
					if(scoreRecebidoPorPerguntar == Integer.MIN_VALUE)
						scoreRecebidoPorPerguntar = 0;
					//System.out.println("u-rtqq = " + scoreRecebidoPorPerguntar);
					//textoSaida += idAtualFeature++ + ":" +scoreRecebidoPorPerguntar+ " ";
					listaValoresFeatures.add(scoreRecebidoPorPerguntar+.0);
					
					//Calcula o score recebido pelo answerer por responder
					//VERIFICADA
					//int reputacaoRecebidaPorResponder = calculaReputacaoRecebidaPorResponder(idAnswerer);
					int scoreRecebidoPorResponder = mapParaRankingDeRating.get(idAnswerer+"").getScoreRecebidoPorResponder();
					if(scoreRecebidoPorResponder == Integer.MIN_VALUE)
						scoreRecebidoPorResponder = 0;
					//System.out.println("u-rtaa = " + scoreRecebidoPorResponder);
					//textoSaida += idAtualFeature++ + ":" +scoreRecebidoPorResponder+ " ";
					listaValoresFeatures.add(scoreRecebidoPorResponder+.0);
					
					//Calcula o score recebido pelo asker por responder
					//VERIFICADA
					//int reputacaoRecebidaPorResponder = calculaReputacaoRecebidaPorResponder(idAnswerer);
					scoreRecebidoPorResponder = mapParaRankingDeRating.get(idAsker+"").getScoreRecebidoPorResponder();
					if(scoreRecebidoPorResponder == Integer.MIN_VALUE)
						scoreRecebidoPorResponder = 0;
					//System.out.println("u-rtaq = " + scoreRecebidoPorResponder);
					//textoSaida += idAtualFeature++ + ":" +scoreRecebidoPorResponder+ " ";
					listaValoresFeatures.add(scoreRecebidoPorResponder+.0);
					
					//Calcula a posicao media no ranking de score de respostas das categorias, max e min (para o answserer)
					//VERIFICADA
					List<Integer> posicoesNosRankingDeRespostasDeCadaCategoria = calculaPosicoesNosRankingDeScoreRespostasDeCadaCategoria(idAnswerer, mapParaRankingDeRating, listaCategoriasDoPar, mapUltimaPosicaoRankingDeScoreDeRespostasPorCat);
					//System.out.println("u-arktaa = " + calculaMedia(posicoesNosRankingDeRespostasDeCadaCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMedia(posicoesNosRankingDeRespostasDeCadaCategoria)+ " ";
					listaValoresFeatures.add(calculaMedia(posicoesNosRankingDeRespostasDeCadaCategoria)+.0);
					//System.out.println("u-xrktaa = " + calculaMax(posicoesNosRankingDeRespostasDeCadaCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(posicoesNosRankingDeRespostasDeCadaCategoria)+ " ";
					listaValoresFeatures.add(calculaMax(posicoesNosRankingDeRespostasDeCadaCategoria)+.0);
					//System.out.println("u-mrktaa = " + calculaMin(posicoesNosRankingDeRespostasDeCadaCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(posicoesNosRankingDeRespostasDeCadaCategoria)+ " ";
					listaValoresFeatures.add(calculaMin(posicoesNosRankingDeRespostasDeCadaCategoria)+.0);
					
					//Calcula a posicao media no ranking de score de respostas das categorias, max e min (para o asker)
					//VERIFICADA
					posicoesNosRankingDeRespostasDeCadaCategoria = calculaPosicoesNosRankingDeScoreRespostasDeCadaCategoria(idAsker, mapParaRankingDeRating, listaCategoriasDoPar, mapUltimaPosicaoRankingDeScoreDeRespostasPorCat);
					//System.out.println("u-arktaq = " + calculaMedia(posicoesNosRankingDeRespostasDeCadaCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMedia(posicoesNosRankingDeRespostasDeCadaCategoria)+ " ";
					listaValoresFeatures.add(calculaMedia(posicoesNosRankingDeRespostasDeCadaCategoria)+.0);
					//System.out.println("u-xrktaq = " + calculaMax(posicoesNosRankingDeRespostasDeCadaCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(posicoesNosRankingDeRespostasDeCadaCategoria)+ " ";
					listaValoresFeatures.add(calculaMax(posicoesNosRankingDeRespostasDeCadaCategoria)+.0);
					//System.out.println("u-mrktaq = " + calculaMin(posicoesNosRankingDeRespostasDeCadaCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(posicoesNosRankingDeRespostasDeCadaCategoria)+ " ";
					listaValoresFeatures.add(calculaMin(posicoesNosRankingDeRespostasDeCadaCategoria)+.0);
					
					//List<Integer> posicoesNosRankingDeRespostasDeCadaCategoria = calculaPosicoesNosRankingDeRespostasDeCadaCategoria(idAnswerer, mapParaRankingDeRating, listaParaRankingDeRating, setCategoriasJaProcessadas, listaCategoriasDoPar);
					//System.out.println("u-arkta = " + calculaMedia(posicoesNosRankingDeRespostasDeCadaCategoria));
					//System.out.println("u-xrkta = " + calculaMax(posicoesNosRankingDeRespostasDeCadaCategoria));
					//System.out.println("u-mrkta = " + calculaMin(posicoesNosRankingDeRespostasDeCadaCategoria));
					
					//Calcula a posicao media no ranking de score de perguntas das categorias, max e min (para o answerer)
					//VERIFICADA
					if(idResposta == 14647829){
						int a = 0;
						int b=a;
					}
					
					List<Integer> posicoesNosRankingDePerguntasDeCadaCategoria = calculaPosicoesNosRankingDeScorePerguntasDeCadaCategoria(idAnswerer, mapParaRankingDeRating, listaCategoriasDoPar, mapUltimaPosicaoRankingDeScoreDePerguntasPorCat);
					//System.out.println("u-arktqa = " + calculaMedia(posicoesNosRankingDePerguntasDeCadaCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMedia(posicoesNosRankingDePerguntasDeCadaCategoria)+ " ";
					double asas = calculaMedia(posicoesNosRankingDePerguntasDeCadaCategoria)+.0;
					
					
					listaValoresFeatures.add(calculaMedia(posicoesNosRankingDePerguntasDeCadaCategoria)+.0);
					//System.out.println("u-xrktqa = " + calculaMax(posicoesNosRankingDePerguntasDeCadaCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(posicoesNosRankingDePerguntasDeCadaCategoria)+ " ";
					listaValoresFeatures.add(calculaMax(posicoesNosRankingDePerguntasDeCadaCategoria)+.0);
					//System.out.println("u-mrktqa = " + calculaMin(posicoesNosRankingDePerguntasDeCadaCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(posicoesNosRankingDePerguntasDeCadaCategoria)+ " ";
					listaValoresFeatures.add(calculaMin(posicoesNosRankingDePerguntasDeCadaCategoria)+.0);
					
					//Calcula a posicao media no ranking de score de perguntas das categorias, max e min (para o asker)
					//VERIFICADA
					posicoesNosRankingDePerguntasDeCadaCategoria = calculaPosicoesNosRankingDeScorePerguntasDeCadaCategoria(idAsker, mapParaRankingDeRating, listaCategoriasDoPar, mapUltimaPosicaoRankingDeScoreDePerguntasPorCat);
					//System.out.println("u-arktqq = " + calculaMedia(posicoesNosRankingDePerguntasDeCadaCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMedia(posicoesNosRankingDePerguntasDeCadaCategoria)+ " ";
					listaValoresFeatures.add(calculaMedia(posicoesNosRankingDePerguntasDeCadaCategoria)+.0);
					//System.out.println("u-xrktqq = " + calculaMax(posicoesNosRankingDePerguntasDeCadaCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(posicoesNosRankingDePerguntasDeCadaCategoria)+ " ";
					listaValoresFeatures.add(calculaMax(posicoesNosRankingDePerguntasDeCadaCategoria)+.0);
					//System.out.println("u-mrktqq = " + calculaMin(posicoesNosRankingDePerguntasDeCadaCategoria));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(posicoesNosRankingDePerguntasDeCadaCategoria)+ " ";
					listaValoresFeatures.add(calculaMin(posicoesNosRankingDePerguntasDeCadaCategoria)+.0);
					
					//List<Integer> posicoesNosRankingDePerguntasDeCadaCategoria = calculaPosicoesNosRankingDePerguntasDeCadaCategoria(idAnswerer, mapParaRankingDeRating, listaParaRankingDeRating, setCategoriasJaProcessadas, listaCategoriasDoPar);
					//System.out.println("u-arktq = " + calculaMedia(posicoesNosRankingDePerguntasDeCadaCategoria));
					//System.out.println("u-xrktq = " + calculaMax(posicoesNosRankingDePerguntasDeCadaCategoria));
					//System.out.println("u-mrktq = " + calculaMin(posicoesNosRankingDePerguntasDeCadaCategoria));
					
					for(int i=0; i< listaCategoriasDoPar.size(); i++){
						setCategoriasJaProcessadas.add(listaCategoriasDoPar.get(i));
					}
					System.out.println("setCategoriasJaProcessadas size :" + setCategoriasJaProcessadas.size());
					
					//Calcula a reputacao total do answerer
					int reputacaoUsuario = calculaReputacaoDeUsuario(idAnswerer);
					//System.out.println("u-repa = " + reputacaoAsker);
					//textoSaida += idAtualFeature++ + ":" +reputacaoUsuario+ " ";
					listaValoresFeatures.add(reputacaoUsuario+.0);
					
					//Calcula a reputacao total do asker
					reputacaoUsuario = calculaReputacaoDeUsuario(idAsker);
					//System.out.println("u-repq = " + reputacaoAsker);
					//textoSaida += idAtualFeature++ + ":" +reputacaoUsuario+ " ";
					listaValoresFeatures.add(reputacaoUsuario+.0);
					
					/*******************************************************Review features*************************************************************/
					
					//Calcula o nro de edicoes que a resposta ja teve
					//VERIFICADA
					int nroEdicoesNaResposta = calculaNroEdicoesNaResposta(idResposta);
					//System.out.println("r-counta = " + nroEdicoesNaResposta);
					//textoSaida += idAtualFeature++ + ":" +nroEdicoesNaResposta+ " ";
					listaValoresFeatures.add(nroEdicoesNaResposta+.0);
					
					//Calcula o nro de edicoes que a pergunta ja teve
					//VERIFICADA
					int nroEdicoesNaPergunta= calculaNroEdicoesNaPergunta(idPergunta);
					//System.out.println("r-countq = " + nroEdicoesNaPergunta);
					//textoSaida += idAtualFeature++ + ":" +nroEdicoesNaPergunta+ " ";
					listaValoresFeatures.add(nroEdicoesNaPergunta+.0);
					
					//Calcula o a idade (em dias) da reposta
					//VERIFICADA
					int idadeResposta = calculaIdadePost(idResposta);
					//System.out.println("r-aage = " + idadeResposta);
					//textoSaida += idAtualFeature++ + ":" +idadeResposta+ " ";
					listaValoresFeatures.add(idadeResposta+.0);
					
					//Calcula o a idade (em dias) da pergunta
					//VERIFICADA
					int idadePergunta = calculaIdadePost(idPergunta);
					//System.out.println("r-qage  = " + idadePergunta);
					//textoSaida += idAtualFeature++ + ":" +idadePergunta+ " ";
					listaValoresFeatures.add(idadePergunta+.0);
					
					//Calcula o nro de usuarios que editarem a resposta
					//VERIFICADA
					int nroEditoresDaResposta = calculaNroDeUsuariosQueEditaramAReposta(idResposta);
					//System.out.println("r-uedia = " + nroEditoresDaResposta);
					//textoSaida += idAtualFeature++ + ":" +nroEditoresDaResposta+ " ";
					listaValoresFeatures.add(nroEditoresDaResposta+.0);
					
					//Calcula o nro de usuarios que editarem a pergunta
					//VERIFICADA
					int nroEditoresDaPergunta = calculaNroDeUsuariosQueEditaramAPergunta(idPergunta);
					//System.out.println("r-uediq = " + nroEditoresDaPergunta);
					//textoSaida += idAtualFeature++ + ":" +nroEditoresDaPergunta+ " ";
					listaValoresFeatures.add(nroEditoresDaPergunta+.0);
					
					//Calcula o nro medio de edicoes por usuario e o desvio padrao (na resposta)
					//VERIFICADA
					List<Integer> listaNroEdicoes = calculaListaNroDeEdicoesPorUsuarioNaResposta(idResposta);
					double mediaDoNroDeEdicoesPorUsuario = calculaMedia(listaNroEdicoes);
					double desvioDoNroDeEdicoesPorUsuario = calculaDesvioPadrao(listaNroEdicoes, mediaDoNroDeEdicoesPorUsuario);
					//System.out.println("r-aepua = " + mediaDoNroDeEdicoesPorUsuario);
					//textoSaida += idAtualFeature++ + ":" +mediaDoNroDeEdicoesPorUsuario+ " ";
					listaValoresFeatures.add(mediaDoNroDeEdicoesPorUsuario+.0);
					//System.out.println("r-sepua = " + desvioDoNroDeEdicoesPorUsuario);
					//textoSaida += idAtualFeature++ + ":" +desvioDoNroDeEdicoesPorUsuario+ " ";
					listaValoresFeatures.add(desvioDoNroDeEdicoesPorUsuario+.0);
					
					//Calcula o nro medio de edicoes por usuario e o desvio padrao (na pergunta)
					//VERIFICADA
					listaNroEdicoes = calculaListaNroDeEdicoesPorUsuarioNaPergunta(idPergunta);
					mediaDoNroDeEdicoesPorUsuario = calculaMedia(listaNroEdicoes);
					desvioDoNroDeEdicoesPorUsuario = calculaDesvioPadrao(listaNroEdicoes, mediaDoNroDeEdicoesPorUsuario);
					//System.out.println("r-aepuq = " + mediaDoNroDeEdicoesPorUsuario);
					//textoSaida += idAtualFeature++ + ":" +mediaDoNroDeEdicoesPorUsuario+ " ";
					listaValoresFeatures.add(mediaDoNroDeEdicoesPorUsuario+.0);
					//System.out.println("r-sepuq = " + desvioDoNroDeEdicoesPorUsuario);
					//textoSaida += idAtualFeature++ + ":" +desvioDoNroDeEdicoesPorUsuario+ " ";
					listaValoresFeatures.add(desvioDoNroDeEdicoesPorUsuario+.0);
					
					//Calcula o nro de edicoes sugeridas a resposta
					//VERIFICADA
					int nroSugestoesDeEdicaoAResposta = calculaNroDeEdicoesSugeridasAPost(idResposta);
					//System.out.println("r-ase = " + nroSugestoesDeEdicaoAResposta);
					//textoSaida += idAtualFeature++ + ":" +nroSugestoesDeEdicaoAResposta+ " ";
					listaValoresFeatures.add(nroSugestoesDeEdicaoAResposta+.0);
					
					//Calcula o nro de edicoes sugeridas a pergunta
					//VERIFICADA
					int nroSugestoesDeEdicaoAPergunta= calculaNroDeEdicoesSugeridasAPost(idPergunta);
					//System.out.println("r-qse = " + nroSugestoesDeEdicaoAPergunta);
					//textoSaida += idAtualFeature++ + ":" +nroSugestoesDeEdicaoAPergunta+ " ";
					listaValoresFeatures.add(nroSugestoesDeEdicaoAPergunta+.0);
					
					//Calcula o nro de usuarios que sugeriram edicoes a pergunta ou resposta
					//VERIFICADA
					int nroDeUsuariosQueSugeriramEdicoes = calculaNroDeUsuariosQueSugeriramEdicoes(idResposta, idPergunta);
					//System.out.println("r-suc = " + nroDeUsuariosQueSugeriramEdicoes);
					//textoSaida += idAtualFeature++ + ":" +nroDeUsuariosQueSugeriramEdicoes+ " ";
					listaValoresFeatures.add(nroDeUsuariosQueSugeriramEdicoes+.0);
					
					//Calcula o nro de edits aprovados na resposta
					//VERIFICADA
					int nroSugestoesDeEdicaoAprovadasNaResposta = calculaNroDeEditsSugeridosAprovadosEmPost(idResposta);
					//System.out.println("r-qas = " + nroSugestoesDeEdicaoAprovadasNaResposta);
					//textoSaida += idAtualFeature++ + ":" +nroSugestoesDeEdicaoAprovadasNaResposta+ " ";
					listaValoresFeatures.add(nroSugestoesDeEdicaoAprovadasNaResposta+.0);
					
					//Calcula o nro de edits rejeitados na resposta
					//VERIFICADA
					int nroSugestoesDeEdicaoRejeitadasNaResposta = calculaNroDeEditsSugeridosRejeitadosEmPost(idResposta);
					//System.out.println("r-aas = " + nroSugestoesDeEdicaoRejeitadasNaResposta);
					//textoSaida += idAtualFeature++ + ":" +nroSugestoesDeEdicaoRejeitadasNaResposta+ " ";
					listaValoresFeatures.add(nroSugestoesDeEdicaoRejeitadasNaResposta+.0);
					
					//Calcula o nro de edits aprovados na pergunta
					//VERIFICADA
					int nroSugestoesDeEdicaoAprovadasNaPergunta = calculaNroDeEditsSugeridosAprovadosEmPost(idPergunta);
					//System.out.println("r-aas = " + nroSugestoesDeEdicaoAprovadasNaPergunta);
					//textoSaida += idAtualFeature++ + ":" +nroSugestoesDeEdicaoAprovadasNaPergunta+ " ";
					listaValoresFeatures.add(nroSugestoesDeEdicaoAprovadasNaPergunta+.0);
					
					//Calcula o nro de edits rejeitados na pergunta
					//VERIFICADA
					int nroSugestoesDeEdicaoRejeitadasNaPergunta = calculaNroDeEditsSugeridosRejeitadosEmPost(idPergunta);
					//System.out.println("r-ars = " + nroSugestoesDeEdicaoRejeitadasNaPergunta);
					//textoSaida += idAtualFeature++ + ":" +nroSugestoesDeEdicaoRejeitadasNaPergunta+ " ";
					listaValoresFeatures.add(nroSugestoesDeEdicaoRejeitadasNaPergunta+.0);
					
					//Calcula o nro de respostas postadas antes daquela resposta (considerando apenas a thread)
					//VERIFICADA
					int nroDeRespostasPostadasAntes = calculaNroDeRespostasPostadasAntesDaResposta(idPergunta, idResposta);
					//System.out.println("r-ab = " + nroDeRespostasPostadasAntes);
					//textoSaida += idAtualFeature++ + ":" +nroDeRespostasPostadasAntes+ " ";
					listaValoresFeatures.add(nroDeRespostasPostadasAntes+.0);
					
					//Calcula o nro de respostas postadas a pergunta
					//VERIFICADA
					int nroDeRespostasPostadasAPergunta = calculaNroDeRespostasPostadasAPergunta(idPergunta);
					//System.out.println("r-naq = " + nroDeRespostasPostadasAPergunta);
					//textoSaida += idAtualFeature++ + ":" +nroDeRespostasPostadasAPergunta+ " ";
					listaValoresFeatures.add(nroDeRespostasPostadasAPergunta+.0);
					
					//Calcula o nro de comentarios postados a pergunta
					//VERIFICADA
					int nroComentariosPostadosAPergunta = calculaNroDeComentariosDoPost(idPergunta);
					//System.out.println("r-qcc = " + nroComentariosPostadosAPergunta);
					//textoSaida += idAtualFeature++ + ":" +nroComentariosPostadosAPergunta+ " ";
					listaValoresFeatures.add(nroComentariosPostadosAPergunta+.0);
					
					//Calcula o nro de comentarios postados a resposta
					//VERIFICADA
					int nroComentariosPostadosAResposta = calculaNroDeComentariosDoPost(idResposta);
					//System.out.println("r-acc = " + nroComentariosPostadosAResposta);
					//textoSaida += idAtualFeature++ + ":" +nroComentariosPostadosAResposta+ " ";
					listaValoresFeatures.add(nroComentariosPostadosAResposta+.0);
					
					//Calcula o nro de usuarios que comentaram a resposta
					//VERIFICADA
					int nroUsuariosQueComentaramResposta = calculaNroDeUsuariosQueComentaramPost(idResposta);
					//System.out.println("r-aua = " + nroUsuariosQueComentaramResposta);
					//textoSaida += idAtualFeature++ + ":" +nroUsuariosQueComentaramResposta+ " ";
					listaValoresFeatures.add(nroUsuariosQueComentaramResposta+.0);
					
					//Calcula o nro de usuarios que comentaram a pergunta
					//VERIFICADA
					int nroUsuariosQueComentaramPergunta = calculaNroDeUsuariosQueComentaramPost(idPergunta);
					//System.out.println("r-auq = " + nroUsuariosQueComentaramPergunta);
					//textoSaida += idAtualFeature++ + ":" +nroUsuariosQueComentaramPergunta+ " ";
					listaValoresFeatures.add(nroUsuariosQueComentaramPergunta+.0);
					
					//calcula a reputacao media/max/min/desvio dos usuarios que editaram a pergunta
					List<Integer> listaReputacaoEditoresDaPergunta = calculaListaComReputacaoDeEditoresDaPergunta(idPergunta);
					double mediaDeReputcaoDeEditoresDaPergunta = calculaMedia(listaReputacaoEditoresDaPergunta);
					//System.out.println("r-arpeq = " + mediaDeReputcaoDeEditoresDaPergunta);
					//textoSaida += idAtualFeature++ + ":" +mediaDeReputcaoDeEditoresDaPergunta+ " ";
					listaValoresFeatures.add(mediaDeReputcaoDeEditoresDaPergunta+.0);
					//System.out.println("r-xrpeq = " + calculaMax(listaReputacaoEditoresDaPergunta));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaReputacaoEditoresDaPergunta)+ " ";
					listaValoresFeatures.add(calculaMax(listaReputacaoEditoresDaPergunta)+.0);
					//System.out.println("r-mrpeq = " + calculaMin(listaReputacaoEditoresDaPergunta));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaReputacaoEditoresDaPergunta)+ " ";
					listaValoresFeatures.add(calculaMin(listaReputacaoEditoresDaPergunta)+.0);
					
					//calcula a reputacao media/max/min/desvio dos usuarios que editaram a resposta
					List<Integer> listaReputacaoEditoresDaResposta = calculaListaComReputacaoDeEditoresDaResposta(idResposta);
					double mediaDeReputcaoDeEditoresDaResposta = calculaMedia(listaReputacaoEditoresDaResposta); 
					//System.out.println("r-arpea = " + mediaDeReputcaoDeEditoresDaResposta);
					//textoSaida += idAtualFeature++ + ":" +mediaDeReputcaoDeEditoresDaResposta+ " ";
					listaValoresFeatures.add(mediaDeReputcaoDeEditoresDaResposta+.0);
					//System.out.println("r-xrpea = " + calculaMax(listaReputacaoEditoresDaResposta));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaReputacaoEditoresDaResposta)+ " ";
					listaValoresFeatures.add(calculaMax(listaReputacaoEditoresDaResposta)+.0);
					//System.out.println("r-mrpea = " + calculaMin(listaReputacaoEditoresDaResposta));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaReputacaoEditoresDaResposta)+ " ";
					listaValoresFeatures.add(calculaMin(listaReputacaoEditoresDaResposta)+.0);
					
					
					/*******************************************************Text Strcuture**********************************************************/
					
					//Calcula o nro de imagens na resposta
					//VERIFICADA
					int nroDeImagensNaResposta = calculaNroDeOcorrenciasDeTag("img", corpoResposta);
					//System.out.println("ts-ica = " + nroDeImagensNaResposta);
					//textoSaida += idAtualFeature++ + ":" +nroDeImagensNaResposta+ " ";
					listaValoresFeatures.add(nroDeImagensNaResposta+.0);
					
					//Calcula o nro de imagens na pergunta
					//VERIFICADA
					int nroDeImagensNaPergunta = calculaNroDeOcorrenciasDeTag("img", corpoPergunta);
					//System.out.println("ts-icq = " + nroDeImagensNaPergunta);
					//textoSaida += idAtualFeature++ + ":" +nroDeImagensNaPergunta+ " ";
					listaValoresFeatures.add(nroDeImagensNaPergunta+.0);
					
					//Calcula o nro de secoes (tags H1) na resposta
					//VERIFICADA
					int nroDeSecoesNaReposta = calculaNroDeOcorrenciasDeTag("H1", corpoResposta);
					//System.out.println("ts-sca = " + nroDeSecoesNaReposta);
					//textoSaida += idAtualFeature++ + ":" +nroDeSecoesNaReposta+ " ";
					listaValoresFeatures.add(nroDeSecoesNaReposta+.0);
					
					//Calcula o nro de secoes (tags H1) na pergunta
					//VERIFICADA
					int nroDeSecoesNaPergunta = calculaNroDeOcorrenciasDeTag("H1", corpoPergunta);
					//System.out.println("ts-scq = " + nroDeSecoesNaPergunta);
					//textoSaida += idAtualFeature++ + ":" +nroDeSecoesNaPergunta+ " ";
					listaValoresFeatures.add(nroDeSecoesNaPergunta+.0);
					
					//Calcula o nro de subsecoes (tags H2) na resposta
					//VERIFICADA
					int nroDeSubSecoesNaReposta = calculaNroDeOcorrenciasDeTag("H2", corpoResposta);
					//System.out.println("ts-ssca = " + nroDeSubSecoesNaReposta);
					//textoSaida += idAtualFeature++ + ":" +nroDeSubSecoesNaReposta+ " ";
					listaValoresFeatures.add(nroDeSubSecoesNaReposta+.0);
					
					//Calcula o nro de subsecoes (tags H2) na pergunta
					//VERIFICADA
					int nroDeSubSecoesNaPergunta = calculaNroDeOcorrenciasDeTag("H2", corpoPergunta);
					//System.out.println("ts-sscq = " + nroDeSubSecoesNaPergunta);
					//textoSaida += idAtualFeature++ + ":" +nroDeSubSecoesNaPergunta+ " ";
					listaValoresFeatures.add(nroDeSubSecoesNaPergunta+.0);
					
					//Calcula o nro de subsecoes (tags H3) na resposta
					//VERIFICADA
					int nroDeSubSubSecoesNaReposta = calculaNroDeOcorrenciasDeTag("H3", corpoResposta);
					//System.out.println("ts-sssca = " + nroDeSubSubSecoesNaReposta);
					//textoSaida += idAtualFeature++ + ":" +nroDeSubSubSecoesNaReposta+ " ";
					listaValoresFeatures.add(nroDeSubSubSecoesNaReposta+.0);
					
					//Calcula o nro de subsecoes (tags H3) na pergunta
					//VERIFICADA
					int nroDeSubSubSecoesNaPergunta = calculaNroDeOcorrenciasDeTag("H3", corpoPergunta);
					//System.out.println("ts-ssscq = " + nroDeSubSubSecoesNaPergunta);
					//textoSaida += idAtualFeature++ + ":" +nroDeSubSubSecoesNaPergunta+ " ";
					listaValoresFeatures.add(nroDeSubSubSecoesNaPergunta+.0);
					
					//Calcula a media, do tamanhos das secoes da resposta(nro de tokens), max, min e desvio (na resposta)
					//VERIFICADA
					List<Integer> listaTamanhosSecoes = calculaTamanhosSecoes(corpoResposta, mt);
					double mediaTamanhoSecoes = calculaMedia(listaTamanhosSecoes);
					//System.out.println("ts-asla = " + mediaTamanhoSecoes);
					//textoSaida += idAtualFeature++ + ":" +mediaTamanhoSecoes+ " ";
					listaValoresFeatures.add(mediaTamanhoSecoes+.0);
					//System.out.println("ts-mxsla = " + calculaMax(listaTamanhosSecoes));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaTamanhosSecoes)+ " ";
					listaValoresFeatures.add(calculaMax(listaTamanhosSecoes)+.0);
					//System.out.println("ts-misla = " + calculaMin(listaTamanhosSecoes));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaTamanhosSecoes)+ " ";
					listaValoresFeatures.add(calculaMin(listaTamanhosSecoes)+.0);
					//System.out.println("ts-ssla = " + calculaDesvioPadrao(listaTamanhosSecoes, mediaTamanhoSecoes));
					//textoSaida += idAtualFeature++ + ":" +calculaDesvioPadrao(listaTamanhosSecoes, mediaTamanhoSecoes)+ " ";
					listaValoresFeatures.add(calculaDesvioPadrao(listaTamanhosSecoes, mediaTamanhoSecoes)+.0);
					
					//Calcula a media, do tamanhos das secoes da resposta(nro de tokens), max, min e desvio (na pergunta)
					//VERIFICADA
					listaTamanhosSecoes = calculaTamanhosSecoes(corpoPergunta, mt);
					mediaTamanhoSecoes = calculaMedia(listaTamanhosSecoes);
					//System.out.println("ts-aslq = " + mediaTamanhoSecoes);
					//textoSaida += idAtualFeature++ + ":" +mediaTamanhoSecoes+ " ";
					listaValoresFeatures.add(mediaTamanhoSecoes+.0);
					//System.out.println("ts-mxslq = " + calculaMax(listaTamanhosSecoes));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaTamanhosSecoes)+ " ";
					listaValoresFeatures.add(calculaMax(listaTamanhosSecoes)+.0);
					//System.out.println("ts-mislq = " + calculaMin(listaTamanhosSecoes));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaTamanhosSecoes)+ " ";
					listaValoresFeatures.add(calculaMin(listaTamanhosSecoes)+.0);
					//System.out.println("ts-sslq = " + calculaDesvioPadrao(listaTamanhosSecoes, mediaTamanhoSecoes));
					//textoSaida += idAtualFeature++ + ":" +calculaDesvioPadrao(listaTamanhosSecoes, mediaTamanhoSecoes)+ " ";
					listaValoresFeatures.add(calculaDesvioPadrao(listaTamanhosSecoes, mediaTamanhoSecoes)+.0);
					
					//Calcula o nro de tags italico + nro de tags bold na resposta
					//VERIFICADA
					int nroDeTagsItalico = calculaNroDeOcorrenciasDeTag("i", corpoResposta);
					int nroDeTagsBold = calculaNroDeOcorrenciasDeTag("b", corpoResposta);
					//System.out.println("ts-boia = " + (nroDeTagsItalico + nroDeTagsBold));
					//textoSaida += idAtualFeature++ + ":" +(nroDeTagsItalico + nroDeTagsBold)+ " ";
					listaValoresFeatures.add((nroDeTagsItalico + nroDeTagsBold)+.0);
					
					//Calcula o nro de tags italico + nro de tags bold na pergunta
					//VERIFICADA
					nroDeTagsItalico = calculaNroDeOcorrenciasDeTag("i", corpoPergunta);
					nroDeTagsBold = calculaNroDeOcorrenciasDeTag("b", corpoPergunta);
					//System.out.println("ts-boiq = " + (nroDeTagsItalico + nroDeTagsBold));
					//textoSaida +=  idAtualFeature++ + ":" +(nroDeTagsItalico + nroDeTagsBold)+ " ";
					listaValoresFeatures.add((nroDeTagsItalico + nroDeTagsBold)+.0);
					
					//Calcula o nro de paragrafos (tags p) resposta
					//VERIFICADA
					int nroDePragrafos = calculaNroDeOcorrenciasDeTag("p", corpoResposta);
					//System.out.println("ts-pca = " + nroDePragrafos);
					//textoSaida +=  idAtualFeature++ + ":" +nroDePragrafos+ " ";
					listaValoresFeatures.add(nroDePragrafos+.0);
					
					//Calcula o nro de paragrafos (tags p) pergunta
					//VERIFICADA
					nroDePragrafos = calculaNroDeOcorrenciasDeTag("p", corpoPergunta);
					//System.out.println("ts-pcq = " + nroDePragrafos);
					//textoSaida +=  idAtualFeature++ + ":" +nroDePragrafos+ " ";
					listaValoresFeatures.add(nroDePragrafos+.0);
					
					//Calcula o nro de quoted blocks (tags blockquote) na resposta
					//VERIFICADA
					int nroDeQuotedBlocks = calculaNroDeOcorrenciasDeTag("blockquote", corpoResposta);
					//System.out.println("ts-quoa = " + nroDeQuotedBlocks);
					//textoSaida +=  idAtualFeature++ + ":" +nroDeQuotedBlocks+ " ";
					listaValoresFeatures.add(nroDeQuotedBlocks+.0);
					
					//Calcula o nro de quoted blocks (tags blockquote) na pergunta
					//VERIFICADA
					nroDeQuotedBlocks = calculaNroDeOcorrenciasDeTag("blockquote", corpoPergunta);
					//System.out.println("ts-quoq = " + nroDeQuotedBlocks);
					//textoSaida +=  idAtualFeature++ + ":" +nroDeQuotedBlocks+ " ";
					listaValoresFeatures.add(nroDeQuotedBlocks+.0);
					
					//Calcula o nro de code snippets na resposta (tags <pre><code>)
					//VERIFICADA
					int nroDeCodeSnippets = calculaNroDeOcorrenciasDeTag("pre/code", corpoResposta);
					//System.out.println("ts-coda = " + nroDeCodeSnippets);
					//textoSaida +=  idAtualFeature++ + ":" +nroDeCodeSnippets+ " ";
					listaValoresFeatures.add(nroDeCodeSnippets+.0);
					
					//Calcula o nro de code snippets na pergunta (tags <pre><code>)
					//VERIFICADA
					nroDeCodeSnippets = calculaNroDeOcorrenciasDeTag("pre/code", corpoPergunta);
					//System.out.println("ts-codq = " + nroDeCodeSnippets);
					//textoSaida +=  idAtualFeature++ + ":" +nroDeCodeSnippets+ " ";
					listaValoresFeatures.add(nroDeCodeSnippets+.0);
					
					//Calcula o nro de listas na resposta (tags ul, ol)
					//VERIFICADA
					int nroDeListasNaoOrdenadas = calculaNroDeOcorrenciasDeTag("ul", corpoResposta);
					int nroDeListasOrdenadas = calculaNroDeOcorrenciasDeTag("ol", corpoResposta);
					//System.out.println("ts-lta = " + (nroDeListasNaoOrdenadas + nroDeListasOrdenadas));
					//textoSaida +=  idAtualFeature++ + ":" +(nroDeListasNaoOrdenadas + nroDeListasOrdenadas)+ " ";
					listaValoresFeatures.add((nroDeListasNaoOrdenadas + nroDeListasOrdenadas)+.0);
					
					//Calcula o nro de listas na pergunta (tags ul, ol)
					//VERIFICADA
					nroDeListasNaoOrdenadas = calculaNroDeOcorrenciasDeTag("ul", corpoPergunta);
					nroDeListasOrdenadas = calculaNroDeOcorrenciasDeTag("ol", corpoPergunta);
					//System.out.println("ts-ltq = " + (nroDeListasNaoOrdenadas + nroDeListasOrdenadas));
					//textoSaida +=  idAtualFeature++ + ":" +(nroDeListasNaoOrdenadas + nroDeListasOrdenadas)+ " ";
					listaValoresFeatures.add((nroDeListasNaoOrdenadas + nroDeListasOrdenadas)+.0);
					
					//Calcula o nro de itens de lista na resposta (tags li)
					//VERIFICADA
					int nroDeItensDeLista = calculaNroDeOcorrenciasDeTag("li", corpoResposta);
					//System.out.println("ts-lita = " + nroDeItensDeLista);
					//textoSaida += idAtualFeature++ + ":" +nroDeItensDeLista+ " ";
					listaValoresFeatures.add(nroDeItensDeLista+.0);
					
					//Calcula o nro de itens de lista na pergunta (tags li)
					//VERIFICADA
					nroDeItensDeLista = calculaNroDeOcorrenciasDeTag("li", corpoPergunta);
					//System.out.println("ts-litq = " + nroDeItensDeLista);
					//textoSaida += idAtualFeature++ + ":" +nroDeItensDeLista+ " ";
					listaValoresFeatures.add(nroDeItensDeLista+.0);
					
					//Calcula o tamanho medio dos snippets da resposta, tamnaho maximo, tamanho minimo, desvio padrao e tamanho total (soma dos snippets) dos codigos da resposta
					//VERIFICADA
					List<Integer> listaTamanhosSnippets = calculaListaTamanhoSnippets(corpoResposta);
					double mediaTamanhoCodigos = calculaMedia(listaTamanhosSnippets);
					//System.out.println("ts-avca = " + mediaTamanhoCodigos);
					//textoSaida += idAtualFeature++ + ":" +mediaTamanhoCodigos+ " ";
					listaValoresFeatures.add(mediaTamanhoCodigos+.0);
					//System.out.println("ts-maca = " + calculaMax(listaTamanhosSnippets));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaTamanhosSnippets)+ " ";
					listaValoresFeatures.add(calculaMax(listaTamanhosSnippets)+.0);
					//System.out.println("ts-mica = " + calculaMin(listaTamanhosSnippets));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaTamanhosSnippets)+ " ";
					listaValoresFeatures.add(calculaMin(listaTamanhosSnippets)+.0);
					//System.out.println("ts-sdca = " + calculaDesvioPadrao(listaTamanhosSnippets, mediaTamanhoCodigos));
					//textoSaida += idAtualFeature++ + ":" +calculaDesvioPadrao(listaTamanhosSnippets, mediaTamanhoCodigos)+ " ";
					listaValoresFeatures.add(calculaDesvioPadrao(listaTamanhosSnippets, mediaTamanhoCodigos)+.0);
					//System.out.println("ts-tdca = " + calculaSomaDeLista(listaTamanhosSnippets));
					//textoSaida += idAtualFeature++ + ":" +calculaSomaDeLista(listaTamanhosSnippets)+ " ";
					listaValoresFeatures.add(calculaSomaDeLista(listaTamanhosSnippets)+.0);
					
					//Calcula o tamanho medio dos snippets da resposta, tamnaho maximo, tamanho minimo, desvio padrao e tamanho total (soma dos snippets) dos codigos da pergunta
					//VERIFICADA
					listaTamanhosSnippets = calculaListaTamanhoSnippets(corpoPergunta);
					mediaTamanhoCodigos = calculaMedia(listaTamanhosSnippets);
					//System.out.println("ts-avcq = " + mediaTamanhoCodigos);
					//textoSaida += idAtualFeature++ + ":" +mediaTamanhoCodigos+ " ";
					listaValoresFeatures.add(mediaTamanhoCodigos+.0);
					//System.out.println("ts-macq = " + calculaMax(listaTamanhosSnippets));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaTamanhosSnippets)+ " ";
					listaValoresFeatures.add(calculaMax(listaTamanhosSnippets)+.0);
					//System.out.println("ts-micq = " + calculaMin(listaTamanhosSnippets));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaTamanhosSnippets)+ " ";
					listaValoresFeatures.add(calculaMin(listaTamanhosSnippets)+.0);
					//System.out.println("ts-sdcq = " + calculaDesvioPadrao(listaTamanhosSnippets, mediaTamanhoCodigos));
					//textoSaida += idAtualFeature++ + ":" +calculaDesvioPadrao(listaTamanhosSnippets, mediaTamanhoCodigos)+ " ";
					listaValoresFeatures.add(calculaDesvioPadrao(listaTamanhosSnippets, mediaTamanhoCodigos)+.0);
					//System.out.println("ts-tdcq = " + calculaSomaDeLista(listaTamanhosSnippets));
					//textoSaida += idAtualFeature++ + ":" +calculaSomaDeLista(listaTamanhosSnippets)+ " ";
					listaValoresFeatures.add(calculaSomaDeLista(listaTamanhosSnippets)+.0);
					
					//Calcula o tamanho medio (nro tokens) dos quoted block da resposta, tamnaho maximo, tamanho minimo e desvio padrao dos tamnhos
					//VERIFICADA
					List<Integer> listaTamanhosQuotedBlocks = calculaListaTamanhoQuotedBlocks(corpoResposta, mt);
					double mediaTamanhoQuotedBlocks = calculaMedia(listaTamanhosQuotedBlocks);
					//System.out.println("ts-avqa = " + mediaTamanhoQuotedBlocks);
					//textoSaida += idAtualFeature++ + ":" +mediaTamanhoQuotedBlocks+ " ";
					listaValoresFeatures.add(mediaTamanhoQuotedBlocks+.0);
					//System.out.println("ts-maqa = " + calculaMax(listaTamanhosQuotedBlocks));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaTamanhosQuotedBlocks)+ " ";
					listaValoresFeatures.add(calculaMax(listaTamanhosQuotedBlocks)+.0);
					//System.out.println("ts-miqa = " + calculaMin(listaTamanhosQuotedBlocks));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaTamanhosQuotedBlocks)+ " ";
					listaValoresFeatures.add(calculaMin(listaTamanhosQuotedBlocks)+.0);
					//System.out.println("ts-sdqa = " + calculaDesvioPadrao(listaTamanhosQuotedBlocks, mediaTamanhoQuotedBlocks));
					//textoSaida += idAtualFeature++ + ":" +calculaDesvioPadrao(listaTamanhosQuotedBlocks, mediaTamanhoQuotedBlocks)+ " ";
					listaValoresFeatures.add(calculaDesvioPadrao(listaTamanhosQuotedBlocks, mediaTamanhoQuotedBlocks)+.0);
					
					//Calcula o tamanho medio (nro tokens) dos quoted block da pergunta, tamnaho maximo, tamanho minimo e desvio padrao dos tamnhos
					//VERIFICADA
					listaTamanhosQuotedBlocks = calculaListaTamanhoQuotedBlocks(corpoPergunta, mt);
					mediaTamanhoQuotedBlocks = calculaMedia(listaTamanhosQuotedBlocks);
					//System.out.println("ts-avqq = " + mediaTamanhoQuotedBlocks);
					//textoSaida += idAtualFeature++ + ":" +calculaMedia(listaTamanhosQuotedBlocks)+ " ";
					listaValoresFeatures.add(calculaMedia(listaTamanhosQuotedBlocks)+.0);
					//System.out.println("ts-maqq = " + calculaMax(listaTamanhosQuotedBlocks));
					//textoSaida += idAtualFeature++ + ":" +calculaMax(listaTamanhosQuotedBlocks)+ " ";
					listaValoresFeatures.add(calculaMax(listaTamanhosQuotedBlocks)+.0);
					//System.out.println("ts-miqq = " + calculaMin(listaTamanhosQuotedBlocks));
					//textoSaida += idAtualFeature++ + ":" +calculaMin(listaTamanhosQuotedBlocks)+ " ";
					listaValoresFeatures.add(calculaMin(listaTamanhosQuotedBlocks)+.0);
					//System.out.println("ts-sdqq = " + calculaDesvioPadrao(listaTamanhosQuotedBlocks, mediaTamanhoQuotedBlocks));
					//textoSaida += idAtualFeature++ + ":" +calculaDesvioPadrao(listaTamanhosQuotedBlocks, mediaTamanhoQuotedBlocks)+ " ";
					listaValoresFeatures.add(calculaDesvioPadrao(listaTamanhosQuotedBlocks, mediaTamanhoQuotedBlocks)+.0);
					
					//Calcula (na resposta) o nro de links externos e internos ao Stack Overflow 
					//VERIFICADA
					List<String> listaUrlLinks = encontraLinks(corpoResposta);
					int nroDeLinksExternos = calculaNroDeLinksExternos(listaUrlLinks);
					//System.out.println("ts-xlca = " + nroDeLinksExternos);
					//textoSaida += idAtualFeature++ + ":" + nroDeLinksExternos+ " ";
					listaValoresFeatures.add(nroDeLinksExternos+.0);
					//System.out.println("ts-ilca = " + (listaUrlLinks.size() - nroDeLinksExternos));
					//textoSaida += idAtualFeature++ + ":" + (listaUrlLinks.size() - nroDeLinksExternos)+ " ";
					listaValoresFeatures.add((listaUrlLinks.size() - nroDeLinksExternos)+.0);
					
					//Calcula (na pergunta) o nro de links externos e internos ao Stack Overflow 
					//VERIFICADA
					listaUrlLinks = encontraLinks(corpoPergunta);
					nroDeLinksExternos = calculaNroDeLinksExternos(listaUrlLinks);
					//System.out.println("ts-xlcq = " + nroDeLinksExternos);
					//textoSaida += idAtualFeature++ + ":" +nroDeLinksExternos+ " ";
					listaValoresFeatures.add(nroDeLinksExternos+.0);
					//System.out.println("ts-ilcq = " + (listaUrlLinks.size() - nroDeLinksExternos));
					//textoSaida += idAtualFeature++ + ":" +(listaUrlLinks.size() - nroDeLinksExternos)+ " ";
					listaValoresFeatures.add((listaUrlLinks.size() - nroDeLinksExternos)+.0);
					
					//Calcula o nro de vezes que o answerer interage com outros usuarios na resposta (nro de @ presentes na resposta)
					//VERIFICADA
					int nroDeInteracoesComOutrosUsuarios = calculaNroDeInteracoes(corpoResposta);
					//System.out.println("ts-urf = " + nroDeInteracoesComOutrosUsuarios);
					//textoSaida += idAtualFeature++ + ":" +nroDeInteracoesComOutrosUsuarios+ " ";
					listaValoresFeatures.add(nroDeInteracoesComOutrosUsuarios+.0);
					
					/*******************************************************Length features*************************************************************/
					
					//Calcula o taqmanho do resposta em Palavras (tokens)
					int nroDePalavrasEmPost = calculaNroDePalavrasEmPost(corpoResposta, mt);
					//System.out.println("tl-wcounta = " + nroDePalavrasEmPost);
					//textoSaida += idAtualFeature++ + ":" +nroDePalavrasEmPost+ " ";
					listaValoresFeatures.add(nroDePalavrasEmPost+.0);
					
					//Calcula o taqmanho do pergunta Palavras (tokens)
					nroDePalavrasEmPost = calculaNroDePalavrasEmPost(corpoPergunta, mt);
					//System.out.println("tl-wcountq = " + nroDePalavrasEmPost);
					//textoSaida += idAtualFeature++ + ":" +nroDePalavrasEmPost+ " ";
					listaValoresFeatures.add(nroDePalavrasEmPost+.0);
					
					//Calcula o taqmanho da resposta em nro de sentencas
					int nroDeSentencasEmPost = calculaNroDeSentencasEmPost(corpoResposta, mt);
					//System.out.println("tl-scounta = " + nroDeSentencasEmPost);
					//textoSaida += idAtualFeature++ + ":" +nroDeSentencasEmPost+ " ";
					listaValoresFeatures.add(nroDeSentencasEmPost+.0);
					
					//Calcula o taqmanho da pergunta em nro de sentencas
					nroDeSentencasEmPost = calculaNroDeSentencasEmPost(corpoPergunta, mt);
					//System.out.println("tl-scountq = " + nroDeSentencasEmPost);
					//textoSaida += idAtualFeature++ + ":" +nroDeSentencasEmPost+ " ";
					listaValoresFeatures.add(nroDeSentencasEmPost+.0);
					
					//Calcula o taqmanho da resposta em nro de caracteres 
					int nroDeCaracteresEmPost = calculaNroDeCaracteresEmPost(corpoResposta, mt);
					//System.out.println("tl-ccounta = " + nroDeCaracteresEmPost);
					//textoSaida += idAtualFeature++ + ":" +nroDeCaracteresEmPost+ " ";
					listaValoresFeatures.add(nroDeCaracteresEmPost+.0);
					
					//Calcula o taqmanho da pergunta em nro de caracteres 
					nroDeCaracteresEmPost = calculaNroDeCaracteresEmPost(corpoPergunta, mt);
					//System.out.println("tl-ccountq = " + nroDeCaracteresEmPost);
					//textoSaida += idAtualFeature++ + ":" +nroDeCaracteresEmPost+ " ";
					listaValoresFeatures.add(nroDeCaracteresEmPost+.0);
					
					/*******************************************************Miscelancia*************************************************************/
					
					//Calcula o score da pergunta
					int scoreDaPergunta = recuperaScore(idPergunta); 
					//System.out.println("m-qs = " + scoreDaPergunta);
					//textoSaida += idAtualFeature++ + ":" +scoreDaPergunta+ " ";
					listaValoresFeatures.add(scoreDaPergunta+.0);
					
					//Calcula o score da resposta
					int scoreDaResposta = recuperaScore(idResposta);
					//System.out.println("m-as = " + scoreDaResposta);
					//textoSaida += idAtualFeature++ + ":" +scoreDaResposta+ " ";
					listaValoresFeatures.add(scoreDaResposta+.0);
					
					//Calcula o favorite count da pergunta
					int favoriteCountDaPergunta = recuperaFavoriteCount(idPergunta);
					//System.out.println("m-afc = " + favoriteCountDaPergunta);
					//textoSaida += idAtualFeature++ + ":" +favoriteCountDaPergunta+ " ";
					listaValoresFeatures.add(favoriteCountDaPergunta+.0);
					
					/*//Calcula o nro de tokens SSCCE em comentarios da pergunta
					int nroDeSSCEE = calculaNroDeSSCCEEmComentariosDePost(idPergunta, mt);
					//System.out.println("m-nosscce = " + nroDeSSCEE);
					//textoSaida += "\t"+nroDeSSCEE;*/
					
					//Calcula o nro de tags na pergunta
					int nroDeTags = listaCategoriasDoPar.size();
					//System.out.println("m-nt = " + nroDeTags);
					//textoSaida += idAtualFeature++ + ":" +nroDeTags+ " ";
					listaValoresFeatures.add(nroDeTags+.0);
					
					//Verifica se a resposta eh uma resposta aceita (0/1)
					int ehRespostaAceita = verificaSeEhRespostaAceita(idResposta);
					//System.out.println("m-aa = " + ehRespostaAceita);
					//textoSaida += idAtualFeature++ + ":" +ehRespostaAceita+ " ";
					listaValoresFeatures.add(ehRespostaAceita+.0);
					
					//Calcula o viewCount da thread
					int viewCount = calculaViewCount(idPergunta);
					//System.out.println("m-qvc = " + viewCount);
					//textoSaida += idAtualFeature++ + ":" +viewCount+ " ";
					listaValoresFeatures.add(viewCount+.0);
					
					//m-qvcn	view count da thread/idade em dias da pergunta
					double viewCountNorm = viewCount/(double)idadePergunta;
					//System.out.println("m-qvc = " + viewCount);
					//textoSaida += idAtualFeature++ + ":" +viewCountNorm+ " ";
					listaValoresFeatures.add(viewCountNorm+.0);
					
					//textoSaida += "# " + idPergunta + "-" + idResposta;
					
				
		
					
			
			
			/*FileOutputStream fo = new FileOutputStream("/home/lucas/variaveis_serializadas/setCategoriasJaProcessadas.ser");
			ObjectOutputStream oo = new ObjectOutputStream(fo);
			oo.writeObject(setCategoriasJaProcessadas); // serializo objeto cat
			oo.close();
			
			fo = new FileOutputStream("/home/lucas/variaveis_serializadas/mapUltimaPosicaoRankingDeScoreDePerguntasPorCat.ser");
			oo = new ObjectOutputStream(fo);
			oo.writeObject(mapUltimaPosicaoRankingDeScoreDePerguntasPorCat); // serializo objeto cat
			oo.close();
			
			fo = new FileOutputStream("/home/lucas/variaveis_serializadas/mapUltimaPosicaoRankingDeScoreDeRespostasPorCat.ser");
			oo = new ObjectOutputStream(fo);
			oo.writeObject(mapUltimaPosicaoRankingDeScoreDeRespostasPorCat); // serializo objeto cat
			oo.close();
			
			fo = new FileOutputStream("/home/lucas/variaveis_serializadas/listaParaRankingDeRating.ser");
			oo = new ObjectOutputStream(fo);
			oo.writeObject(listaParaRankingDeRating); // serializo objeto cat
			oo.close();*/
			
		}catch(Exception e){
			e.printStackTrace();
		}
				
		return listaValoresFeatures;
	}

	private  double calculaUmcaa(
			List<Integer> listaNroDeComentariosPorResposta, double Uapa) {
		
		if(listaNroDeComentariosPorResposta.size() != Uapa){
			return 0;
		}
		else{
			return calculaMin(listaNroDeComentariosPorResposta);
		}
		
	}

	private  double calculaUxcaa(
			List<Integer> listaNroDeComentariosPorResposta) {
		return calculaMax(listaNroDeComentariosPorResposta);
	}

	private  double calculaUacaa(
			List<Integer> listaNroDeComentariosPorResposta, int uapa) {
		return calculaMedia(listaNroDeComentariosPorResposta, uapa);
	}

	private  int calculaUqpq(int idAsker) {
		return calculaNroDePerguntasPostadas(idAsker);
	}

	private  int calculaUqpa(int idAnswerer) {
		return calculaNroDePerguntasPostadas(idAnswerer);
	}

	private  int calculaUapq(int idAsker) {
		return calculaNroDeRespostasPostadas(idAsker);
	}

	private  int calculaUapa(int idAnswerer) {
		return calculaNroDeRespostasPostadas(idAnswerer);
	}

	private  int calculaUbdgq(int idAsker) {
		return calculaNroDeBadges(idAsker);
	}

	private  int calculaUbdga(int idAnswerer) {
		return calculaNroDeBadges(idAnswerer);
	}

	private  int calculaUlacq(int idAsker) {
		return calculaNroDeDiasDesdeOUltimoAcesso(idAsker);
	}

	private  int calculaUlaca(int idAnswerer) {
		return calculaNroDeDiasDesdeOUltimoAcesso(idAnswerer);
	}

	private  int calculaUdaycq(int idUsuario) {
		return calculaNroDeDiasDesdeORegistro(idUsuario);
	}

	private  int calculaUdayca(int idUsuario) {
		return calculaNroDeDiasDesdeORegistro(idUsuario);
	}

	private  void restauraVariaveisPreprocessadas() {
		try{
			long tempoInicial = System.currentTimeMillis();
			System.out.println("A");

			if(ehPrimeiraVez){
				//Inicializacaoes de estruturas de dados/variaveis utilizadas para o rankeamento
				mapRankingAskers = new HashMap<Integer, Integer>();
				ultimaPosicaoNoRankingDeAskers = calculaRankingPerguntas(mapRankingAskers);
				mapRankingAnswerers = new HashMap<Integer, Integer>();
				ultimaPosicaoNoRankingDeAnswerers = calculaRankingRespostas(mapRankingAnswerers);
				
				FileOutputStream fo = new FileOutputStream("/home/lucas/variaveis_serializadas/mapRankingAskers.ser");
				ObjectOutputStream oo = new ObjectOutputStream(fo);
				oo.writeObject(mapRankingAskers); // serializo objeto cat
				oo.close();
				
				fo = new FileOutputStream("/home/lucas/variaveis_serializadas/ultimaPosicaoNoRankingDeAskers.ser");
				oo = new ObjectOutputStream(fo);
				oo.writeObject(ultimaPosicaoNoRankingDeAskers); // serializo objeto cat
				oo.close();
				
				fo = new FileOutputStream("/home/lucas/variaveis_serializadas/mapRankingAnswerers.ser");
				oo = new ObjectOutputStream(fo);
				oo.writeObject(mapRankingAnswerers); // serializo objeto cat
				oo.close();
				
				fo = new FileOutputStream("/home/lucas/variaveis_serializadas/ultimaPosicaoNoRankingDeAnswerers.ser");
				oo = new ObjectOutputStream(fo);
				oo.writeObject(ultimaPosicaoNoRankingDeAnswerers); // serializo objeto cat
				oo.close();
				
			}else{
				 FileInputStream fi = new FileInputStream("/home/lucas/variaveis_serializadas/mapRankingAskers.ser");
				 ObjectInputStream oi = new ObjectInputStream(fi);
				 mapRankingAskers =(Map<Integer, Integer>) oi.readObject();
				 oi.close();
				 
				 fi = new FileInputStream("/home/lucas/variaveis_serializadas/ultimaPosicaoNoRankingDeAskers.ser");
				 oi = new ObjectInputStream(fi);
				 ultimaPosicaoNoRankingDeAskers =(Integer) oi.readObject();
				 oi.close();
				 
				 fi = new FileInputStream("/home/lucas/variaveis_serializadas/mapRankingAnswerers.ser");
				 oi = new ObjectInputStream(fi);
				 mapRankingAnswerers =(Map<Integer, Integer>) oi.readObject();
				 oi.close();
				 
				 fi = new FileInputStream("/home/lucas/variaveis_serializadas/ultimaPosicaoNoRankingDeAnswerers.ser");
				 oi = new ObjectInputStream(fi);
				 ultimaPosicaoNoRankingDeAnswerers =(Integer) oi.readObject();
				 oi.close();
			}
			
			System.out.println("B");
			//Descobre todas as tags
			
			if(ehPrimeiraVez){
				listaTags = descobreTodasTags();
				FileOutputStream fo = new FileOutputStream("/home/lucas/variaveis_serializadas/listaTags.ser");
				ObjectOutputStream oo = new ObjectOutputStream(fo);
				oo.writeObject(listaTags); // serializo objeto cat
				oo.close();
			}else{
				FileInputStream fi = new FileInputStream("/home/lucas/variaveis_serializadas/listaTags.ser");
				ObjectInputStream oi = new ObjectInputStream(fi);
				listaTags =(List<String>) oi.readObject();
				oi.close();
			}
		
			System.out.println("C");
			//Desobre todos os usuarios
			
			if(ehPrimeiraVez){
				listaIdUsers = recuperaTodosUsuarios();
				FileOutputStream fo = new FileOutputStream("/home/lucas/variaveis_serializadas/listaIdUsers.ser");
				ObjectOutputStream oo = new ObjectOutputStream(fo);
				oo.writeObject(listaIdUsers); // serializo objeto cat
				oo.close();
			}else{
				FileInputStream fi = new FileInputStream("/home/lucas/variaveis_serializadas/listaIdUsers.ser");
				ObjectInputStream oi = new ObjectInputStream(fi);
				listaIdUsers =(List<String>) oi.readObject();
				oi.close();
			}
			
			System.out.println("D");
			
			if(ehPrimeiraVez){
				listaParaRankingDeRating = new ArrayList<DadosUsuario>();
				mapParaRankingDeRating = new HashMap<String, DadosUsuario>();
				inicializaMapEListaParaRankingDeRating(mapParaRankingDeRating, listaParaRankingDeRating, listaIdUsers);
			}else{
				FileInputStream fi = new FileInputStream("/home/lucas/variaveis_serializadas/listaParaRankingDeRating.ser");
				ObjectInputStream oi = new ObjectInputStream(fi);
				listaParaRankingDeRating =(List<DadosUsuario>) oi.readObject();
				oi.close();
				
				for(int  p=0; p< listaParaRankingDeRating.size(); p++){
					mapParaRankingDeRating.put(listaParaRankingDeRating.get(p).getId()+"", listaParaRankingDeRating.get(p));
				}
			}
			
			System.out.println("E");
			
			
			if(ehPrimeiraVez){
				mapRankingDeAnswerersCategorias = new HashMap<String, Map<String, Integer>>();
				mapRankingDeAskersCategorias = new HashMap<String, Map<String, Integer>>();
				mapUltimaPosicaoRankingDeRespostasPorCat = new HashMap<String, Integer>();
				mapUltimaPosicaoRankingDePerguntasPorCat = new HashMap<String, Integer>();
				preencheMapDadosUsuariosERanking(mapParaRankingDeRating, listaTags, mapRankingDeAnswerersCategorias, mapRankingDeAskersCategorias, mapUltimaPosicaoRankingDeRespostasPorCat, mapUltimaPosicaoRankingDePerguntasPorCat);
				
				FileOutputStream fo = new FileOutputStream("/home/lucas/variaveis_serializadas/mapRankingDeAnswerersCategorias.ser");
				ObjectOutputStream oo = new ObjectOutputStream(fo);
				oo.writeObject(mapRankingDeAnswerersCategorias); // serializo objeto cat
				oo.close();
				
				fo = new FileOutputStream("/home/lucas/variaveis_serializadas/mapRankingDeAskersCategorias.ser");
				oo = new ObjectOutputStream(fo);
				oo.writeObject(mapRankingDeAskersCategorias); // serializo objeto cat
				oo.close();
				
				fo = new FileOutputStream("/home/lucas/variaveis_serializadas/mapUltimaPosicaoRankingDeRespostasPorCat.ser");
				oo = new ObjectOutputStream(fo);
				oo.writeObject(mapUltimaPosicaoRankingDeRespostasPorCat); // serializo objeto cat
				oo.close();
				
				fo = new FileOutputStream("/home/lucas/variaveis_serializadas/mapUltimaPosicaoRankingDePerguntasPorCat.ser");
				oo = new ObjectOutputStream(fo);
				oo.writeObject(mapUltimaPosicaoRankingDePerguntasPorCat); // serializo objeto cat
				oo.close();
			}else{
				FileInputStream fi = new FileInputStream("/home/lucas/variaveis_serializadas/mapRankingDeAnswerersCategorias.ser");
				ObjectInputStream oi = new ObjectInputStream(fi);
				mapRankingDeAnswerersCategorias =(Map<String, Map<String, Integer>>) oi.readObject();
				oi.close();
				
				fi = new FileInputStream("/home/lucas/variaveis_serializadas/mapRankingDeAskersCategorias.ser");
				oi = new ObjectInputStream(fi);
				mapRankingDeAskersCategorias =(Map<String, Map<String, Integer>>) oi.readObject();
				oi.close();
				
				fi = new FileInputStream("/home/lucas/variaveis_serializadas/mapUltimaPosicaoRankingDeRespostasPorCat.ser");
				oi = new ObjectInputStream(fi);
				mapUltimaPosicaoRankingDeRespostasPorCat =(Map<String, Integer>) oi.readObject();
				oi.close();
				
				fi = new FileInputStream("/home/lucas/variaveis_serializadas/mapUltimaPosicaoRankingDePerguntasPorCat.ser");
				oi = new ObjectInputStream(fi);
				mapUltimaPosicaoRankingDePerguntasPorCat =(Map<String, Integer>) oi.readObject();
				oi.close();
			}
			
			System.out.println("F");
			
			//Nao vamos guardar essa informação em arquivo
			setCategoriasJaProcessadas = new HashSet<String>();
			//Map<cat, ultimaPosicaoRankingDeScoreDePergOuResp>
			mapUltimaPosicaoRankingDeScoreDeRespostasPorCat = new HashMap<String, Integer>();
			mapUltimaPosicaoRankingDeScoreDePerguntasPorCat = new HashMap<String, Integer>();
			
			if(ehPrimeiraVez){
				//setCategoriasJaProcessadas = new HashSet<String>();
				//Vamos preencher o map mapDadosUsuario com o score recebido a partir de perguntas e respostas para cada usuario
				//preencheMapParaRankingDeRating(mapParaRankingDeRating, listaParaRankingDeRating);
				preencheMapParaRankingDeScore(mapParaRankingDeRating);
				
				ComparatorScorePerguntas comparatorPerguntas = new ComparatorScorePerguntas();
				List<DadosUsuario> listaParaOrdenacaoDeScorePorPerguntar = new ArrayList<DadosUsuario>(listaParaRankingDeRating);
				Collections.sort(listaParaOrdenacaoDeScorePorPerguntar, comparatorPerguntas);
				ultimaPosicaoDoRankingDePerguntas = determinaOrdenacaoPorScoreDePerguntas(listaParaOrdenacaoDeScorePorPerguntar);
				System.out.println("pos 0 = " + listaParaOrdenacaoDeScorePorPerguntar.get(0).getScoreRecebidoPorPerguntar());
				System.out.println("pos ultima = " + listaParaOrdenacaoDeScorePorPerguntar.get(listaParaOrdenacaoDeScorePorPerguntar.size()-1).getScoreRecebidoPorPerguntar());
				
				ComparatorScoreRespostas comparatorRespostas = new ComparatorScoreRespostas();
				List<DadosUsuario> listaParaOrdenacaoDeScorePorResponder = new ArrayList<DadosUsuario>(listaParaRankingDeRating);
				Collections.sort(listaParaOrdenacaoDeScorePorResponder, comparatorRespostas);
				ultimaPosicaoDoRankingDeRespostas = determinaOrdenacaoPorScoreDeRespostas(listaParaOrdenacaoDeScorePorResponder);

				FileOutputStream fo = new FileOutputStream("/home/lucas/variaveis_serializadas/listaParaOrdenacaoDeScorePorPerguntar.ser");
				ObjectOutputStream oo = new ObjectOutputStream(fo);
				oo.writeObject(listaParaOrdenacaoDeScorePorPerguntar); // serializo objeto cat
				oo.close();
				
				fo = new FileOutputStream("/home/lucas/variaveis_serializadas/ultimaPosicaoDoRankingDePerguntas.ser");
				oo = new ObjectOutputStream(fo);
				oo.writeObject(ultimaPosicaoDoRankingDePerguntas); // serializo objeto cat
				oo.close();
				
				fo = new FileOutputStream("/home/lucas/variaveis_serializadas/listaParaOrdenacaoDeScorePorResponder.ser");
				oo = new ObjectOutputStream(fo);
				oo.writeObject(listaParaOrdenacaoDeScorePorResponder); // serializo objeto cat
				oo.close();
				
				fo = new FileOutputStream("/home/lucas/variaveis_serializadas/ultimaPosicaoDoRankingDeRespostas.ser");
				oo = new ObjectOutputStream(fo);
				oo.writeObject(ultimaPosicaoDoRankingDeRespostas); // serializo objeto cat
				oo.close();
			}else{
				/*FileInputStream fi = new FileInputStream("/home/lucas/variaveis_serializadas/setCategoriasJaProcessadas.ser");
				ObjectInputStream oi = new ObjectInputStream(fi);
				setCategoriasJaProcessadas =(Set<String>) oi.readObject();
				oi.close();*/
				
				FileInputStream fi = new FileInputStream("/home/lucas/variaveis_serializadas/ultimaPosicaoDoRankingDePerguntas.ser");
				ObjectInputStream oi = new ObjectInputStream(fi);
				ultimaPosicaoDoRankingDePerguntas =(Integer) oi.readObject();
				oi.close();
				
				fi = new FileInputStream("/home/lucas/variaveis_serializadas/ultimaPosicaoDoRankingDeRespostas.ser");
				oi = new ObjectInputStream(fi);
				ultimaPosicaoDoRankingDeRespostas =(Integer) oi.readObject();
				oi.close();
				
				/*fi = new FileInputStream("/home/lucas/variaveis_serializadas/mapUltimaPosicaoRankingDeScoreDeRespostasPorCat.ser");
				oi = new ObjectInputStream(fi);
				mapUltimaPosicaoRankingDeScoreDeRespostasPorCat =(Map<String, Integer>) oi.readObject();
				oi.close();
				
				fi = new FileInputStream("/home/lucas/variaveis_serializadas/mapUltimaPosicaoRankingDeScoreDePerguntasPorCat.ser");
				oi = new ObjectInputStream(fi);
				mapUltimaPosicaoRankingDeScoreDePerguntasPorCat =(Map<String, Integer>) oi.readObject();
				oi.close();*/
			}
			
			if(ehPrimeiraVez){
				FileOutputStream fo = new FileOutputStream("/home/lucas/variaveis_serializadas/listaParaRankingDeRating.ser");
				ObjectOutputStream oo = new ObjectOutputStream(fo);
				oo.writeObject(listaParaRankingDeRating); // serializo objeto cat
				oo.close();
			}
			System.out.println("G");
			long tempoFinal = System.currentTimeMillis();
			System.out.println("Tempo gasto nas inicializacoes: " + (tempoFinal-tempoInicial));
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	private  String selecinaCategoriaParaSerRemovida(List<String> listaTagsPergunta) {
		
		
		
		Random randomGenerator = new Random(); 
		int tamanhoSet = setCategoriasJaProcessadas.size();
		
		while(true){
			int indice = randomGenerator.nextInt(tamanhoSet);
			String categoriaASerRremovida = "";
			int i=0;
			for(Object obj : setCategoriasJaProcessadas)
			{
			    if (i == indice){
			    	categoriaASerRremovida = (String)obj;
			    	if(!listaTagsPergunta.contains(categoriaASerRremovida))
			    		return categoriaASerRremovida;
			    	else
			    		break;
			    	//else
			    	//setCategoriasJaProcessadas.remove(categoriaASerRremovida);
			    	//System.out.println("Removendo Categoria " + categoriaASerRremovida);
			    	//break;
			    }
			    i++;
			}
			return null;
		}
		
		
		
		/*(int j=0; j< listaParaRankingDeRating.size(); j++){
			DadosUsuario du =  listaParaRankingDeRating.get(j);
			Map<String, DadosRatingCategoria> mapCategorias = du.getMapInfoRankingPorCategoria();
			mapCategorias.put(categoriaASerRremovida, null);
			mapCategorias.remove(categoriaASerRremovida);
		}
		
		mapUltimaPosicaoRankingDeScoreDeRespostasPorCat.remove(categoriaASerRremovida);
		mapUltimaPosicaoRankingDeScoreDePerguntasPorCat.remove(categoriaASerRremovida);*/
		
	}

	private  List<String> descobreTagsLib() {
		List<String> listaTags = new ArrayList<String>();
		try{
			String query = ConsultasBD.consultaTagsLib();
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				String tagName = rs.getString("TagName");
				listaTags.add(tagName);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaTags;
	}

	private  int calculaNroEdicoesNaPergunta(int idPergunta) {
		try{
			String query = ConsultasBD.consultaNroEdicoesNaPergunta(idPergunta);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroEdicoes = rs.getInt("nroEdicoesNAPergunta");
			return nroEdicoes;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaViewCount(int idPergunta) {
		try{
			String query = ConsultasBD.consultaViewCount(idPergunta);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int viewCount = rs.getInt("viewCount");
			return viewCount;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int verificaSeEhRespostaAceita(int idResposta) {
		try{
			String query = ConsultasBD.consultaEhRespostaAceita(idResposta);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int ehRespostaAceita = rs.getInt("ehAceita");
			return ehRespostaAceita;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaReputacaoDeUsuario(int idUser) {
		try{
			String query = ConsultasBD.consultaReputacaoDeUsuario(idUser);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int reputacao = rs.getInt("reputacao");
			return reputacao;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  List<Integer> calculaListaComReputacaoDeEditoresDaPergunta(
			int idResposta) {
		List<Integer> listaReputacoes = new ArrayList<Integer>();
		try{
			String query = ConsultasBD.consultaReputacaoDeEditoresDePergunta(idResposta);
			List<String> listaUsers = new ArrayList<String>();
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				String userId = rs.getString("idUser");
				if(listaUsers.contains(userId)){
					System.out.println("PULANDO...");
					continue;
				}
					
				listaUsers.add(userId);
				int reputacao = rs.getInt("reputacao");
				listaReputacoes.add(reputacao);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaReputacoes;
	}
	
	private  List<Integer> calculaListaComReputacaoDeEditoresDaResposta(
			int idResposta) {
		List<Integer> listaReputacoes = new ArrayList<Integer>();
		try{
			String query = ConsultasBD.consultaReputacaoDeEditoresDeResposta(idResposta);
			List<String> listaUsers = new ArrayList<String>();
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				String userId = rs.getString("idUser");
				if(listaUsers.contains(userId)){
					System.out.println("PULANDO...");
					continue;
				}
					
				listaUsers.add(userId);
				int reputacao = rs.getInt("reputacao");
				listaReputacoes.add(reputacao);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaReputacoes;
	}

	private  int calculaNroDeCaracteresEmPost(String corpoResposta,
			ManipuladorDeTexto mt) {
		try{
			//Primeiro vamos remover os codigos, uams vez que nao sera considerados no calculo de tamanho do post
			HtmlCleaner cleaner = new HtmlCleaner();
			TagNode root = cleaner.clean( corpoResposta );
			Object[] codeNodes = root.evaluateXPath( "//code" );
			  for(int i=0; i<codeNodes.length; i++){
				  ((TagNode)codeNodes[i]).removeFromTree();
			}
			String texto = "";
			texto += root.getText();
			return texto.length();
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDeSentencasEmPost(String corpoResposta,
			ManipuladorDeTexto mt) {
		try{
			//Primeiro vamos remover os codigos, uams vez que nao sera considerados no calculo de tamanho do post
			HtmlCleaner cleaner = new HtmlCleaner();
			TagNode root = cleaner.clean( corpoResposta );
			Object[] codeNodes = root.evaluateXPath( "//code" );
			  for(int i=0; i<codeNodes.length; i++){
				  ((TagNode)codeNodes[i]).removeFromTree();
			}
			String texto = "";
			texto += root.getText();
			return mt.DetectaSetencas(texto).length;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDePalavrasEmPost(String corpoResposta, ManipuladorDeTexto mt) {
		try{
			//Primeiro vamos remover os codigos, uams vez que nao sera considerados no calculo de tamanho do post
			HtmlCleaner cleaner = new HtmlCleaner();
			TagNode root = cleaner.clean( corpoResposta );
			Object[] codeNodes = root.evaluateXPath( "//code" );
			  for(int i=0; i<codeNodes.length; i++){
				  ((TagNode)codeNodes[i]).removeFromTree();
			}
			String texto = "";
			texto += root.getText();
			return mt.recuperaTokens(texto).size();
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  List<Integer> calculaPosicoesNosRankingDeScorePerguntasDeCadaCategoria(
			int idAnswerer, Map<String, DadosUsuario> mapParaRankingDeRating,
			List<String> listaCategoriasDoPar, Map<String, Integer> mapUltimaPosicaoRankingDeScoreDePerguntasPorCat) {
		List<Integer> listaPosicoes = new ArrayList<Integer>();
		
		for(int i=0; i< listaCategoriasDoPar.size(); i++){
			String categoria = listaCategoriasDoPar.get(i);
			
				//Caso seja um usuario carregado na memoria
				if(mapParaRankingDeRating.containsKey(idAnswerer+"")){
					Map<String, DadosRatingCategoria> mpdrc = mapParaRankingDeRating.get(idAnswerer+"").getMapInfoRankingPorCategoria();
					//Caso aquele usuario tenha sido retornado no select de rankeamento daquela categoria
					if(mpdrc.containsKey(categoria)){
						int posRank = mpdrc.get(categoria).getPosicaoNoRankingDeScoreDePerguntasDestaCategoria();
						if(posRank == 0)
							listaPosicoes.add(mapUltimaPosicaoRankingDeScoreDePerguntasPorCat.get(categoria)+1);
						else
							listaPosicoes.add(posRank);
					}
						
					else
						listaPosicoes.add(mapUltimaPosicaoRankingDeScoreDePerguntasPorCat.get(categoria)+1);
				}
				else
					listaPosicoes.add(mapUltimaPosicaoRankingDeScoreDePerguntasPorCat.get(categoria)+1);
		}
		return listaPosicoes;
	}
	
	private  List<Integer> calculaPosicoesNosRankingDeScoreRespostasDeCadaCategoria(
			int idAnswerer, Map<String, DadosUsuario> mapParaRankingDeRating,
			List<String> listaCategoriasDoPar, Map<String, Integer> mapUltimaPosicaoRankingDeScoreDeRespostasPorCat) {
		List<Integer> listaPosicoes = new ArrayList<Integer>();
		
		for(int i=0; i< listaCategoriasDoPar.size(); i++){
			String categoria = listaCategoriasDoPar.get(i);
			//Caso já seja uma categoria procesada, basta pegar a posicao no ranking
			if(mapParaRankingDeRating.containsKey(idAnswerer+"")){
				Map<String, DadosRatingCategoria> mpdrc = mapParaRankingDeRating.get(idAnswerer+"").getMapInfoRankingPorCategoria();
				if(mpdrc.containsKey(categoria)){
					int posRank = mpdrc.get(categoria).getPosicaoNoRankingDeScoreDeRespostasDestaCategoria();
					if(posRank == 0)
						listaPosicoes.add(mapUltimaPosicaoRankingDeScoreDeRespostasPorCat.get(categoria)+1);
					else
						listaPosicoes.add(posRank);
				}
					
				else
					listaPosicoes.add(mapUltimaPosicaoRankingDeScoreDeRespostasPorCat.get(categoria)+1);
			}
				
			else
				listaPosicoes.add(mapUltimaPosicaoRankingDeScoreDeRespostasPorCat.get(categoria)+1);
		}
		return listaPosicoes;
	}

	private  int determinaOrdenacaoPorScoreDeRespostas(
			List<DadosUsuario> listaParaRankingDeRating) {
		int scoreAnterior = -1;
		int posicaoNoRanking = 0;
		for(int i=0; i<listaParaRankingDeRating.size(); i++){
			DadosUsuario du = listaParaRankingDeRating.get(i);
			int scorePorResponder = du.getScoreRecebidoPorResponder();
			if(scorePorResponder != scoreAnterior)
				posicaoNoRanking++;
			du.setPosicaoNoRankingDeScoreDeRespostas(posicaoNoRanking);
			scoreAnterior = scorePorResponder;
		}
		if(scoreAnterior == Integer.MIN_VALUE)
			return posicaoNoRanking;
		else
			return posicaoNoRanking + 1;
	}
	
	private  int determinaOrdenacaoPorScoreDePerguntas(
			List<DadosUsuario> listaParaRankingDeRating) {
		int scoreAnterior = -1;
		int posicaoNoRanking = 0;
		for(int i=0; i<listaParaRankingDeRating.size(); i++){
			DadosUsuario du = listaParaRankingDeRating.get(i);
			int scorePorPerguntar = du.getScoreRecebidoPorPerguntar();
			if(scorePorPerguntar != scoreAnterior)
				posicaoNoRanking++;
			du.setPosicaoNoRankingDeScoreDePerguntas(posicaoNoRanking);
			scoreAnterior = scorePorPerguntar;
		}
		
		if(scoreAnterior == Integer.MIN_VALUE)
			return posicaoNoRanking;
		else
			return posicaoNoRanking + 1;
	}

	private  List<Integer> calculaScoreRecebidoPorResponderEmCategorias(
			int idAnswerer, List<String> listaCategoriasDoPar,
			Map<String, DadosUsuario> mapParaRankingDeRating) {
		List<Integer> listaScoreRecebidoPorResponderEmCategorias = new ArrayList<Integer>();
		
		for(int i=0; i< listaCategoriasDoPar.size(); i++){
			String categoria = listaCategoriasDoPar.get(i);
			
			if(mapParaRankingDeRating.containsKey(idAnswerer+"")){
				Map<String, DadosRatingCategoria> mpdrc = mapParaRankingDeRating.get(idAnswerer+"").getMapInfoRankingPorCategoria();
				if(mpdrc.containsKey(categoria))
					listaScoreRecebidoPorResponderEmCategorias.add(mpdrc.get(categoria).getScoreRecebidoPorResponderNestaCategoria());
				else
					listaScoreRecebidoPorResponderEmCategorias.add(0);
			}
			else
				listaScoreRecebidoPorResponderEmCategorias.add(0);
		}
		
		return listaScoreRecebidoPorResponderEmCategorias;
	}
	
	private  List<Integer> calculaScoreRecebidoPorPerguntarEmCategorias(
			int idAnswerer, List<String> listaCategoriasDoPar,
			Map<String, DadosUsuario> mapParaRankingDeRating) {
		List<Integer> listaScoreRecebidoPorPerguntarEmCategorias = new ArrayList<Integer>();
		
		for(int i=0; i< listaCategoriasDoPar.size(); i++){
			String categoria = listaCategoriasDoPar.get(i);
			
			if(mapParaRankingDeRating.containsKey(idAnswerer+"")){
				Map<String, DadosRatingCategoria> mpdrc = mapParaRankingDeRating.get(idAnswerer+"").getMapInfoRankingPorCategoria();
				if(mpdrc.containsKey(categoria))
					listaScoreRecebidoPorPerguntarEmCategorias.add(mpdrc.get(categoria).getScoreRecebidoPorPerguntarNestaCategoria());
				else
					listaScoreRecebidoPorPerguntarEmCategorias.add(0);
			}
			else
				listaScoreRecebidoPorPerguntarEmCategorias.add(0);
		}
		
		return listaScoreRecebidoPorPerguntarEmCategorias;
	}

	private  void preencheMapParaRankingDeScorePorCategoria(
			Map<String, DadosUsuario> mapParaRankingDeRating,
			List<DadosUsuario> listaParaRankingDeRating,
			Set<String> setCategoriasJaProcessadas,
			List<String> listaCategoriasDoPar, Map<String, Integer> mapUltimaPosicaoRankingDeScoreDeRespostasPorCat, Map<String, Integer> mapUltimaPosicaoRankingDeScoreDePerguntasPorCat, Map<String, Integer> mapCategoriaId, List<String> listaCategoriasDoPar2) {
		try{
			//Se a categoria ja foi processado, pulamos ela pois significa que ja calculamos o rankeamento de scores para a categoria
			for(int i=0; i< listaCategoriasDoPar.size(); i++){
				String categoria = listaCategoriasDoPar.get(i);
				if(setCategoriasJaProcessadas.contains(categoria))
					continue;
				
				/*String categoriaASerLiberada = "";
				if(setCategoriasJaProcessadas.size() >= 10){
					categoriaASerLiberada = selecinaCategoriaParaSerRemovida(listaCategoriasDoPar);
					setCategoriasJaProcessadas.remove(categoriaASerLiberada);
				}*/
					
				System.out.println("Processando categoria " + categoria);
			
				/*if(categoriaASerLiberada.equals("")){
					//Vamos inicializar a categoria para todos os usuarios 
					for(int j=0; j< listaParaRankingDeRating.size(); j++){
						DadosUsuario du = listaParaRankingDeRating.get(j);
						du.getMapInfoRankingPorCategoria().put(categoria, new DadosRatingCategoria(categoria));
					}
				}*/
				
				
				int idCategoria = mapCategoriaId.get(categoria);
				String arquivoCategoriaPergunta = "/home/lucas/Dropbox/rakings_score_por_cat/" + idCategoria + "Q.txt";
				BufferedReader bufferedReaderArquivoResult = new BufferedReader(new InputStreamReader(new FileInputStream(arquivoCategoriaPergunta)));
				bufferedReaderArquivoResult.readLine();
				
				int scoreAnterior = -1;
				int posicaoNoRanking = 0;
				String line = "";
				while ((line = bufferedReaderArquivoResult.readLine()) != null) {
					String partes[] = line.split("\t");
					String userId = partes[0];
					
					if(userId.equals("439963")){
						int a = 1;
						int b = a;
					}
					
					
					int score = Integer.parseInt(partes[1]);
					if(score != scoreAnterior)
						posicaoNoRanking++;
					scoreAnterior = score;
					DadosUsuario du = mapParaRankingDeRating.get(userId);
					if(du ==null)
						continue;
					
					//if(categoriaASerLiberada.equals("")){
						if(!du.getMapInfoRankingPorCategoria().containsKey(categoria)){
							DadosRatingCategoria drc = new DadosRatingCategoria(categoria);
							du.getMapInfoRankingPorCategoria().put(categoria, drc);
							drc.setScoreRecebidoPorPerguntarNestaCategoria(score);
							drc.setPosicaoNoRankingDeScoreDePerguntasDestaCategoria(posicaoNoRanking);
						}
						else{
							DadosRatingCategoria drc = du.getMapInfoRankingPorCategoria().get(categoria);
							drc.setScoreRecebidoPorPerguntarNestaCategoria(score);
							drc.setPosicaoNoRankingDeScoreDePerguntasDestaCategoria(posicaoNoRanking);
						}
				
						
					/*}else{
						DadosRatingCategoria drc = du.getMapInfoRankingPorCategoria().get(categoriaASerLiberada);
						drc.setScoreRecebidoPorPerguntar(score);
						drc.setPosicaoNoRankingDeScoreDePerguntas(posicaoNoRanking);
						
						du.getMapInfoRankingPorCategoria().remove(categoriaASerLiberada);
						drc.setNomeDaCategoria(categoria);
						du.getMapInfoRankingPorCategoria().put(categoria, drc);
					}*/
					
				}
				mapUltimaPosicaoRankingDeScoreDePerguntasPorCat.put(categoria, posicaoNoRanking);
				bufferedReaderArquivoResult.close();
				
				String arquivoCategoriaResposta = "/home/lucas/Dropbox/rakings_score_por_cat/" + idCategoria + "A.txt";
				bufferedReaderArquivoResult = new BufferedReader(new InputStreamReader(new FileInputStream(arquivoCategoriaResposta)));
				bufferedReaderArquivoResult.readLine();
				
				scoreAnterior = -1;
				posicaoNoRanking = 0;
				while ((line = bufferedReaderArquivoResult.readLine()) != null) {
					String partes[] = line.split("\t");
					
					String userId = partes[0];
					
					
					
					if(userId.equals("439963")){
						int a = 1;
						int b = a;
					}
					
					int score = Integer.parseInt(partes[1]);
					if(score != scoreAnterior)
						posicaoNoRanking++;
					scoreAnterior = score;
					DadosUsuario du = mapParaRankingDeRating.get(userId);
					if(du ==null)
						continue;
					
					if(!du.getMapInfoRankingPorCategoria().containsKey(categoria)){
						DadosRatingCategoria drc = new DadosRatingCategoria(categoria);
						du.getMapInfoRankingPorCategoria().put(categoria, drc);
						drc.setScoreRecebidoPorResponderNestaCategoria(score);
						drc.setPosicaoNoRankingDeScoreDeRespostasDestaCategoria(posicaoNoRanking);
					}
					else{
						DadosRatingCategoria drc = du.getMapInfoRankingPorCategoria().get(categoria);
						drc.setScoreRecebidoPorResponderNestaCategoria(score);
						drc.setPosicaoNoRankingDeScoreDeRespostasDestaCategoria(posicaoNoRanking);
					}
					//if(categoriaASerLiberada.equals("")){
						
					/*}else{
						if(du.getMapInfoRankingPorCategoria().containsKey(categoria)){
							DadosRatingCategoria drc = du.getMapInfoRankingPorCategoria().get(categoria);
							drc.setScoreRecebidoPorResponder(score);
							drc.setPosicaoNoRankingDeScoreDeRespostas(posicaoNoRanking);
						}else{
							DadosRatingCategoria drc = du.getMapInfoRankingPorCategoria().get(categoriaASerLiberada);
							drc.setScoreRecebidoPorResponder(score);
							drc.setPosicaoNoRankingDeScoreDeRespostas(posicaoNoRanking);
							
							du.getMapInfoRankingPorCategoria().remove(categoriaASerLiberada);
							drc.setNomeDaCategoria(categoria);
							du.getMapInfoRankingPorCategoria().put(categoria, drc);
						}
						
					}*/
					
					
					
				}
				mapUltimaPosicaoRankingDeScoreDeRespostasPorCat.put(categoria, posicaoNoRanking);
				bufferedReaderArquivoResult.close();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		/*try{
			//Se a categoria ja foi processado, pulamos ela pois significa que ja calculamos o rankeamento de scores para a categoria
			for(int i=0; i< listaCategoriasDoPar.size(); i++){
				String categoria = listaCategoriasDoPar.get(i);
				if(setCategoriasJaProcessadas.contains(categoria))
					continue;
				
				System.out.println("Processando categoria " + categoria);
				
				//Vamos inicializar a categoria para todos os usuarios 
				for(int j=0; j< listaParaRankingDeRating.size(); j++){
					DadosUsuario du = listaParaRankingDeRating.get(j);
					du.getMapInfoRankingPorCategoria().put(categoria, new DadosRatingCategoria(categoria));
				}
				
				int scoreAnterior = -1;
				int posicaoNoRanking = 0;
				String query = ConsultasBD.consultaScoreRecebidoPorPerguntarPorCat(categoria);
				ResultSet rs = cbd.executaQuery(query);
				while(rs.next()){
					String userId = rs.getString("idUser");
					int score = rs.getInt("score");
					if(score != scoreAnterior)
						posicaoNoRanking++;
					scoreAnterior = score;
					DadosUsuario du = mapParaRankingDeRating.get(userId);
					if(du ==null)
						continue;
					DadosRatingCategoria drc = du.getMapInfoRankingPorCategoria().get(categoria);
					drc.setScoreRecebidoPorPerguntar(score);
					drc.setPosicaoNoRankingDeScoreDePerguntas(posicaoNoRanking);
				}
				mapUltimaPosicaoRankingDeScoreDePerguntasPorCat.put(categoria, posicaoNoRanking);
				
				
				scoreAnterior = -1;
				posicaoNoRanking = 0;
				query = ConsultasBD.consultaScoreRecebidoPorResponderPorCat(categoria);
				rs = cbd.executaQuery(query);
				while(rs.next()){
					String userId = rs.getString("idUser");
					int score = rs.getInt("score");
					if(score != scoreAnterior)
						posicaoNoRanking++;
					scoreAnterior = score;
					DadosUsuario du = mapParaRankingDeRating.get(userId);
					if(du ==null)
						continue;
					DadosRatingCategoria drc = du.getMapInfoRankingPorCategoria().get(categoria);
					drc.setScoreRecebidoPorResponder(score);
					drc.setPosicaoNoRankingDeScoreDeRespostas(posicaoNoRanking);
				}
				mapUltimaPosicaoRankingDeScoreDeRespostasPorCat.put(categoria, posicaoNoRanking);
			}
		}catch(Exception e){
			e.printStackTrace();
		}*/
		
	}

	private  void preencheMapParaRankingDeScore(
			Map<String, DadosUsuario> mapParaRankingDeRating) {
		
		try{
			//Para cada usuaro, calculamos o score recebido por perguntar
			String query = ConsultasBD.consultaScoreRecebidoPorPerguntarGeral();
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				String userId = rs.getString("owneruserid");
				int score = rs.getInt("score");
				DadosUsuario du = mapParaRankingDeRating.get(userId);
				if(du == null)
					continue;
				du.setScoreRecebidoPorPerguntar(score);
			}
			
			//Para cada usuaro, calculamos o score recebido por responder
			query = ConsultasBD.consultaScoreRecebidoPorResponderGeral();
			rs = cbd.executaQuery(query);
			while(rs.next()){
				String userId = rs.getString("owneruserid");
				int score = rs.getInt("score");
				DadosUsuario du = mapParaRankingDeRating.get(userId);
				if(du == null)
					continue;
				du.setScoreRecebidoPorResponder(score);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	private  int calculaScoreRecebidoPorResponder(int idUsuario) {
		try{
			String query = ConsultasBD.consultaScoreRecebidoPorResponder(idUsuario);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int scoreRecebidoPorResponder = rs.getInt("score");
			return scoreRecebidoPorResponder;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
	
	private  int calculaScoreRecebidoPorPerguntar(int idUsuario) {
		try{
			String query = ConsultasBD.consultaScoreRecebidoPorPerguntar(idUsuario);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int scoreRecebidoPorPerguntar = rs.getInt("score");
			return scoreRecebidoPorPerguntar;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaSomaDeLista(
			List<Integer> listaRatingRecebidoPorPerguntarEmCategorias) {
		int soma=0;
		for(int i=0; i< listaRatingRecebidoPorPerguntarEmCategorias.size(); i++){
			soma +=  listaRatingRecebidoPorPerguntarEmCategorias.get(i);
		}
		return soma;
	}

	private  int calculaNroDeInteracoes(String corpoResposta) {
		try{
			//Primeiro vamos remover os codigos, uams vez que nao sera considerados @ presente em codigo fonte
			HtmlCleaner cleaner = new HtmlCleaner();
			TagNode root = cleaner.clean( corpoResposta );
			Object[] codeNodes = root.evaluateXPath( "//code" );
			  for(int i=0; i<codeNodes.length; i++){
				  ((TagNode)codeNodes[i]).removeFromTree();
			}
			String texto = "";
			texto += root.getText();
			int count = StringUtils.countMatches(texto, "@");	
			return count;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  List<Integer> calculaTamanhosSecoes(String corpoResposta, ManipuladorDeTexto mt) {
		List<Integer> listaTamanhosCodigos = new ArrayList<Integer>();
		try{
			//Primeiro vamos remover os codigos, uams vez que eles nao serao considerados no calculo de tamanho das secoes
			HtmlCleaner cleaner = new HtmlCleaner();
			TagNode root = cleaner.clean( corpoResposta );
			Object[] codeNodes = root.evaluateXPath( "//code" );
			  for(int i=0; i<codeNodes.length; i++){
				  ((TagNode)codeNodes[i]).removeFromTree();
			}
			boolean comecouSecao = false;
			String textoSecao = "";
			List<TagNode> tags = root.getAllElementsList(true);
			TagNode paiDoUltimoH1=null;
			for(int i=0; i<tags.size(); i++){
				if(tags.get(i).getName().equals("h1")|| tags.get(i).getName().equals("H1")){
					if(comecouSecao)
						listaTamanhosCodigos.add(mt.recuperaTokens(textoSecao).size());
					
					comecouSecao = true;
					textoSecao = ""; 
					paiDoUltimoH1 = tags.get(i).getParent();
				}
				else if(comecouSecao && paiDoUltimoH1==tags.get(i).getParent()){
					textoSecao += "\n" + tags.get(i).getText();
					TagNode tagsFilhas[] = tags.get(i).getAllElements(true);
					int nroDeTagsASeremEleminadas = tagsFilhas.length;
					
					for(int j=0; j< nroDeTagsASeremEleminadas; j++){
							tags.remove(i+1);
					}
				}
				else if(comecouSecao && paiDoUltimoH1!=tags.get(i).getParent()){
					comecouSecao = false;
					listaTamanhosCodigos.add(mt.recuperaTokens(textoSecao).size());
					textoSecao = ""; 
				}
			}
			
			if(comecouSecao){
				listaTamanhosCodigos.add(mt.recuperaTokens(textoSecao).size());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaTamanhosCodigos;
	}

	private  double calculaEntropiaDePerguntasERespostas(
			List<Integer> listaNroPerguntasPostadasPorCategoria,
			List<Integer> listaNroRespostasPostadasPorCategoria, boolean normalizaEntropa) {
		
		List<Integer> listaGeral = new ArrayList<Integer>();
		for(int i=0; i< listaNroPerguntasPostadasPorCategoria.size(); i++){
			listaGeral.add(listaNroPerguntasPostadasPorCategoria.get(i) + listaNroRespostasPostadasPorCategoria.get(i));
		}
		
		return calculaEntropia(listaGeral, normalizaEntropa);
	}

	private  double calculaEntropia(
			List<Integer> listaGeral, boolean normalizaEntropa) {
		
		double soma = 0;
		for(int i=0; i< listaGeral.size(); i++){
			soma += listaGeral.get(i);
		}
		
		int tamanho = listaGeral.size();
		double entropiaTotal = 0;
		
		for(int i=0; i< listaGeral.size(); i++){
			double prob;
			if(listaGeral.get(i) == 0)
				prob = 0;
			else
				prob =  listaGeral.get(i)/(double)soma;
			if(prob != 0){
				entropiaTotal += prob*(Math.log(prob)/Math.log(2));
			}
		}
		
		if(normalizaEntropa)
			return -entropiaTotal/tamanho;
		else{
			return -entropiaTotal;
		}
	}

	private  int calculaNroDeEditsSugeridosRejeitadosEmPost(int idPost) {
		try{
			String query = ConsultasBD.consultaNroDeEditsSugeridosRejeitadosPorPost(idPost);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroEditsSugeridos = rs.getInt("nroEditsSugeridos");
			return nroEditsSugeridos;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDeEditsSugeridosAprovadosEmPost(int idPost) {
		try{
			String query = ConsultasBD.consultaNroDeEditsSugeridosAprovadosPorPost(idPost);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroEditsSugeridos = rs.getInt("nroEditsSugeridos");
			return nroEditsSugeridos;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDeUsuariosQueSugeriramEdicoes(int idResposta, int idPergunta) {
		try{
			String query = ConsultasBD.consultaNroDeUsuariosQueSugeriramEdicoes(idResposta, idPergunta);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroEditsSugeridos = rs.getInt("nroUsuarios");
			return nroEditsSugeridos;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDeEdicoesSugeridasAPost(int idPost) {
		try{
			String query = ConsultasBD.consultaNroDeEditSugeridosAPost(idPost);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroEditsSugeridos = rs.getInt("nroEditsSugeridos");
			return nroEditsSugeridos;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDeEditsRejeitadosPropostosPorUsuario(int idAnswerer) {
		try{
			String query = ConsultasBD.consultaNroDeEditSugeridosRejeitados(idAnswerer);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroEditsSugeridos = rs.getInt("nroEditsSugeridos");
			return nroEditsSugeridos;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDeEditsAprovadosPropostosPorUsuario(int idAnswerer) {
		try{
			String query = ConsultasBD.consultaNroDeEditSugeridosAprovados(idAnswerer);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroEditsSugeridos = rs.getInt("nroEditsSugeridos");
			return nroEditsSugeridos;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDeEditsSugeridos(int idAnswerer) {
		try{
			String query = ConsultasBD.consultaNroDeEditSugeridos(idAnswerer);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroEditsSugeridos = rs.getInt("nroEditsSugeridos");
			return nroEditsSugeridos;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	/*private  List<Integer> calculaRatingRecebidoPorResponderEmCategorias(
			int idAnswerer, List<String> listaCategorias,
			Map<String, DadosUsuario> mapParaRankingDeRating) {
		
		List<Integer> listaRatingRecebidoPorResponderEmCategorias = new ArrayList<Integer>();
		
		for(int i=0; i< listaCategorias.size(); i++){
			listaRatingRecebidoPorResponderEmCategorias.add(mapParaRankingDeRating.get(idAnswerer+"").getMapInfoRankingPorCategoria().get(listaCategorias.get(i)).getRatingRecebidoPorResponder());
		}
		
		return listaRatingRecebidoPorResponderEmCategorias;
	}*/
	
	/*private  List<Integer> calculaRatingRecebidoPorPerguntarEmCategorias(
			int idAnswerer, List<String> listaCategorias,
			Map<String, DadosUsuario> mapParaRankingDeRating) {
		
		List<Integer> listaRatingRecebidoPorPerguntarEmCategorias = new ArrayList<Integer>();
		
		for(int i=0; i< listaCategorias.size(); i++){
			listaRatingRecebidoPorPerguntarEmCategorias.add(mapParaRankingDeRating.get(idAnswerer+"").getMapInfoRankingPorCategoria().get(listaCategorias.get(i)).getRatingRecebidoPorPerguntar());
		}
		
		return listaRatingRecebidoPorPerguntarEmCategorias;
	}*/

	/*private  List<Integer> calculaPosicoesNosRankingDeRespostasDeCadaCategoria(
			int idAnswerer, Map<String, DadosUsuario> mapParaRankingDeRating, List<DadosUsuario> listaParaRankingDeRating,
			Set<String> setCategoriasJaProcessadas, List<String> listaCategorias) {
		List<Integer> listaPosicoes = new ArrayList<Integer>();
		
		for(int i=0; i< listaCategorias.size(); i++){
			String categoria = listaCategorias.get(i);
			//Caso já seja uma categoria procesada, basta pegar a posicao no ranking
			if(setCategoriasJaProcessadas.contains(categoria)){
				listaPosicoes.add(mapParaRankingDeRating.get(idAnswerer+"").getMapInfoRankingPorCategoria().get(categoria).getPosicaoNoRankingDeRatingDeRespostas());
			}else{
				ComparatorRatingRespostasPorCategoia comp = new ComparatorRatingRespostasPorCategoia(categoria);
				Collections.sort(listaParaRankingDeRating, comp);
				
				int ratingAnterior = -1;
				int posicaoNoRanking = 0;
				for(int j=0; j<listaParaRankingDeRating.size(); j++){
					DadosRatingCategoria drc = listaParaRankingDeRating.get(j).getMapInfoRankingPorCategoria().get(categoria);
					int ratingPorResponder = drc.getRatingRecebidoPorResponder();
					if(ratingPorResponder != ratingAnterior)
						posicaoNoRanking++;
					drc.setPosicaoNoRankingDeRatingDeRespostas(posicaoNoRanking);
					ratingAnterior = ratingPorResponder;
				}
				listaPosicoes.add(mapParaRankingDeRating.get(idAnswerer+"").getMapInfoRankingPorCategoria().get(categoria).getPosicaoNoRankingDeRatingDeRespostas());
			}
		}
		return listaPosicoes;
	}*/
	
	/*private  List<Integer> calculaPosicoesNosRankingDePerguntasDeCadaCategoria(
			int idAnswerer, Map<String, DadosUsuario> mapParaRankingDeRating, List<DadosUsuario> listaParaRankingDeRating,
			Set<String> setCategoriasJaProcessadas, List<String> listaCategorias) {
		List<Integer> listaPosicoes = new ArrayList<Integer>();
		
		for(int i=0; i< listaCategorias.size(); i++){
			String categoria = listaCategorias.get(i);
			//Caso já seja uma categoria procesada, basta pegar a posicao no ranking
			if(setCategoriasJaProcessadas.contains(categoria)){
				listaPosicoes.add(mapParaRankingDeRating.get(idAnswerer+"").getMapInfoRankingPorCategoria().get(categoria).getPosicaoNoRankingDeRatingDePerguntas());
			}else{
				ComparatorRatingPerguntasPorCategoia comp = new ComparatorRatingPerguntasPorCategoia(categoria);
				Collections.sort(listaParaRankingDeRating, comp);
				
				int ratingAnterior = -1;
				int posicaoNoRanking = 0;
				for(int j=0; j<listaParaRankingDeRating.size(); j++){
					DadosRatingCategoria drc = listaParaRankingDeRating.get(j).getMapInfoRankingPorCategoria().get(categoria);
					int ratingPorPerguntar = drc.getRatingRecebidoPorPerguntar();
					if(ratingPorPerguntar != ratingAnterior)
						posicaoNoRanking++;
					drc.setPosicaoNoRankingDeRatingDePerguntas(posicaoNoRanking);
					ratingAnterior = ratingPorPerguntar;
				}
				listaPosicoes.add(mapParaRankingDeRating.get(idAnswerer+"").getMapInfoRankingPorCategoria().get(categoria).getPosicaoNoRankingDeRatingDePerguntas());
			}
		}
		return listaPosicoes;
	}*/

	/*private  void preencheMapParaRankingDeRatingPorCategoria(Map<String, DadosUsuario> mapParaRankingDeRating, List<DadosUsuario> listaParaRankingDeRating, Set<String> setCats, List<String> listaCategorias) {
		try{
			//Se a categoria ja foi processado, pulamos ela
			for(int i=0; i< listaCategorias.size(); i++){
				String categoria = listaCategorias.get(i);
				if(setCats.contains(categoria))
					continue;
				
				//Vamos inicializar a categoria para todos os usuarios 
				for(int j=0; j< listaParaRankingDeRating.size(); j++){
					DadosUsuario du = listaParaRankingDeRating.get(j);
					du.getMapInfoRankingPorCategoria().put(categoria, new DadosRatingCategoria(categoria));
				}
				
				String query = ConsultasBD.consultaNroDeRespostasQueForamAceitasPorCat(categoria);
				ResultSet rs = cbd.executaQuery(query);
				while(rs.next()){
					String userId = rs.getString("idUser");
					int nroDeRespostasAceitas = rs.getInt("nroRespostasQueForamAceitasPorUsuario");
					DadosUsuario du = mapParaRankingDeRating.get(userId);
					if(du ==null)
						continue;
					DadosRatingCategoria drc = du.getMapInfoRankingPorCategoria().get(categoria);
					drc.setNroDeRespostasAceitas(nroDeRespostasAceitas);
				}
				
				query = ConsultasBD.consultaNroDeUpvotesEmPerguntaPorCat(categoria);
				rs = cbd.executaQuery(query);
				while(rs.next()){
					String userId = rs.getString("idUser");
					int nroUpvotesPorUsuario = rs.getInt("nroUpvotesPorUsuario");
					DadosUsuario du = mapParaRankingDeRating.get(userId);
					if(du ==null)
						continue;
					DadosRatingCategoria drc = du.getMapInfoRankingPorCategoria().get(categoria);
					if(drc == null){
						int a =0;
						int b=a;
					}
					
					drc.setNroDeUpvotesEmSuasPerguntas(nroUpvotesPorUsuario);
				}
				
				query = ConsultasBD.consultaNroDeUpvotesEmRespostasPorCat(categoria);
				rs = cbd.executaQuery(query);
				while(rs.next()){
					String userId = rs.getString("idUser");
					int nroUpvotesPorUsuario = rs.getInt("nroUpvotesPorUsuario");
					DadosUsuario du = mapParaRankingDeRating.get(userId);
					if(du ==null)
						continue;
					DadosRatingCategoria drc = du.getMapInfoRankingPorCategoria().get(categoria);
					drc.setNroDeUpvotesEmSuasRespostas(nroUpvotesPorUsuario);
				}
				
				query = ConsultasBD.consultaNroDeDownvotesEmPerguntasPorCat(categoria);
				rs = cbd.executaQuery(query);
				while(rs.next()){
					String userId = rs.getString("idUser");
					int nroDownvotesPorUsuario = rs.getInt("nroDownvotesPorUsuario");
					DadosUsuario du = mapParaRankingDeRating.get(userId);
					if(du ==null)
						continue;
					DadosRatingCategoria drc = du.getMapInfoRankingPorCategoria().get(categoria);
					drc.setNroDeDownvotesEmSuasPerguntas(nroDownvotesPorUsuario);
				}
				
				query = ConsultasBD.consultaNroDeDownvotesEmRespostasPorCat(categoria);
				rs = cbd.executaQuery(query);
				while(rs.next()){
					String userId = rs.getString("idUser");
					int nroDownvotesPorUsuario = rs.getInt("nroDownvotesPorUsuario");
					DadosUsuario du = mapParaRankingDeRating.get(userId);
					if(du ==null)
						continue;
					DadosRatingCategoria drc = du.getMapInfoRankingPorCategoria().get(categoria);
					drc.setNroDeDownvotesEmSuasRespostas(nroDownvotesPorUsuario);
				}
				
				System.out.println(listaParaRankingDeRating.size());
				for(int j=0; j< listaParaRankingDeRating.size(); j++){
					//System.out.println(i);
					DadosRatingCategoria drc = listaParaRankingDeRating.get(j).getMapInfoRankingPorCategoria().get(categoria);
					
					drc.setRatingRecebidoPorResponder(15*drc.getNroDeRespostasAceitas() + 10*drc.getNroDeUpvotesEmSuasRespostas() -2*drc.getNroDeDownvotesEmSuasRespostas());
					drc.setRatingRecebidoPorPerguntar(5*drc.getNroDeUpvotesEmSuasPerguntas() -2*drc.getNroDeDownvotesEmSuasPerguntas());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
			
			
			
		
		
		
	}*/

	private  void determinaOrdenacaoPorRatingDeRespostas(List<DadosUsuario> listaParaRankingDeRating) {
		int ratingAnterior = -1;
		int posicaoNoRanking = 0;
		for(int i=0; i<listaParaRankingDeRating.size(); i++){
			DadosUsuario du = listaParaRankingDeRating.get(i);
			int ratingPorResponder = du.getRatingRecebidoPorResponder();
			if(ratingPorResponder != ratingAnterior)
				posicaoNoRanking++;
			du.setPosicaoNoRankingDeRatingDeRespostas(posicaoNoRanking);
			ratingAnterior = ratingPorResponder;
		}
	}
	
	private  void determinaOrdenacaoPorRatingDePerguntas(List<DadosUsuario> listaParaRankingDeRating) {
		int ratingAnterior = -1;
		int posicaoNoRanking = 0;
		for(int i=0; i<listaParaRankingDeRating.size(); i++){
			DadosUsuario du = listaParaRankingDeRating.get(i);
			int ratingPorPerguntar = du.getRatingRecebidoPorPerguntar();
			if(ratingPorPerguntar != ratingAnterior)
				posicaoNoRanking++;
			du.setPosicaoNoRankingDeRatingDePerguntas(posicaoNoRanking);
			ratingAnterior = ratingPorPerguntar;
		}
	}

	private  void inicializaMapEListaParaRankingDeRating(Map<String, DadosUsuario> mapParaRankingDeRating, List<DadosUsuario> listaParaRankingDeRating, List<String> listaIdUsers) {
		
		for(int i=0; i< listaIdUsers.size(); i++){
			int idUsuario = Integer.parseInt(listaIdUsers.get(i));
			DadosUsuario du = new DadosUsuario(idUsuario);
			mapParaRankingDeRating.put(idUsuario+"", du);
			listaParaRankingDeRating.add(du);
		}
		
	}

	private  void preencheMapParaRankingDeRating(Map<String, DadosUsuario> mapParaRankingDeRating, List<DadosUsuario> listaParaRankingDeRating) {
		try{
			String query = ConsultasBD.consultaNroDeRespostasQueForamAceitasGeral();
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				String userId = rs.getString("idUser");
				int nroDeRespostasAceitas = rs.getInt("nroRespostasQueForamAceitasPorUsuario");
				DadosUsuario du = mapParaRankingDeRating.get(userId);
				if(du ==null)
					continue;
				du.setNroDeRespostasAceitas(nroDeRespostasAceitas);
			}
			
			query = ConsultasBD.consultaNroDeUpvotesEmPerguntaGeral();
			rs = cbd.executaQuery(query);
			while(rs.next()){
				String userId = rs.getString("idUser");
				int nroUpvotesPorUsuario = rs.getInt("nroUpvotesPorUsuario");
				DadosUsuario du = mapParaRankingDeRating.get(userId);
				if(du ==null)
					continue;
				du.setNroDeUpvotesEmSuasPerguntas(nroUpvotesPorUsuario);
			}
			
			query = ConsultasBD.consultaNroDeUpvotesEmRespostasGeral();
			rs = cbd.executaQuery(query);
			while(rs.next()){
				String userId = rs.getString("idUser");
				int nroUpvotesPorUsuario = rs.getInt("nroUpvotesPorUsuario");
				DadosUsuario du = mapParaRankingDeRating.get(userId);
				if(du ==null)
					continue;
				du.setNroDeUpvotesEmSuasRespostas(nroUpvotesPorUsuario);
			}
			
			query = ConsultasBD.consultaNroDeDownvotesEmPerguntasGeral();
			rs = cbd.executaQuery(query);
			while(rs.next()){
				String userId = rs.getString("idUser");
				int nroDownvotesPorUsuario = rs.getInt("nroDownvotesPorUsuario");
				DadosUsuario du = mapParaRankingDeRating.get(userId);
				if(du ==null)
					continue;
				du.setNroDeDownvotesEmSuasPerguntas(nroDownvotesPorUsuario);
			}
			
			query = ConsultasBD.consultaNroDeDownvotesEmRespostasGeral();
			rs = cbd.executaQuery(query);
			while(rs.next()){
				String userId = rs.getString("idUser");
				int nroDownvotesPorUsuario = rs.getInt("nroDownvotesPorUsuario");
				DadosUsuario du = mapParaRankingDeRating.get(userId);
				if(du ==null)
					continue;
				du.setNroDeDownvotesEmSuasRespostas(nroDownvotesPorUsuario);
			}
			
			System.out.println(listaParaRankingDeRating.size());
			for(int i=0; i< listaParaRankingDeRating.size(); i++){
				//System.out.println(i);
				DadosUsuario du = listaParaRankingDeRating.get(i);
				
				du.setRatingRecebidoPorResponder(15*du.getNroDeRespostasAceitas() + 10*du.getNroDeUpvotesEmSuasRespostas() -2*du.getNroDeDownvotesEmSuasRespostas());
				du.setRatingRecebidoPorPerguntar(5*du.getNroDeUpvotesEmSuasPerguntas() -2*du.getNroDeDownvotesEmSuasPerguntas());
			}
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	private  List<String> recuperaTodosUsuarios() {
		List<String> listaIdUsuarios = new ArrayList<String>();
		try{
			String query = ConsultasBD.consultaIdUsuarios();
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				String idUsuario = rs.getString("id");
				listaIdUsuarios.add(idUsuario);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaIdUsuarios;
	}

	private  int calculaReputacaoRecebidaPorResponder(int idAnswerer) {
		try{
			//+15 por resposta aceita
			//Primeiro vamos calcular a reputacao gerada porque suas respostas foram aceitas
			String query = ConsultasBD.consultaNroDeRespostasDeUsuarioQueForamAceitas(idAnswerer);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroRespostasQueForamAceitas = rs.getInt("nroRespostasQueForamAceitas");
			
			//+10 por upvote, -2 por downvote em suas perguntas
			//Vamos calcular o nro de upvotes e downvotes em perguntas feitas pelo usuario
			query = ConsultasBD.consultaNroDeUpvotesEmRespostasDeUsuario(idAnswerer);
			rs = cbd.executaQuery(query);
			rs.next();
			int nroDeUpVotesEmRespostasDoUsuario = rs.getInt("nroUpvotes");
			
			query = ConsultasBD.consultaNroDeDownvotesEmRespostasDeUsuario(idAnswerer);
			rs = cbd.executaQuery(query);
			rs.next();
			int nroDeDownVotesEmRespostasDoUsuario = rs.getInt("nroDownvotes");
			
			return 15*nroRespostasQueForamAceitas + 10*nroDeUpVotesEmRespostasDoUsuario -2*nroDeDownVotesEmRespostasDoUsuario;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaReputacaoRecebidaPorPerguntar(int idAnswerer) {
		try{
			//Reputacao recebida por fazer perguntas = +5 por upvote, -2 por downvote em suas perguntas
			//Vamos calcular o nro de upvotes e downvotes em perguntas feitas pelo usuario
			String query = ConsultasBD.consultaNroDeUpvotesEmPerguntasDeUsuario(idAnswerer);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroDeUpVotesEmRespostasDoUsuario = rs.getInt("nroUpvotes");
			
			query = ConsultasBD.consultaNroDeDownvotesEmPerguntasDeUsuario(idAnswerer);
			rs = cbd.executaQuery(query);
			rs.next();
			int nroDeDownVotesEmRespostasDoUsuario = rs.getInt("nroDownvotes");
			
			return 5*nroDeUpVotesEmRespostasDoUsuario -2*nroDeDownVotesEmRespostasDoUsuario;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  List<Integer> calculaListaComPosicoesNosRankings(int idAnswerer, List<String> listaCategorias, Map<String, Map<String, Integer>> mapRanking, Map<String, Integer> mapUltimaPosicaoRankingPorCat) {
		List<Integer> listaPosicoesRanking = new ArrayList<Integer>();
		for(int i=0; i< listaCategorias.size(); i++){
			String categoria = listaCategorias.get(i);
			int posicao = mapUltimaPosicaoRankingPorCat.get(categoria) + 1;
			if(mapRanking.get(categoria).containsKey(idAnswerer+""))
				posicao = mapRanking.get(categoria).get(idAnswerer+"");
			listaPosicoesRanking.add(posicao);
		}
		return listaPosicoesRanking;
	}

	private  List<Integer> calculaNroDeRespostasPostadasPorCategoria(List<String> listaCategorias, int idAnswerer) {
		List<Integer> listaNroDeRespostasPostadasPorCategoria = new ArrayList<Integer>();
		try{
			for(int i=0; i< listaCategorias.size(); i++){
				String query = ConsultasBD.consultaNroDeRespostasPostadasPorCategoria(idAnswerer, listaCategorias.get(i));
				ResultSet rs = cbd.executaQuery(query);
				rs.next();
				int nroRespostas = rs.getInt("nroRespostas");
				listaNroDeRespostasPostadasPorCategoria.add(nroRespostas);
			}
			return listaNroDeRespostasPostadasPorCategoria;
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaNroDeRespostasPostadasPorCategoria;
	}

	private  List<Integer> calculaNroDePerguntasPostadasPorCategoria(List<String> listaCategorias, int idAnswerer) {
		List<Integer> listaNroDePerguntasPostadasPorCategoria = new ArrayList<Integer>();
		try{
			for(int i=0; i< listaCategorias.size(); i++){
				String query = ConsultasBD.consultaNroDePerguntasPostadasPorCategoria(idAnswerer, listaCategorias.get(i));
				ResultSet rs = cbd.executaQuery(query);
				rs.next();
				int nroPerguntas = rs.getInt("nroPerguntas");
				listaNroDePerguntasPostadasPorCategoria.add(nroPerguntas);
				
			}
			return listaNroDePerguntasPostadasPorCategoria;
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaNroDePerguntasPostadasPorCategoria;
	}

	private  List<String> descobreCategoriasDaPergunta(int idPergunta) {
		List<String> listaCategoriasDaPergunta = new ArrayList<String>();
		try{
			String query = ConsultasBD.consultaCategoriasDaPergunta(idPergunta);
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				String categoria = rs.getString("tagid");
				listaCategoriasDaPergunta.add(categoria);
			}
			return listaCategoriasDaPergunta;
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaCategoriasDaPergunta;
	}

	private  List<Integer> encontraNroDeRespostasPorPergunta(int idAnswerer) {
		List<Integer> listaNroRespostasPorPergunta = new ArrayList<Integer>();
		try{
			String query = ConsultasBD.consultaNroDeRespostasPorPergunta(idAnswerer);
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				int nroRespostas = rs.getInt("nroRespostas");
				listaNroRespostasPorPergunta.add(nroRespostas);
			}
			return listaNroRespostasPorPergunta;
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaNroRespostasPorPergunta;
	}

	private  List<Integer> encontraNroDeComentariosPorPergunta(int idAnswerer) {
		List<Integer> listaNroComentariosPorPergunta = new ArrayList<Integer>();
		try{
			String query = ConsultasBD.consultaNroDeComentariosPorPergunta(idAnswerer);
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				int nroComentarios = rs.getInt("nroComentarios");
				listaNroComentariosPorPergunta.add(nroComentarios);
			}
			return listaNroComentariosPorPergunta;
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaNroComentariosPorPergunta;
	}
	
	private  List<Integer> encontraNroDeComentariosPorResposta(int idAnswerer) {
		List<Integer> listaNroComentariosPorResposta = new ArrayList<Integer>();
		try{
			String query = ConsultasBD.consultaNroDeComentariosPorResposta(idAnswerer);
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				int nroComentarios = rs.getInt("nroComentarios");
				listaNroComentariosPorResposta.add(nroComentarios);
			}
			return listaNroComentariosPorResposta;
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaNroComentariosPorResposta;
	}

	private  int calculaNroDeLinksExternos(List<String> listaUrlLinks) {
		int nroLinksExternos = 0;
		for(int i=0; i< listaUrlLinks.size(); i++){
			if(!listaUrlLinks.get(i).contains("stackoverflow.com"))
				nroLinksExternos++;
		}
		return nroLinksExternos;
	}

	private  List<String> encontraLinks(String corpoPost) {
		List<String> listUrlLinks = new ArrayList<String>();
		try{
			HtmlCleaner cleaner = new HtmlCleaner();
			TagNode root = cleaner.clean( corpoPost );
			
			Object[] QuotedBlocksNodes = root.evaluateXPath( "//a" );
			for(int i=0; i<QuotedBlocksNodes.length; i++){
				String url = "";
				url += ((TagNode)QuotedBlocksNodes[i]).getAttributeByName("href");
				listUrlLinks.add(url);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return listUrlLinks;
	}

	private  List<Integer> calculaListaTamanhoQuotedBlocks(String corpoPost, ManipuladorDeTexto mt) {
		List<Integer> listTamanhoCodigos = new ArrayList<Integer>();
		try{
			HtmlCleaner cleaner = new HtmlCleaner();
			TagNode root = cleaner.clean( corpoPost );
			
			Object[] QuotedBlocksNodes = root.evaluateXPath( "//blockquote" );
			for(int i=0; i<QuotedBlocksNodes.length; i++){
				String textoCodigo = "";
				textoCodigo += ((TagNode)QuotedBlocksNodes[i]).getText();
				int nroTokens = mt.recuperaTokens(textoCodigo).size();
				listTamanhoCodigos.add(nroTokens);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return listTamanhoCodigos;
	}

	private  List<Integer> calculaListaTamanhoSnippets(String corpoPost) {
		List<Integer> listTamanhoCodigos = new ArrayList<Integer>();
		try{
			HtmlCleaner cleaner = new HtmlCleaner();
			TagNode root = cleaner.clean( corpoPost );
			
			Object[] codeNodes = root.evaluateXPath( "//pre/code" );
			for(int i=0; i<codeNodes.length; i++){
				String textoCodigo = "";
				textoCodigo += ((TagNode)codeNodes[i]).getText();
				String[] lines = textoCodigo.split("\r\n|\r|\n");
				listTamanhoCodigos.add(lines.length);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return listTamanhoCodigos;
	}

	public  int calculaNroDeOcorrenciasDeTag(String nomeTag, String corpoPost){
		try{
			HtmlCleaner cleaner = new HtmlCleaner();
			TagNode root = cleaner.clean( corpoPost );
			
			Object[] nodes = root.evaluateXPath( "//" + nomeTag);
			return nodes.length;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
	
	private  int calculaNroDeUsuariosQueComentaramPost(int idPost) {
		try{
			String query = ConsultasBD.consultaNroDeUsuariosQuemComentaramPost(idPost);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroUsuarios = rs.getInt("nroUsuarios");
			return nroUsuarios;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDeComentariosDoPost(int idPost) {
		try{
			String query = ConsultasBD.consultaNroDeComentariosDoPost(idPost);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroComentarios = rs.getInt("nroComentarios");
			return nroComentarios;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDeRespostasPostadasAPergunta(int idPergunta) {
		try{
			String query = ConsultasBD.consultaNroDeRespostasPostadasAPergunta(idPergunta);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroRespostas = rs.getInt("nroRespostas");
			return nroRespostas;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDeRespostasPostadasAntesDaResposta(int idPergunta, int idResposta) {
		try{
			String query = ConsultasBD.consultaNroDeRespostasPostadasAntes(idPergunta, idResposta);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroPerguntas = rs.getInt("nroRespostas");
			return nroPerguntas;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  List<Integer> calculaListaNroDeEdicoesPorUsuarioNaPergunta(int idPergunta) {
		try{
			List<Integer> listaNroEdicoes = new ArrayList<Integer>();
			String query = ConsultasBD.consultaNroDeEdicoesPorUsuarioNaPergunta(idPergunta);
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				int nroEdicoes = rs.getInt("nroEdicoesUser");
				listaNroEdicoes.add(nroEdicoes);
			}
			return listaNroEdicoes;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	private  List<Integer> calculaListaNroDeEdicoesPorUsuarioNaResposta(int idResposta) {
		try{
			List<Integer> listaNroEdicoes = new ArrayList<Integer>();
			String query = ConsultasBD.consultaNroDeEdicoesPorUsuarioNaResposta(idResposta);
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				int nroEdicoes = rs.getInt("nroEdicoesUser");
				listaNroEdicoes.add(nroEdicoes);
			}
			return listaNroEdicoes;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}

	private  int calculaNroDeUsuariosQueEditaramAPergunta(int idPergunta) {
		try{
			String query = ConsultasBD.consultaNroUsuariosQueEditaramAPergunta(idPergunta);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int idade = rs.getInt("nroUsers");
			return idade;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
	
	private  int calculaNroDeUsuariosQueEditaramAReposta(int idResposta) {
		try{
			String query = ConsultasBD.consultaNroUsuariosQueEditaramAResposta(idResposta);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int idade = rs.getInt("nroUsers");
			return idade;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaIdadePost(int idPost) {
		try{
			String query = ConsultasBD.consultaIdadePost(idPost);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int idade = rs.getInt("idade");
			return idade;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroEdicoesNaResposta(int idResposta) {
		try{
			String query = ConsultasBD.consultaNroEdicoesNaResposta(idResposta);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroEdicoes = rs.getInt("nroEdicoesNAResposta");
			return nroEdicoes;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  void preencheMapDadosUsuariosERanking(Map<String, DadosUsuario> mapDadosUsuario, List<String> listaTags, Map<String, Map<String, Integer>> mapRankingDeAnsweresPorCategoria, Map<String, Map<String, Integer>> mapRankingDeAskersPorCategoria, Map<String, Integer> mapUltimaPosicaoRankingDeRespostasPorCat, Map<String, Integer> mapUltimaPosicaoRankingDePerguntasPorCat) {
		try{
			String selectTopAnswerers = "SELECT pa.owneruserid idUser, COUNT(*) contagem " +
			"FROM tags_new t INNER JOIN posts pa ON t.postid = pa.parentid " +
			"WHERE t.tagid = ? AND pa.owneruserid IS NOT NULL " +
			"GROUP BY pa.owneruserid " +
			"ORDER BY contagem DESC";
			PreparedStatement statementTop3Answerers = cbd.criaPreparedStatement(selectTopAnswerers);
			
			String selectTopAskers = "SELECT pq.owneruserid idUser, COUNT(*) contagem " +
			"FROM tags_new t INNER JOIN posts pq ON t.postid = pq.id " +
			"WHERE t.tagid = ? AND pq.owneruserid IS NOT NULL " +
			"GROUP BY pq.owneruserid " +
			"ORDER BY contagem DESC";
			PreparedStatement statementTop3Askers = cbd.criaPreparedStatement(selectTopAskers);
			long startTime = System.currentTimeMillis();
			for(int i=0; i< listaTags.size(); i++){
				//Calculando os top3 answeres de cada cat e montando o ranking completo de answerers para a categoria
				
				String categoria = listaTags.get(i);
				//System.out.println(i);
				statementTop3Answerers.setString(1, categoria);
				ResultSet rs = statementTop3Answerers.executeQuery();
				//System.out.println("Descobrindo top3 answerers");
				
				Map<String, Integer> mapRankingAsweresParaCategoriaEmQuestao = new HashMap<String, Integer>();
				mapRankingDeAnsweresPorCategoria.put(categoria, mapRankingAsweresParaCategoriaEmQuestao);
				
 				Map<String, Integer> mapRankingAskersParaCategoriaEmQuestao = new HashMap<String, Integer>();
				mapRankingDeAskersPorCategoria.put(categoria, mapRankingAskersParaCategoriaEmQuestao);
				
				int posicao = 0;
				int nroDeRespostasAnterior = -1;
				while(rs.next()){
					//Se for TOP 3 para a categoria, atualizamos a informacoes no map de usuario
					int idUser = Integer.parseInt(rs.getString("idUser"));
					int nroDeRespostas = Integer.parseInt(rs.getString("contagem"));
					
					if(nroDeRespostas != nroDeRespostasAnterior)
						posicao++;
					
					if(posicao <= 3){
						DadosUsuario du = mapDadosUsuario.get(idUser+"");
						if(du == null)
							continue;
						du.getCategoriasEmQueEhTop3Answerer().add(categoria);
					}
					nroDeRespostasAnterior = nroDeRespostas;
					mapRankingAsweresParaCategoriaEmQuestao.put(idUser+"", posicao);
				}
				mapUltimaPosicaoRankingDeRespostasPorCat.put(categoria, posicao);
				
				posicao = 0;
				int nroDePerguntasAnterior = -1;
				statementTop3Askers.setString(1, listaTags.get(i));
				rs = statementTop3Askers.executeQuery();
				//System.out.println("Descobrindo top3 askers");
				while(rs.next()){
					int idUser = Integer.parseInt(rs.getString("idUser"));
					int nroDePerguntas = Integer.parseInt(rs.getString("contagem"));
					
					if(nroDePerguntas != nroDePerguntasAnterior)
						posicao++;
					
					if(posicao <= 3){
						DadosUsuario du = mapDadosUsuario.get(idUser+"");
						if(du == null)
							continue;
						du.getCategoriasEmQueEhTop3Asker().add(categoria);
					}
					nroDePerguntasAnterior = nroDePerguntas;
					mapRankingAskersParaCategoriaEmQuestao.put(idUser+"", posicao);
				}
				mapUltimaPosicaoRankingDePerguntasPorCat.put(categoria, posicao);
			}
			
			//long stopTime = System.currentTimeMillis();
			//long elapsedTime = stopTime - startTime;
		    // System.out.println(elapsedTime);
		  
			//Calculando os numro de categorias em que um usuario ja respondeu
			String query = ConsultasBD.consultaNumeroDeCategoriasRepondidasPorUsuarios();
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				int idUser = Integer.parseInt(rs.getString("idUser"));
				int nroCats = rs.getInt("nroCats");
				DadosUsuario du = mapDadosUsuario.get(idUser+"");
				if(du == null)
					continue;
				du.setNroDeCategoriasQueJaRespondeu(nroCats);
			}
			
			//Calculando os numro de categorias em que um usuario ja perguntou
			query = ConsultasBD.consultaNumeroDeCategoriasPerguntadasPorUsuarios();
			rs = cbd.executaQuery(query);
			while(rs.next()){
				int idUser = Integer.parseInt(rs.getString("idUser"));
				int nroCats = rs.getInt("nroCats");
				DadosUsuario du = mapDadosUsuario.get(idUser+"");
				if(du == null)
					continue;
				du.setNroDeCategoriasQueJaPreguntou(nroCats);
			}	
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	private  List<String> descobreTodasTags() {
		List<String> listaTags = new ArrayList<String>();
		try{
			String query = ConsultasBD.consultaTagsDosPosts();
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				String tag = rs.getString("tagid");
				listaTags.add(tag);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaTags;
	}

	private  int calculaRankingRespostas(Map<Integer, Integer> mapRankingAnswerers) {
		try{
			String query = ConsultasBD.consultaRankingRespostas();
			ResultSet rs = cbd.executaQuery(query);
			int contadorPosicao = 0;
			int contagemAnterior = -1;
			while(rs.next()){
				int idUsuario = Integer.parseInt(rs.getString("idUser"));
				int contagem = Integer.parseInt(rs.getString("contagem"));
				if(contagem != contagemAnterior)
					contadorPosicao++;
				contagemAnterior = contagem;
				mapRankingAnswerers.put(idUsuario, contadorPosicao);
			}
			return contadorPosicao;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaRankingPerguntas(Map<Integer, Integer> mapRankingAskers) {
		try{
			String query = ConsultasBD.consultaRankingPerguntas();
			ResultSet rs = cbd.executaQuery(query);
			int contadorPosicao = 0;
			int contagemAnterior = -1;
			while(rs.next()){
				int idUsuario = Integer.parseInt(rs.getString("idUser"));
				int contagem = Integer.parseInt(rs.getString("contagem"));
				if(contagem != contagemAnterior)
					contadorPosicao++;
				contagemAnterior = contagem;				
				mapRankingAskers.put(idUsuario, contadorPosicao);
				
			}
			return contadorPosicao;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDePerguntasPostadasQueForamResolvidas(int idUser) {
		try{
			String query = ConsultasBD.consultaNroDePerguntasPostadasComRespostaAceita(idUser);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			return Integer.parseInt(rs.getString("nroPerguntasPostadasComRespostaAceita"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDePerguntasPostadas(int idUser) {
		try{
			String query = ConsultasBD.consultaNroDePerguntasPostadas(idUser);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			return Integer.parseInt(rs.getString("nroPerguntasPostadas"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDeRespostasPostadas(int idUser) {
		try{
			String query = ConsultasBD.consultaNroDeRespostasPostadas(idUser);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			return Integer.parseInt(rs.getString("nroRespostasPostadas"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDeEdtisFeitosEmPerguntas(int idUser) {
		try{
			String query = ConsultasBD.consultaNroDeEdicoesAPerguntas(idUser);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			return Integer.parseInt(rs.getString("nroEdicoesAPerguntas"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
	
	private  int calculaNroDeEdtisFeitosEmRespostas(int idUser) {
		try{
			String query = ConsultasBD.consultaNroDeEdicoesARespostas(idUser);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			return Integer.parseInt(rs.getString("nroEdicoesARespostas"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDeComentariosPostadosPorUsuario(int idUser) {
		try{
			String query = ConsultasBD.consultaNroTotalDeComentarios(idUser);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			return Integer.parseInt(rs.getString("nroComentarios"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDeBadges(int idUser) {
		try{
			String query = ConsultasBD.consultaNroDeBadges(idUser);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			return Integer.parseInt(rs.getString("nroBadges"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private  int calculaNroDeDiasDesdeORegistro(int idUser){
		try{
			String query = ConsultasBD.consultaNroDeDiasDesdeORegistro(idUser);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			return Integer.parseInt(rs.getString("tempo"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
	
	private  int calculaNroDeDiasDesdeOUltimoAcesso(int idUser){
		try{
			String query = ConsultasBD.consultaNroDeDiasDesdeOUltimoAcesso(idUser);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			return Integer.parseInt(rs.getString("tempo"));
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
	
	private  int calculaNroDeSSCCEEmComentariosDePost(int idPost, ManipuladorDeTexto mt) {
		int nroDeSSCEE = 0;
		try{
			//ConexaoDB cbd = new ConexaoDB();
			//cbd.conectaAoBD();
			String query = ConsultasBD.consultaComentarios(idPost);
			int tamanhoCodigo = 0;
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				String comentario = rs.getString("comentario");
				List<String> listaTokens = mt.recuperaTokens(comentario);
				for(int i=0; i< listaTokens.size(); i++){
					if(listaTokens.get(i).equals("sscce"))
						nroDeSSCEE++;
				}
				
				/*String textoCodigos = mt.getCodigoPreCode(corpo).toLowerCase();
				int nroDeSnippets = mt.getNumeroDeTrechosDeSocigo(corpo);
				String[] lines = textoCodigos.split("\r\n|\r|\n");
				tamanhoCodigo = 0;
				if(!textoCodigos.equals("")){
					tamanhoCodigo = lines.length;
					return tamanhoCodigo;
				}*/
		}
			//fecha a conexao com o BD
			//cbd.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return nroDeSSCEE;
	}

	/* 
	 * Metodo responsavel por calcular o numero de linhas de codigo presente num post (incluindo linhas em branco e cometarios)
	 */
	private  int calculaNumeroDeLinhasDeCodigo(int idPost) {
		try{
			ManipuladorDeTexto mt = new ManipuladorDeTexto("", false);
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();
			String query = ConsultasBD.consultaCorpo(idPost);
			int tamanhoCodigo = 0;
			ResultSet rs = cbd.executaQuery(query);
			if(rs.next()){
				String corpo = rs.getString("body");
				String textoCodigos = mt.getCodigoPreCode(corpo).toLowerCase();
				int nroDeSnippets = mt.getNumeroDeTrechosDeCodigo(corpo);
				String[] lines = textoCodigos.split("\r\n|\r|\n");
				tamanhoCodigo = 0;
				if(!textoCodigos.equals("")){
					tamanhoCodigo = lines.length;
					return tamanhoCodigo;
				}
		}
			//fecha a conexao com o BD
			cbd.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return 0;
	}

	/* 
	 * Metodo responsavel por verificar a presença de codigo (tags <pre><code> em sequencia) em post
	 */
	private  boolean verificaPresencaDeCodigo(int idPost) {
		try{
			ManipuladorDeTexto mt = new ManipuladorDeTexto("", false);
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();
			String query = ConsultasBD.consultaCorpo(idPost);
			ResultSet rs = cbd.executaQuery(query);
			if(rs.next()){
				String corpo = rs.getString("body");
				int nroTrechosDeCodigo = mt.getNumeroDeTrechosDeCodigo(corpo);
				return nroTrechosDeCodigo > 0;
			}
			//fecha a conexao com o BD
			cbd.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return false;
	}

	/* 
	 * Metodo responsavel por encontrar o fovoriteCount de um post pergunta
	 */
	private  int recuperaFavoriteCount(int idPost) {
		try{
			
			//:TODO Comentar nos outros metodos
			//ConexaoDB cbd = new ConexaoDB();
			//cbd.conectaAoBD();
			String query = ConsultasBD.consultaFavoriteCount(idPost);
			ResultSet rs = cbd.executaQuery(query);
			if(rs.next()){
				String favoriteCountStr = rs.getString("favoriteCount");
				if(favoriteCountStr == null)
					return 0;
				else 
					return Integer.parseInt(favoriteCountStr); 
			}
			//fecha a conexao com o BD
			//cbd.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return 0;
	}

	/* 
	 * Metodo responsavel por encontrar o score de um post pergunta
	 */
	private  int recuperaScore(int idPost) {
		try{
			//ConexaoDB cbd = new ConexaoDB();
			//cbd.conectaAoBD();
			String query = ConsultasBD.consultaScore(idPost);
			ResultSet rs = cbd.executaQuery(query);
			if(rs.next()){
				int score = Integer.parseInt(rs.getString("score"));
				return score; 
			}
			//fecha a conexao com o BD
			//cbd.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return 0;
	}

	/* 
	 * Metodo responsavel por encontrar o numero de tokens no texto (LN) em um post
	 */
	private  int encontraNroDeTokensNoPost(int idPost) {
		List<String> listaTokens = null;
		try{
			ManipuladorDeTexto mt = new ManipuladorDeTexto("", true);
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();
			String query = ConsultasBD.consultaCorpo(idPost);
			ResultSet rs = cbd.executaQuery(query);
			if(rs.next()){
				String corpo = rs.getString("body");
				String corpoTratado = mt.removeTagsIndesejadas(corpo, false);
				listaTokens = mt.recuperaTokens(corpoTratado);
				
			}else
				System.out.println("ID inválido de post");
			
			//fecha a conexao com o BD
			cbd.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaTokens.size();
	}

	/* 
	 * Metodo responsavel por verificar se uma pergunta foi editda por usuario com alta reputacao (>=1000)
	 * sendo este usuario diferente do asker
	 */
	private  boolean verificaPerguntaEditadaPorUsuarioComAltaReputaca(int idPergunta, int thresholdReputacao) {
		try{
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();
			String query = ConsultasBD.consultaVerificaPerguntasEditadasPorUsuarioComAltaReputacao(idPergunta, thresholdReputacao);
			ResultSet rs = cbd.executaQuery(query);
			if(rs.next()){
				int count = Integer.parseInt(rs.getString("contador"));
				if(count > 0)
					return true;
			}
			//fecha a conexao com o BD
			cbd.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return false;
	}
	
	private  double calculaMedia(List<Integer> values){
		if(values.isEmpty())
			return 0;
		
		double sum=0;
		for(int i=0; i< values.size(); i++){
			sum += values.get(i);
		}
		return sum/(double)values.size();
	}
	
	private  double calculaDesvioPadrao(List<Integer> lista, double mean){
		if(lista.isEmpty())
			return 0;
		
		double sum = 0;
		for(int i=0; i< lista.size(); i++){
			sum += Math.pow( lista.get(i) - mean , 2);
		}
		return Math.sqrt(sum/lista.size());

	}
	
	private  double calculaMin(List<Integer> values){
		if(values.isEmpty())
			return 0;
		double min = values.get(0);
		for(int i=1; i< values.size(); i++){
			if(values.get(i) < min)
				min = values.get(i);
		}
		return min;	
	}
	
	private  double calculaMax(List<Integer> values){
		if(values.isEmpty())
			return 0;
		double max = values.get(0);
		for(int i=1; i< values.size(); i++){
			if(values.get(i) > max)
				max = values.get(i);
		}
		return max;	
	}
	
	private  double calculaMedia(List<Integer> lista, int nroRespostasPostadas) {
		if(nroRespostasPostadas == 0)
			return 0;
		
		double sum=0;
		for(int i=0; i< lista.size(); i++){
			sum += lista.get(i);
		}
		return sum/(double)nroRespostasPostadas;
	}
	
	
}

