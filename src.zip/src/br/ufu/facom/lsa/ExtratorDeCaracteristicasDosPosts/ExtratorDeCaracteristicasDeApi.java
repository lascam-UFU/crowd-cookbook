//Deve ser executado uma vez para cada API

/* Possivies Pendencias existentes na implementacao das features
 *1- calculo de entropia, quando tem um vetor apeans com 0`s o calculo da entropia da 1
 *2- Consideracoes acerca dos ranking: usuarios que nao estao nos rankings sao considerados estarem atras do uiltmo do ranking (que geralmente possui score negativo) 
 *3- Metricas score total obtido por perguntar ou responder nas categorias de T: o autor falou que se trata de soma do score se cada categoria, mas para mim o certo seria fazer select 
 * */

package br.ufu.facom.lsa.ExtratorDeCaracteristicasDosPosts;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.io.FileUtils;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;
import br.ufu.facom.lsa.TesteHowTo.ClassificadorHowTo;

public class ExtratorDeCaracteristicasDeApi {
	
	private ConexaoDB cbd;
	private ClassificadorHowTo classificador;
	
	public ExtratorDeCaracteristicasDeApi(){
		try{
			cbd = new ConexaoDB();
			 //Conecta ao banco
			cbd.conectaAoBD();	
			
			classificador = new ClassificadorHowTo();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void calculaFeaturesParaApi(boolean ehPrimeiraVez, String vetAPIs[], int nroMaxDeParesConsiderados){
		try{
			
			//Variavel boolena que indica que se eh a primeira vez ira executar a classe  ExtratorDeCaracteristicasDePosts
			//boolean ehPrimeiraVez = false;
			//Variavel que indica se a entropia devera ser normalizada
			boolean normalizaEntropa = true;
			//Caminho do arquivo que associa a cada nome de API um id numerico
			String caminhoArquivoIdCategoria = "/home/lucas/Dropbox/mapeamentoIdsCategorias.txt";
			ExtratorDeCaracteristicasDePar ec = new ExtratorDeCaracteristicasDePar(caminhoArquivoIdCategoria, ehPrimeiraVez, normalizaEntropa);
						
			//int nroDeParesParaBaseline = 1000;
			int nroDeParesProcessados = 0;
			int nroDeThreadsJaProcessadas = 0;
			
			String nomeAPIs = "";
			
			for(int i=0; i< vetAPIs.length; i++){
				nomeAPIs += vetAPIs[i];
				if(i!=vetAPIs.length-1){
					nomeAPIs += "_";
				}
			}
			
			System.out.println("API: " + nomeAPIs);
			
			//Arquivo onde serao armazenados os resultados das features 
			String caminhoArquivoResultadosFeatures = "/home/lucas/Dropbox/resultadosFeatures/" + nomeAPIs + ".txt";
			//Cria o arquivo onde serao colocados os resultados da extrecao de features
			PrintWriter outFileFeatures = new PrintWriter(new BufferedWriter(new FileWriter(caminhoArquivoResultadosFeatures, false)));
			//Cria a pasta onde serao colocados o arquivos respresentando os pares de Q&A
			//(new File("/home/lucas/Dropbox/pares Q&A/" + nomeAPIs)).mkdir();
			//Limpa a pasta onde serao armazenados os arquivos contendo os pares Q&A
		    //FileUtils.cleanDirectory(new File("/home/lucas/Dropbox/pares Q&A/" + nomeAPIs));
		    
		    //Lista que armazenara o id de perguntas que possuem a tag (categoria)
		    List<Integer> listaIdPerguntas = new ArrayList<Integer>();
		    File f = new File("/home/lucas/Dropbox/idPerguntasAPIs/idsPerguntas_" + nomeAPIs + ".txt");
		    if(f.exists()){
		    	BufferedReader bufferedReaderArquivoIdPerguntas = new BufferedReader(new InputStreamReader(new FileInputStream("/home/lucas/Dropbox/idPerguntasAPIs/idsPerguntas_" + nomeAPIs + ".txt")));
				String linha = ""; 
				while((linha = bufferedReaderArquivoIdPerguntas.readLine()) != null){
					int id = Integer.parseInt(linha);
					listaIdPerguntas.add(id);
				}
		    }else{
		    	PrintWriter outFileIds = new PrintWriter(new BufferedWriter(new FileWriter("/home/lucas/Dropbox/idPerguntasAPIs/idsPerguntas_" + nomeAPIs + ".txt", false)));
				//Tags da lib em questao
				List<String> listaTagsLib = new ArrayList<String>();
				for(int i=0; i< vetAPIs.length; i++)
					listaTagsLib.add(vetAPIs[i]);
				String query = ConsultasBD.consultaPerguntasAleatoriasEmCategorias(listaTagsLib);
				System.out.println(query);
				ResultSet rs = cbd.executaQuery(query);
				while(rs.next()){
					int postid = rs.getInt("postid");
					listaIdPerguntas.add(postid);
					outFileIds.println(postid);
				}
				outFileIds.close();
		    }
		    
		    //Lista para guardar os resultados (cada elemento da lista eh outra lista com os valores das features)
		    List<List<Double>> listaResultados = new ArrayList<List<Double>>();
		   
		    //Variavel que contem o indice atual da pergunta que esta sendo processada
		    int indiceAtual = 0;
		    while(nroDeParesProcessados < nroMaxDeParesConsiderados && indiceAtual < listaIdPerguntas.size()){
		    	int idPergunta = listaIdPerguntas.get(indiceAtual);
				boolean perguntaPossuiRespostaComAnswererValido = false;
				boolean perguntaPossuiRespostaComCodigoFonte = false;
				
				String q1 = ConsultasBD.consultaCorpo(idPergunta);
				ResultSet r1 = cbd.executaQuery(q1);
				r1.next();
				String corpoPergunta = r1.getString("body");
				
				indiceAtual++;
				q1 = ConsultasBD.consultaOwneruserid(idPergunta);
				r1 = cbd.executaQuery(q1);
				r1.next();
				int idAsker = r1.getInt("owneruserid");
				//Se retornar 0, significa que o owneruserid da tabela posts eh nulo, por isso desconsideramos
				if(idAsker == 0){
					//System.out.println("Desconsiderando a pergunta " + idPergunta + ", por ter ownderuserid nulo." );
					continue;
				}
				
				q1 = ConsultasBD.consultaTitulo(idPergunta);
				r1 = cbd.executaQuery(q1);
				r1.next();
				String tituloPergunta = r1.getString("title");
				if(!classificador.classficaComoHowTO(tituloPergunta, corpoPergunta)){
					//System.out.println((indiceAtual-1) + " nao eh howto");
					continue;
				}
				else{
					//System.out.println((indiceAtual-1) + " eh howto");
				}
				
				q1 = ConsultasBD.consultaTags(idPergunta);
				r1 = cbd.executaQuery(q1);
				r1.next();
				String strTags = r1.getString("tags").replace("<", " ").replace(">", " ");
				
				//Agora vamos recuperar todas as respostas associadas a pergunta
				String query1 = ConsultasBD.consultaRespostasDePergunta(idPergunta);
				ResultSet rsInterno = cbd.executaQuery(query1);
				while(rsInterno.next()){
					int idResposta = rsInterno.getInt("id");
					String corpoResposta = rsInterno.getString("body");
					int idAnswerer = rsInterno.getInt("owneruserid");
					
					//Se retornar 0, significa que o owneruserid da tabela posts eh nulo, por isso desconsideramos
					if(idAnswerer == 0){
						//System.out.println("Desconsiderando o par " + idPergunta + "-" + idResposta + ", pq a resposta tem ownderuserid nulo." );
						continue;
					}	else{
						perguntaPossuiRespostaComAnswererValido = true;
						nroDeParesProcessados++;
					}
					
					//String textoPar = "<b>Question Title: " + tituloPergunta + "</b><br><b>Tags: " + strTags+ "</b><br><b>Question Body:</b><br>" + corpoPergunta + "<br><b>Answer:</b><br>" + corpoResposta;
					//String textoPar = "<b>Question Title: " + tituloPergunta + "</b>";
					//PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("/media/HDii-2x3Tb/Lucas/lucas2/drop box/Dropbox/pares Q&A/" + nomeAPIs + "/" + idPergunta + "-" + idResposta + ".html", false)));
					//out.print(textoPar);
					//out.close();
					
					List<Double> listaFeaturesPar = ec.calculaFeatures(idPergunta, idResposta, idAsker, idAnswerer, corpoPergunta, corpoResposta);
					String feauresPair = "";
					for(int i=0; i< listaFeaturesPar.size(); i++){
						feauresPair += (i+1) + ":" + listaFeaturesPar.get(i) + " ";
					}
					feauresPair += "#" + idPergunta + "-" + idResposta;
					outFileFeatures.println(feauresPair);
					outFileFeatures.flush();
					
					listaResultados.add(listaFeaturesPar);
					
					//Caso queira gravar em arquivo de texto
					//outFileFeatures.println(textoSaida);
					//outFileFeatures.flush();
				
				}
				
				if( (perguntaPossuiRespostaComAnswererValido)){
					nroDeThreadsJaProcessadas++;
					System.out.println("nroDeThreadsJaProcessadas # nroDeParesProcessados = " + nroDeThreadsJaProcessadas + " " + nroDeParesProcessados);
				}
				
		    }
		    
		    outFileFeatures.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
