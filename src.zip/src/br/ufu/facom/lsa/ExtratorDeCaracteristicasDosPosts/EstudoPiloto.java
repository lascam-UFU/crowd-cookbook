package br.ufu.facom.lsa.ExtratorDeCaracteristicasDosPosts;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.Manifest;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;
import br.ufu.facom.lsa.Lda.ManipuladorDeTexto;
import br.ufu.facom.lsa.TesteHowTo.ClassificadorHowTo;

public class EstudoPiloto {
	public static void main(String[] args) {
		try{
		
		ManipuladorDeTexto mt = new ManipuladorDeTexto("", true);
			
		ConexaoDB cbd = new ConexaoDB();
		 //Conecta ao banco stackOfMar2013
		cbd.conectaAoBD();	
		
		ConexaoDB cbdStackResearch = new ConexaoDB();
		//Conecta ao banco stack_research
		cbdStackResearch.conectaAoBD("stack_research");
		
		int nroDeRepostasComCodigoFonte = 0;
	
		int numAPIs = 5;
		for(int j=0; j< numAPIs; j++){
			//Lista que armazena o(s) nome(s) das apis 
			List<String> listaPIs = new ArrayList<String>();
			if(j == 0){
				listaPIs.add("jquery");
				listaPIs.add("asp.net");
			}else if(j == 1){
				listaPIs.add("swing");
				listaPIs.add("java");
			}else if(j == 2){
				listaPIs.add("swt");
			}else if(j == 3){
				listaPIs.add("stl");
			}else if(j == 4){
				listaPIs.add("c++");
				listaPIs.add("qt4");
			}
			
			int nroDeParesParaBaseline = 1000;
			int nroDeParesProcessados = 0;
			int nroDeThreadsJaProcessadas = 0;
			
			ClassificadorHowTo classificador = new ClassificadorHowTo();
			
			//String que vai armazenar o nome de todas APIs do vetor vetAPIs
			String nomeAPIs = "";
			
			for(int i=0; i< listaPIs.size(); i++){
				nomeAPIs += listaPIs.get(i);
				if(i!=listaPIs.size()-1){
					nomeAPIs += "_";
				}
			}
		
			//Lista que armazenara o id de perguntas que possuem a tag (categoria)
		    List<Integer> listaIdPerguntas = new ArrayList<Integer>();
		   	String query = ConsultasBD.consultaPerguntasAleatoriasEmCategorias(listaPIs);
				System.out.println(query);
				ResultSet rs = cbd.executaQuery(query);
				while(rs.next()){
					int postid = rs.getInt("postid");
 					listaIdPerguntas.add(postid);
				}
			
		    
		    //Variavel que contem o indice atual da pergunta que esta sendo processada
		    int indiceAtual = 0;
		    while(nroDeParesProcessados < nroDeParesParaBaseline && indiceAtual < listaIdPerguntas.size()){
		    	int idPergunta = listaIdPerguntas.get(indiceAtual);
				//boolean perguntaPossuiRespostaComAnswererValido = false;
								
				String q1 = ConsultasBD.consultaCorpo(idPergunta);
				ResultSet r1 = cbd.executaQuery(q1);
				r1.next();
				String corpoPergunta = r1.getString("body");
				indiceAtual++;
				
				q1 = ConsultasBD.consultaTitulo(idPergunta);
				r1 = cbd.executaQuery(q1);
				r1.next();
				String tituloPergunta = r1.getString("title");
				if(!classificador.classficaComoHowTO(tituloPergunta, corpoPergunta)){
					//System.out.println((indiceAtual-1) + " nao eh howto");
					continue;
				}
				else{
					//System.out.println((indiceAtual-1) + " eh howto");
				}
				
				q1 = ConsultasBD.consultaTags(idPergunta);
				r1 = cbd.executaQuery(q1);
				r1.next();
				String strTags = r1.getString("tags");
				
				//Agora vamos recuperar todas as respostas associadas a pergunta
				String query1 = ConsultasBD.consultaRespostasDePerguntaComOrdemAleatoria(idPergunta);
				ResultSet rsInterno = cbd.executaQuery(query1);
				
				//Ira pegar apenas a primeira resposta, ou seja, cada pergunta gerara apenas 1 par QA
				while(rsInterno.next()){
					int idResposta = rsInterno.getInt("id");
					String corpoResposta = rsInterno.getString("body");
					
					String textoCodigos = mt.getCodigoPreCode(corpoResposta).toLowerCase();
					int nroDeSnippets = mt.getNumeroDeTrechosDeCodigo(corpoResposta);
					String[] lines = textoCodigos.split("\r\n|\r|\n");
					if(!textoCodigos.equals(""))
						nroDeRepostasComCodigoFonte++;
					nroDeParesProcessados++;
					
					PreparedStatement ps = cbdStackResearch.criaPreparedStatement("insert into post_pairs(question_id, answer_id, question_title, question_tags, question_body, answer_body) values(?,?,?,?,?,?)");
					ps.setInt(1, idPergunta);
					ps.setInt(2, idResposta);
					ps.setString(3, tituloPergunta);
					ps.setString(4, strTags);
					ps.setString(5, corpoPergunta);
					ps.setString(6, corpoResposta);
					ps.executeUpdate();
					
					break;
			 	}
				
				nroDeThreadsJaProcessadas++;
				System.out.println("nroDeThreadsJaProcessadas # nroDeParesProcessados = " + nroDeThreadsJaProcessadas + " " + nroDeParesProcessados);
			}
		    
		    System.out.println("nroDeRepostasComCodigoFonte = " + nroDeRepostasComCodigoFonte); 
		    
		}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
