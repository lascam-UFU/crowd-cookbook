package br.ufu.facom.lsa.ExtratorDeCaracteristicasDosPosts;

import java.util.Comparator;

public class ComparatorScoreRespostas implements Comparator<DadosUsuario>{
	
	public int compare(DadosUsuario du1,DadosUsuario du2) {  
		return (du1.getScoreRecebidoPorResponder()  < du2.getScoreRecebidoPorResponder()) ? +1 : (du1.getScoreRecebidoPorResponder()  > du2.getScoreRecebidoPorResponder()) ? -1 : 0;
	}
}
