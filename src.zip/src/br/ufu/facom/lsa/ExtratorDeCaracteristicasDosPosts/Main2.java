package br.ufu.facom.lsa.ExtratorDeCaracteristicasDosPosts;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.zip.GZIPInputStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;

public class Main2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//populaTabelaTags();
		//produzArquivoSuggestedEdits();
		corrigeArquivoComInsercoesNaSuggestedEdits();
		//fazRankingCategorias();
		//produzArquivoTagsDescription();
	}
	
	private static List<String> descobreTodasTags() {
		List<String> listaTags = new ArrayList<String>();
		try{
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();
			
			String query = ConsultasBD.consultaTagsDosPosts();
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				String tag = rs.getString("tagid");
				listaTags.add(tag);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return listaTags;
	}
	
	private static void fazRankingCategorias() {
		try{
			List<String> listaTags = descobreTodasTags();
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();
			
			//Se a categoria ja foi processado, pulamos ela pois significa que ja calculamos o rankeamento de scores para a categoria
			for(int i=0; i< listaTags.size(); i++){
				String categoria = listaTags.get(i);
				System.out.println(i + " " + categoria);
				
				FileOutputStream saidaGeralQ;
				PrintStream fileSaidaGeralQ;
				saidaGeralQ = new FileOutputStream("/home/lucas/Dropbox/rakings_score_por_cat/"+ i + "Q.txt");
				fileSaidaGeralQ = new PrintStream(saidaGeralQ);
				fileSaidaGeralQ.println(categoria);
				
				FileOutputStream saidaGeralA;
				PrintStream fileSaidaGeralA;
				saidaGeralA = new FileOutputStream("/home/lucas/Dropbox/rakings_score_por_cat/"+ i + "A.txt");
				fileSaidaGeralA = new PrintStream(saidaGeralA);
				fileSaidaGeralA.println(categoria);
				
				
				String query = ConsultasBD.consultaScoreRecebidoPorPerguntarPorCat(categoria);
				ResultSet rs = cbd.executaQuery(query);
				while(rs.next()){
					String userId = rs.getString("idUser");
					int score = rs.getInt("score");
					
					fileSaidaGeralQ.println(userId + "\t" + score);
				}
				
				fileSaidaGeralQ.close();
				
				query = ConsultasBD.consultaScoreRecebidoPorResponderPorCat(categoria);
				rs = cbd.executaQuery(query);
				while(rs.next()){
					String userId = rs.getString("idUser");
					int score = rs.getInt("score");
					fileSaidaGeralA.println(userId + "\t" + score);
				}
				
				fileSaidaGeralA.close();
			}
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	//Metodo para eliminar inserts repetidos
	private static void corrigeArquivoComInsercoesNaSuggestedEdits() {
		try{
			HashSet<String> setIdsDeSuggestedEdits = new HashSet<String>();
			PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("/home/lucas/Dropbox/dados_suggested edits/inserts_suggested_edits_tratado_completo.sql", true)));
			
			BufferedReader br = new BufferedReader(new FileReader("/home/lucas/Dropbox/dados_suggested edits/inserts_suggested_edits_completo.sql"));
			String line;
			line = br.readLine();
			out.println(line);
			int contador = 0;
			while ((line = br.readLine()) != null) {
			   String suggestedEditId = line.split("InsertDate\\) values\\(")[1].split(",")[0];
			   if(!setIdsDeSuggestedEdits.contains(suggestedEditId)){
				   setIdsDeSuggestedEdits.add(suggestedEditId);
				   out.println(line);
				   //System.out.println(contador++);
			   }else{
				   System.out.println("repetido - " + suggestedEditId);
			   }
			   //insert into suggestededits(Id, PostId, PostType, CreationDate, RejectionDate, ApprovalDate, ProposingUser, InsertDate) values(12,4733084,'question','1295425619','-1','1295426084',165969, NOW());
			}
			 out.close();
			   br.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private static void produzArquivoTagsDescription() {
		try{
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();
			
			List<String> listaTags = descobreTodasTags();
			
			PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("/home/lucas/tags_description.sql", true)));
		   
			System.setProperty("http.proxyHost", "proxy.ufu.br");
	 		System.setProperty("http.proxyPort", "3128");
	 		System.setProperty("https.proxyHost", "proxy.ufu.br");
	 		System.setProperty("https.proxyPort", "3128");
			int pageNum = 1;
			int ultimo_indice = 0;
			while(ultimo_indice <=  listaTags.size()-1){
				System.out.println(pageNum++);
				
				String strTags = "";
				int count = 0;
				while(count < 20 && ultimo_indice <=  listaTags.size()-1){
					String tag = listaTags.get(ultimo_indice).replace("#", "%23");
					strTags += tag + ";";
					ultimo_indice++;
					count++;
				}
				strTags = strTags.substring(0, strTags.length()-1);
	
				String comando = "https://api.stackexchange.com/2.1/tags/" + strTags + "/wikis?key=1BAOPNIyGbCybVi4U0P5Ww((&page=1&pagesize=100&site=stackoverflow";
				
				URL url = new URL(comando);
		 	    url.openConnection();
		 	    InputStream is = null;
		 	    
		 	    while(true){
		 	    	try{
			 	    	is = url.openStream();
			 	    	break;
			 	    }catch(Exception e){
			 	    	Thread.sleep(120000);
			 	    }
		 	    }
		 	     
		 	    GZIPInputStream ginstream =new GZIPInputStream(is);
		 	    String respostaDescompactada = "";
					byte[] buf = new byte[1024];
					int len;
			         while ((len = ginstream.read(buf)) > 0) 
			        	 respostaDescompactada += new String(buf, 0, len); 
			         String strParcial[] = respostaDescompactada.split("\\{\"items\":")[1].split(",\"quota_remaining\":");
			         String jsonStr = strParcial[0];
			         	
				 	JSONTokener tokener = new JSONTokener(jsonStr);
				 	JSONArray finalResult = new JSONArray(tokener);
				 	
				 	int nroElementos = finalResult.length();
				 	for(int i=0; i< nroElementos; i++){
				 		JSONObject jsob = finalResult.getJSONObject(i);
				 		String tagName = (String)jsob.get("tag_name");
				 		if(!jsob.has("excerpt")){
				 			continue;
				 		}
				 		String tagDescription = (String)jsob.get("excerpt");
				 		
				 		String cmd = "insert into tagsDescription(tagName, desciption) values('" + tagName + "','" + tagDescription + "')";
	 					out.println(cmd + ";");
				 		out.flush();
				 	}
				 	//System.out.println(nroSemIduser);
				 	
				 	if((pageNum % 500) == 0){
				 		System.out.println("dormindo..");
				 		//Thread.sleep(300000);
				 	}
				 	
			}
			
			out.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	private static void produzArquivoSuggestedEdits() {
		try{
			
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();
			
			List<Integer> listaUsuariosValidos = new ArrayList<Integer>();
			String query = ConsultasBD.consultaNroDeRespostasQueForamAceitasGeral();
			ResultSet rs = cbd.executaQuery("SELECT id from users");
			while(rs.next()){
				listaUsuariosValidos.add(rs.getInt("id"));
			}
			
			List<Integer> listaPostValidos = new ArrayList<Integer>();
			rs = cbd.executaQuery("SELECT id from posts");
			while(rs.next()){
				listaPostValidos.add(rs.getInt("id"));
			}
			
			List<Integer> lidEditsJaProcessados = new ArrayList<Integer>();

			
			
			PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("/home/lucas/Dropbox/dados_suggested_edits/inserts_suggested_edits.sql", true)));
		   
			
			System.setProperty("http.proxyHost", "proxy.ufu.br");
	 		System.setProperty("http.proxyPort", "3128");
	 		System.setProperty("https.proxyHost", "proxy.ufu.br");
	 		System.setProperty("https.proxyPort", "3128");
			int pageNum = 1;
			boolean temMaisPaginas = true;
			while(temMaisPaginas){
				System.out.println("Buscando pagina " + pageNum);
				//String comando = "https://api.stackexchange.com/2.1/suggested-edits?key=1BAOPNIyGbCybVi4U0P5Ww((&page=" + pageNum + "&pagesize=100&order=desc&max=1375315200&sort=creation&site=stackoverflow";
				//String comando = "https://api.stackexchange.com/2.1/suggested-edits?key=1BAOPNIyGbCybVi4U0P5Ww((&page=" + pageNum + "&pagesize=100&order=desc&max=1378479444&min=655525&sort=creation&site=stackoverflow";
				String comando = "https://api.stackexchange.com/2.1/suggested-edits?key=1BAOPNIyGbCybVi4U0P5Ww((&page=" + pageNum + "&pagesize=100&order=desc&max=1367321891&min=655525&sort=creation&site=stackoverflow";
				
				URL url = new URL(comando);
		 	    url.openConnection();
		 	    InputStream is = null;
		 	    
		 	    while(true){
		 	    	try{
			 	    	is = url.openStream();
			 	    	break;
			 	    }catch(Exception e){
			 	    	Thread.sleep(120000);
			 	    }
		 	    }
		 	     
		 	    GZIPInputStream ginstream =new GZIPInputStream(is);
		 	    String respostaDescompactada = "";
					byte[] buf = new byte[1024];
					int len;
			         while ((len = ginstream.read(buf)) > 0) 
			        	 respostaDescompactada += new String(buf, 0, len); 
			        // System.out.println(respostaDescompactada);
			         //String strParcial[] = respostaDescompactada.split("\\{\"items\":")[1].split(",\"quota_remaining\":");
			         String strParcial[] = respostaDescompactada.split("\\{\"items\":")[1].split(",\"has_more\":");
			         String jsonStr = strParcial[0];
			        // System.out.println(jsonStr);
			         String strResto = strParcial[1];
			        // System.out.println(strResto);
			         //if(strResto.split("\"has_more\":")[1].contains("true")){
			        //	 temMaisPaginas =  true;
			        //	 pageNum++;
			         //}
			         
			         if(strResto.split(",")[0].contains("true")){
					  	 temMaisPaginas =  true;
					  	 pageNum++;
					 }
			        	 
			         else
			        	 temMaisPaginas = false;
				 		
				 	JSONTokener tokener = new JSONTokener(jsonStr);
				 	JSONArray finalResult = new JSONArray(tokener);
				 	
				 	//System.out.println(jsonStr);
				 	
				 	int nroElementos = finalResult.length();
				 	int nroSemIduser = 0;
				 	for(int i=0; i< nroElementos; i++){
				 		JSONObject jsob = finalResult.getJSONObject(i);
				 		Integer idSuggestedEdit = (Integer)jsob.get("suggested_edit_id");
				 		if(lidEditsJaProcessados.contains(idSuggestedEdit))
				 			continue;
				 		lidEditsJaProcessados.add(idSuggestedEdit);
				 		
				 		Integer idPost = (Integer)jsob.get("post_id");
				 		if(!listaPostValidos.contains(idPost))
				 			continue;
				 		String postType = (String)jsob.get("post_type");
				 		String titulo = "";
				 		if(jsob.has("title"))
				 			titulo = (String)jsob.get("title");
				 		String comentario = "";
				 		if(jsob.has("comment"))
				 			comentario = (String)jsob.get("comment");
				 		Integer creationDate = (Integer)jsob.get("creation_date");
				 		Integer rejectionDate = -1;
				 		if(jsob.has("rejection_date"))
				 			rejectionDate = (Integer)jsob.get("rejection_date");
				 		Integer approvalDate = -1;
				 		if(jsob.has("approval_date"))
				 			approvalDate = (Integer)jsob.get("approval_date");
				 		Integer idUsuario = -2;
				 		if(jsob.has("proposing_user")){
				 			JSONObject jsobDadosUsuario = (JSONObject)jsob.get("proposing_user");
				 			if(jsobDadosUsuario.has("user_id"))
				 				idUsuario = (Integer)jsobDadosUsuario.get("user_id");
				 		}
				 		if(!listaUsuariosValidos.contains(idUsuario) && idUsuario != -2)
				 			continue;
				 		//PreparedStatement ps = cbd.criaPreparedStatement("insert into suggestededits(Id, PostId, PostType, Title, Comment, CreationDate, RejectionDate, ApprovalDate, ProposingUser, InsertDate) values(?,?,?,?,?,?,?,?,?,NOW())");
						//ps.setInt(1, idSuggestedEdit);
				 	    //ps.setInt(2, idPost);
				 		//ps.setString(3, postType);
				 		//ps.setString(4, titulo);
				 		//ps.setString(5, comentario);
				 		//ps.setInt(6, creationDate);
				 		//ps.setString(7, rejectionDate+"");
				 		//ps.setString(8, approvalDate+"");
				 		//ps.setInt(9, idUsuario);
				 		
				 		
				 		String cmd2 = "insert into suggestededits(Id, PostId, PostType, CreationDate, RejectionDate, ApprovalDate, ProposingUser, InsertDate) values(" + 
	 					idSuggestedEdit + "," + idPost + ",'" + postType + "','" + creationDate + "','" + rejectionDate + "','" + approvalDate + "'," + idUsuario + ", NOW())";
				 		//System.out.println(cmd2);
				 		
				 		out.println(cmd2 + ";");
				 		 out.flush();
				 		System.out.println(creationDate);

				 		int a = 0;
					 	int b =a;
				 	}
				 	//System.out.println(nroSemIduser);
				 	
				 	if((pageNum % 500) == 0)
				 		Thread.sleep(300000) ;
				 	
				 
		        
			}
			
			out.close();
		
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	private static void populaTabelaTags() {
		try{	
			String query =  "SELECT id, tags FROM posts WHERE posttypeid = 1;";
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();
			ResultSet rs = cbd.executaQuery(query);
			PreparedStatement ps = cbd.criaPreparedStatement("insert into tags(tagid, postid) values(?,?)");
			while(rs.next()){
				String tags = rs.getString("tags");
				int postid = Integer.parseInt(rs.getString("id"));
				String tagsVet[] = tags.split("><");
				tagsVet[0] = tagsVet[0].replace("<", "");
				tagsVet[tagsVet.length-1] = tagsVet[tagsVet.length-1].replace(">", "");
				for(int i=0; i< tagsVet.length; i++){
					ps.setString(1, tagsVet[i]);
					ps.setInt(2, postid);
					ps.executeUpdate();
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
