package br.ufu.facom.lsa.ExtratorDeCaracteristicasDosPosts;

import java.io.Serializable;

public class DadosRatingCategoria implements Serializable{
	private String nomeDaCategoria;
	/*private int nroDeRespostasAceitas;
	private int nroDeUpvotesEmSuasPerguntas;
	private int nroDeDownvotesEmSuasPerguntas;
	private int nroDeUpvotesEmSuasRespostas;
	private int nroDeDownvotesEmSuasRespostas;
	private int ratingRecebidoPorPerguntar;
	private int ratingRecebidoPorResponder;
	private int posicaoNoRankingDeRatingDePerguntas;
	private int posicaoNoRankingDeRatingDeRespostas;*/
	private int scoreRecebidoPorPerguntar;
	private int scoreRecebidoPorResponder;
	private int posicaoNoRankingscoreDePerguntas;
	private int posicaoNoRankingDescoreDeRespostas;
	
	public DadosRatingCategoria(String nomeDaCategoria) {
		this.nomeDaCategoria = nomeDaCategoria;
		/*nroDeRespostasAceitas = 0;
		nroDeUpvotesEmSuasPerguntas = 0;
		nroDeDownvotesEmSuasPerguntas = 0;
		nroDeUpvotesEmSuasRespostas = 0;
		nroDeDownvotesEmSuasRespostas = 0;
		ratingRecebidoPorPerguntar = 0;
		ratingRecebidoPorResponder = 0;
		posicaoNoRankingDeRatingDePerguntas = 0;
		posicaoNoRankingDeRatingDeRespostas = 0;*/
		scoreRecebidoPorPerguntar = 0;
		scoreRecebidoPorResponder = 0;
		posicaoNoRankingscoreDePerguntas = 0;
		posicaoNoRankingDescoreDeRespostas = 0;
	}
	
	public int getScoreRecebidoPorPerguntarNestaCategoria() {
		return scoreRecebidoPorPerguntar;
	}

	public void setScoreRecebidoPorPerguntarNestaCategoria(int scoreRecebidoPorPerguntar) {
		this.scoreRecebidoPorPerguntar = scoreRecebidoPorPerguntar;
	}

	public int getScoreRecebidoPorResponderNestaCategoria() {
		return scoreRecebidoPorResponder;
	}

	public void setScoreRecebidoPorResponderNestaCategoria(int scoreRecebidoPorResponder) {
		this.scoreRecebidoPorResponder = scoreRecebidoPorResponder;
	}

	public int getPosicaoNoRankingDeScoreDePerguntasDestaCategoria() {
		return posicaoNoRankingscoreDePerguntas;
	}

	public void setPosicaoNoRankingDeScoreDePerguntasDestaCategoria(
			int posicaoNoRankingscoreDePerguntas) {
		this.posicaoNoRankingscoreDePerguntas = posicaoNoRankingscoreDePerguntas;
	}

	public int getPosicaoNoRankingDeScoreDeRespostasDestaCategoria() {
		return posicaoNoRankingDescoreDeRespostas;
	}

	public void setPosicaoNoRankingDeScoreDeRespostasDestaCategoria(
			int posicaoNoRankingDescoreDeRespostas) {
		this.posicaoNoRankingDescoreDeRespostas = posicaoNoRankingDescoreDeRespostas;
	}

	public String getNomeDaCategoria() {
		return nomeDaCategoria;
	}

	public void setNomeDaCategoria(String nomeDaCategoria) {
		this.nomeDaCategoria = nomeDaCategoria;
	}

	/*public int getNroDeRespostasAceitas() {
		return nroDeRespostasAceitas;
	}

	public void setNroDeRespostasAceitas(int nroDeRespostasAceitas) {
		this.nroDeRespostasAceitas = nroDeRespostasAceitas;
	}

	public int getNroDeUpvotesEmSuasPerguntas() {
		return nroDeUpvotesEmSuasPerguntas;
	}

	public void setNroDeUpvotesEmSuasPerguntas(int nroDeUpvotesEmSuasPerguntas) {
		this.nroDeUpvotesEmSuasPerguntas = nroDeUpvotesEmSuasPerguntas;
	}

	public int getNroDeDownvotesEmSuasPerguntas() {
		return nroDeDownvotesEmSuasPerguntas;
	}

	public void setNroDeDownvotesEmSuasPerguntas(int nroDeDownvotesEmSuasPerguntas) {
		this.nroDeDownvotesEmSuasPerguntas = nroDeDownvotesEmSuasPerguntas;
	}

	public int getNroDeUpvotesEmSuasRespostas() {
		return nroDeUpvotesEmSuasRespostas;
	}

	public void setNroDeUpvotesEmSuasRespostas(int nroDeUpvotesEmSuasRespostas) {
		this.nroDeUpvotesEmSuasRespostas = nroDeUpvotesEmSuasRespostas;
	}

	public int getNroDeDownvotesEmSuasRespostas() {
		return nroDeDownvotesEmSuasRespostas;
	}

	public void setNroDeDownvotesEmSuasRespostas(int nroDeDownvotesEmSuasRespostas) {
		this.nroDeDownvotesEmSuasRespostas = nroDeDownvotesEmSuasRespostas;
	}

	public int getRatingRecebidoPorPerguntar() {
		return ratingRecebidoPorPerguntar;
	}

	public void setRatingRecebidoPorPerguntar(int ratingRecebidoPorPerguntar) {
		this.ratingRecebidoPorPerguntar = ratingRecebidoPorPerguntar;
	}

	public int getRatingRecebidoPorResponder() {
		return ratingRecebidoPorResponder;
	}

	public void setRatingRecebidoPorResponder(int ratingRecebidoPorResponder) {
		this.ratingRecebidoPorResponder = ratingRecebidoPorResponder;
	}

	public int getPosicaoNoRankingDeRatingDePerguntas() {
		return posicaoNoRankingDeRatingDePerguntas;
	}

	public void setPosicaoNoRankingDeRatingDePerguntas(
			int posicaoNoRankingDeRatingDePerguntas) {
		this.posicaoNoRankingDeRatingDePerguntas = posicaoNoRankingDeRatingDePerguntas;
	}

	public int getPosicaoNoRankingDeRatingDeRespostas() {
		return posicaoNoRankingDeRatingDeRespostas;
	}

	public void setPosicaoNoRankingDeRatingDeRespostas(
			int posicaoNoRankingDeRatingDeRespostas) {
		this.posicaoNoRankingDeRatingDeRespostas = posicaoNoRankingDeRatingDeRespostas;
	}*/
	
	
	
	
}
