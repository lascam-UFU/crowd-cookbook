package br.ufu.facom.lsa.ExtratorDeCaracteristicasDosPosts;

import java.util.Comparator;

public class ComparatorScorePerguntas implements Comparator<DadosUsuario>{
	
	public int compare(DadosUsuario du1,DadosUsuario du2) {  
		return (du1.getScoreRecebidoPorPerguntar()  < du2.getScoreRecebidoPorPerguntar()) ? +1 : (du1.getScoreRecebidoPorPerguntar()  > du2.getScoreRecebidoPorPerguntar()) ? -1 : 0;
	}
}
