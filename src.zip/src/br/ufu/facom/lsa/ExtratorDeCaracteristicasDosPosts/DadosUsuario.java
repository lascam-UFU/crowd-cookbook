package br.ufu.facom.lsa.ExtratorDeCaracteristicasDosPosts;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DadosUsuario implements Serializable{
	private int id;
	private List<String> categoriasEmQueEhTop3Answerer;
	private List<String> categoriasEmQueEhTop3Asker;
	private int nroDeCategoriasQueJaRespondeu;
	private int nroDeCategoriasQueJaPerguntou;
	private int nroDeRespostasAceitas;
	private int nroDeUpvotesEmSuasPerguntas;
	private int nroDeDownvotesEmSuasPerguntas;
	private int nroDeUpvotesEmSuasRespostas;
	private int nroDeDownvotesEmSuasRespostas;
	private int ratingRecebidoPorPerguntar;
	private int ratingRecebidoPorResponder;
	private int posicaoNoRankingDeRatingDePerguntas;
	private int posicaoNoRankingDeRatingDeRespostas;
	private int scoreRecebidoPorPerguntar;
	private int scoreRecebidoPorResponder;
	private int posicaoNoRankingDeScoreDePerguntas;
	private int posicaoNoRankingDeScoreDeRespostas;
	private Map<String, DadosRatingCategoria> mapInfoRankingPorCategoria; 
	
	public DadosUsuario(int id){
		this.id = id;
		categoriasEmQueEhTop3Answerer = new ArrayList<String>();
		categoriasEmQueEhTop3Asker = new ArrayList<String>();
		nroDeCategoriasQueJaRespondeu = 0;
		nroDeCategoriasQueJaPerguntou = 0;
		nroDeRespostasAceitas = 0;
		nroDeUpvotesEmSuasPerguntas = 0;
		nroDeDownvotesEmSuasPerguntas = 0;
		nroDeUpvotesEmSuasRespostas = 0;
		nroDeDownvotesEmSuasRespostas = 0;
		ratingRecebidoPorPerguntar = 0;
		ratingRecebidoPorResponder = 0;
		posicaoNoRankingDeRatingDePerguntas = 0;
		posicaoNoRankingDeRatingDeRespostas = 0;
		mapInfoRankingPorCategoria = new HashMap<String, DadosRatingCategoria>(); 
		//Sao inicializados com valor minimo, para usuarios que nao responderam ao perguntaram serem jogados no final do ranking
		scoreRecebidoPorPerguntar = Integer.MIN_VALUE;
		scoreRecebidoPorResponder = Integer.MIN_VALUE;
		posicaoNoRankingDeScoreDePerguntas = 0;
		posicaoNoRankingDeScoreDeRespostas = 0;;
	}
	
	public int getPosicaoNoRankingDeScoreDePerguntas() {
		return posicaoNoRankingDeScoreDePerguntas;
	}

	public void setPosicaoNoRankingDeScoreDePerguntas(
			int posicaoNoRankingDeScoreDePerguntas) {
		this.posicaoNoRankingDeScoreDePerguntas = posicaoNoRankingDeScoreDePerguntas;
	}

	public int getPosicaoNoRankingDeScoreDeRespostas() {
		return posicaoNoRankingDeScoreDeRespostas;
	}

	public void setPosicaoNoRankingDeScoreDeRespostas(
			int posicaoNoRankingDeScoreDeRespostas) {
		this.posicaoNoRankingDeScoreDeRespostas = posicaoNoRankingDeScoreDeRespostas;
	}

	public int getScoreRecebidoPorPerguntar() {
		return scoreRecebidoPorPerguntar;
	}

	public void setScoreRecebidoPorPerguntar(int scoreRecebidoPorPerguntar) {
		this.scoreRecebidoPorPerguntar = scoreRecebidoPorPerguntar;
	}

	public int getScoreRecebidoPorResponder() {
		return scoreRecebidoPorResponder;
	}

	public void setScoreRecebidoPorResponder(int scoreRecebidoPorResponder) {
		this.scoreRecebidoPorResponder = scoreRecebidoPorResponder;
	}

	public Map<String, DadosRatingCategoria> getMapInfoRankingPorCategoria() {
		return mapInfoRankingPorCategoria;
	}

	public void setMapInfoRankingPorCategoria(
			Map<String, DadosRatingCategoria> mapInfoRankingPorCategoria) {
		this.mapInfoRankingPorCategoria = mapInfoRankingPorCategoria;
	}

	public int getPosicaoNoRankingDeRatingDePerguntas() {
		return posicaoNoRankingDeRatingDePerguntas;
	}

	public void setPosicaoNoRankingDeRatingDePerguntas(
			int posicaoNoRankingDeRatingDePerguntas) {
		this.posicaoNoRankingDeRatingDePerguntas = posicaoNoRankingDeRatingDePerguntas;
	}

	public int getPosicaoNoRankingDeRatingDeRespostas() {
		return posicaoNoRankingDeRatingDeRespostas;
	}

	public void setPosicaoNoRankingDeRatingDeRespostas(
			int posicaoNoRankingDeRatingDeRespostas) {
		this.posicaoNoRankingDeRatingDeRespostas = posicaoNoRankingDeRatingDeRespostas;
	}

	public int getNroDeRespostasAceitas() {
		return nroDeRespostasAceitas;
	}

	public void setNroDeRespostasAceitas(int nroDeRespostasAceitas) {
		this.nroDeRespostasAceitas = nroDeRespostasAceitas;
	}

	public int getNroDeUpvotesEmSuasPerguntas() {
		return nroDeUpvotesEmSuasPerguntas;
	}

	public void setNroDeUpvotesEmSuasPerguntas(int nroDeUpvotesEmSuasPerguntas) {
		this.nroDeUpvotesEmSuasPerguntas = nroDeUpvotesEmSuasPerguntas;
	}

	public int getNroDeDownvotesEmSuasPerguntas() {
		return nroDeDownvotesEmSuasPerguntas;
	}

	public void setNroDeDownvotesEmSuasPerguntas(int nroDeDownvotesEmSuasPerguntas) {
		this.nroDeDownvotesEmSuasPerguntas = nroDeDownvotesEmSuasPerguntas;
	}

	public int getNroDeUpvotesEmSuasRespostas() {
		return nroDeUpvotesEmSuasRespostas;
	}

	public void setNroDeUpvotesEmSuasRespostas(int nroDeUpvotesEmSuasRespostas) {
		this.nroDeUpvotesEmSuasRespostas = nroDeUpvotesEmSuasRespostas;
	}

	public int getNroDeDownvotesEmSuasRespostas() {
		return nroDeDownvotesEmSuasRespostas;
	}

	public void setNroDeDownvotesEmSuasRespostas(int nroDeDownvotesEmSuasRespostas) {
		this.nroDeDownvotesEmSuasRespostas = nroDeDownvotesEmSuasRespostas;
	}

	public int getRatingRecebidoPorPerguntar() {
		return ratingRecebidoPorPerguntar;
	}

	public void setRatingRecebidoPorPerguntar(int ratingRecebidoPorPerguntar) {
		this.ratingRecebidoPorPerguntar = ratingRecebidoPorPerguntar;
	}

	public int getRatingRecebidoPorResponder() {
		return ratingRecebidoPorResponder;
	}

	public void setRatingRecebidoPorResponder(int ratingRecebidoPorResponder) {
		this.ratingRecebidoPorResponder = ratingRecebidoPorResponder;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<String> getCategoriasEmQueEhTop3Answerer() {
		return categoriasEmQueEhTop3Answerer;
	}

	public void setCategoriasEmQueEhTop3Answerer(
			List<String> categoriasEmQueEhTop3Answerer) {
		this.categoriasEmQueEhTop3Answerer = categoriasEmQueEhTop3Answerer;
	}

	public List<String> getCategoriasEmQueEhTop3Asker() {
		return categoriasEmQueEhTop3Asker;
	}

	public void setCategoriasEmQueEhTop3Asker(
			List<String> categoriasEmQueEhTop3Asker) {
		this.categoriasEmQueEhTop3Asker = categoriasEmQueEhTop3Asker;
	}

	public int getNroDeCategoriasQueJaRespondeu() {
		return nroDeCategoriasQueJaRespondeu;
	}

	public void setNroDeCategoriasQueJaRespondeu(int nroDeCategoriasQueJaRespondeu) {
		this.nroDeCategoriasQueJaRespondeu = nroDeCategoriasQueJaRespondeu;
	}

	public int getNroDeCategoriasQueJaPerguntou() {
		return nroDeCategoriasQueJaPerguntou;
	}

	public void setNroDeCategoriasQueJaPreguntou(int nroDeCategoriasQueJaPerguntou) {
		this.nroDeCategoriasQueJaPerguntou = nroDeCategoriasQueJaPerguntou;
	}
}
