/* 
 * Classe responsavel por gerar os arquivos sobre os quais serao aplicados o LDA 
 */

package br.ufu.facom.lsa.Lda;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.ResultSet;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;
import br.ufu.facom.lsa.Lda.ManipuladorDeTexto;
import br.ufu.facom.lsa.TesteHowTo.ClassificadorHowTo;

import org.apache.commons.io.FileUtils;

public class Main {
	

	public final static void main(String[] args) {
		//API que iremos gerar os arquivos para os posts e aplicar LDA (ex. "swt", "gwt")
		String nomeAPI = "swt";
		//Caminho do sistema de arquivos onde iremos armazenar os arquivos gerados a partir dos posts
		String caminho = "/media/HDii-2x3Tb/Lucas/lucas2/stackoverflow/Dados LDA";
		//Variavel booleana para indicar se os trechos de codigo-fonte serao considerados na construcao dos arquivos
		Boolean consideraCodigo = false;
		//Variavel booleana para indicar se serao consideradas apenas as threads com resposta aceita
		Boolean consideraApenasComRespostaAceita = false;
		//Variavel para indicar a estrategia que adotaremos para construcao dos arquivos (possui um dos valores de constantes definidas na classe)
		int tipoArquivo = GerenciadorDeLDA.COMPLETE_THREAD;
		//Variavel booleana para indicar se o titulo da pergunta sera considerado na construcao dos arquivos
		Boolean consideraTitulo = false; 
		//Variavel booleana para indicar se serao considerados bi-grans 
		//se for true, os tolens finaos produzidos serao tanto bigrans como unigrans
		Boolean usaBigrans = false; 
		//Variavel boolena se indica se iremos aplicar o LDA usando o pre-processamento convensional, ou se usaremos chunking
		//se for true, usaremos o pre-processamento convesional de texto
		Boolean usaPreProcessamentoConvensional = true;
		//Variavel boolena que indica se serao consideradas apeans threads do tipo HOW no LDA
		//se for true, usaremos apenas threads cujo tipo da pergunta eh HOW
		Boolean usaApenasHOw = true;
		
		String vetAPIs[] = {"swt"};		
		String nomeAPIs = "";
		
		for(int j=0; j< vetAPIs.length; j++){
			nomeAPIs += vetAPIs[j];
			if(j!=vetAPIs.length-1){
				nomeAPIs += "_";
			}
		}
		
		//Cria a pasta onde serao armazenadas os arquivos que participarao do LDA
		String nomePasta = caminho + "/" + nomeAPIs + "_" + (consideraCodigo ? "1": "0") + "_" + tipoArquivo + "_" + (consideraApenasComRespostaAceita ? "1": "0") + "_" + (usaPreProcessamentoConvensional ? "1": "0");
		File f = new File(nomePasta);
		f.mkdir();
		
		//metodo responsavel por produzir os arquivos referentes aos posts
		//GerenciadorDeLDA.produzArquivosPosts(vetAPIs, tipoArquivo, consideraTitulo, consideraCodigo, nomePasta, consideraApenasComRespostaAceita, usaPreProcessamentoConvensional, usaApenasHOw);
		
		//Depois de gerados os arquivos, iremos aplicar o LDA
		//alpha: um bom valor heuristicamente conhecido eh 50/numTopicos, por isso passa 50 como alpha
		//beta: um bom valor utilizado eh 0.01
		//iteracoes: geralmente utilizadas de 1000-2000
		//GerenciadorDeLDA.aplicaLDA(nomePasta, 20, 50.0, 0.01, 2000, usaBigrans, null, null, null);
		
	}
}
