package br.ufu.facom.lsa.Lda;

import java.util.Comparator;

public class ComparatorDocTopicPair implements Comparator<DocTopicPair>{
	
	private String metricPair;
	
	public String getMetricPair() {
		return metricPair;
	}

	public void setMetricPair(String metricPair) {
		this.metricPair = metricPair;
	}

	public int compare(DocTopicPair o1, DocTopicPair o2) {
		return o1.getPercent() < o2.getPercent() ? +1 : o1.getPercent() > o2.getPercent() ? -1 : 0;
	}
}