/* 
 * Classe que representa o PERCENTUAL de um DOC para um TOPICO  
 */

package br.ufu.facom.lsa.Lda;

public class DocTopicPair {
	private String DocName;
	private int topicId;
	private double percent;
	
	public DocTopicPair(String docName, int topicId, double percent) {
		this.DocName = docName;
		this.topicId = topicId;
		this.percent = percent;
	}

	public String getDocName() {
		return DocName;
	}

	public void setDocName(String docName) {
		DocName = docName;
	}

	public int getTopicId() {
		return topicId;
	}

	public void setTopicId(int topicId) {
		this.topicId = topicId;
	}

	public double getPercent() {
		return percent;
	}

	public void setPercent(double percent) {
		this.percent = percent;
	}
	
	
	
	
}
