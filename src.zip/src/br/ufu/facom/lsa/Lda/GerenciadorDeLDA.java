/* 
 * Classe responsavel por aplicar o LDA 
 */

package br.ufu.facom.lsa.Lda;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

import br.ufu.facom.isel.cookbookgenerator.main.LDAConfig;
import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;
import br.ufu.facom.lsa.GeradorDeCookbooks.DadoRanqueamento;
import br.ufu.facom.lsa.TesteHowTo.ClassificadorHowTo;
import cc.mallet.types.*;
import cc.mallet.pipe.*;
import cc.mallet.pipe.iterator.*;
import cc.mallet.topics.*;

import java.sql.ResultSet;
import java.util.*;
import java.util.regex.*;

import org.apache.commons.io.FileUtils;

public class GerenciadorDeLDA {

	// Para a construcao do arquivo toda a thread sera considerada (pergunta e todas
	// as respostas)
	public static final int COMPLETE_THREAD = 0;
	// Para a construcao do arquivo sera considerada a pergunta
	public static final int APENAS_PERGUNTA = 1;
	// Para a construcao do arquivo sera considerada a pergunta e a respota aceita
	public static final int PERGUNTA_RESPOSTA_ACEITA = 2;

	// Metodo responsavel por aplicar a LDA com base no caminho da pasta onde estao
	// os arquivos previamente produzidos
	public static void aplicaLDA(LDAConfig ldaConfig, int numTopicos, double alfa, double beta, int numIteracoes,
			Boolean usaBigrans, Map<String, List<DocTopicPair>> mapDocumentoTopicos,
			Map<String, List<DocTopicPair>> mapTopicoDocumentos, Map<String, String> mapTopicoTopTerms) {
		// <idDaPergunta, topicoDominanteNaThread>
		try {

			// Cria o objeto file passando o caminho onde estao localizados os arquivos
			File diretorio = new File(ldaConfig.pathForLDAFiles + "/corpus");
			diretorio.mkdir();

			// Cria o objeto fileiterator
			FileIterator fi = new FileIterator(new File[] { diretorio }, null, FileIterator.STARTING_DIRECTORIES);

			// Constroi o pipe com os filtros responsaveis pela transformacao dos dados
			Pipe pipe = buildPipe(usaBigrans);

			InstanceList instances = new InstanceList(pipe);
			instances.addThruPipe(fi); // data, label, name fields

			// Create a model with 100 topics, alpha_t = 0.01, beta_w = 0.01
			// Note that the first parameter is passed as the sum over topics, while
			// the second is the parameter for a single dimension of the Dirichlet prior.
			ParallelTopicModel model = new ParallelTopicModel(numTopicos, alfa, beta);

			// ParallelTopicModel model = new ParallelTopicModel(numTopicos);
			model.addInstances(instances);

			// Use two parallel samplers, which each look at one half the corpus and combine
			// statistics after every iteration.
			model.setNumThreads(2);

			// Run the model for 50 iterations and stop (this is for testing only,
			// for real applications, use 1000 to 2000 iterations)
			model.setNumIterations(numIteracoes);
			// Encontra o modelo
			model.estimate();

			// Exploracao em cima do modelo gerado
			// Imprime para cada topico, as top words de cada um
			// model.printTopWords(new File("/media/HDii-2x3Tb/Lucas/lucas2/drop
			// box/Dropbox/Dados LDA/topicos_words.txt"), 11, false);
			model.printTopWords(new File(ldaConfig.pathForLDAFiles + "/topicos_words.txt"), 21, false);

			// Imprime para cada documento, o percentual de termos de cada topico
			model.printDocumentTopics(new File(ldaConfig.pathForLDAFiles + "/documentos_topicos.txt"));

			model.printState(new File(ldaConfig.pathForLDAFiles + "/state.txt"));

			model.printTopicWordWeights(new File(ldaConfig.pathForLDAFiles + "/topicwordsweights.txt"));

			model.printTypeTopicCounts(new File(ldaConfig.pathForLDAFiles + "/typetopiccounts.txt"));

			// Essa matriz guardara para cada doc o percentual de termos que vem de cada um
			// dos topicos
			// model.getData().size() -> nro de instancias
			double matrizDocTopicos[][] = new double[model.getData().size()][numTopicos];

			for (int i = 0; i < model.getData().size(); i++) {
				matrizDocTopicos[i] = model.getTopicProbabilities(i);
			}

			Object matrizTopTermos[][];
			matrizTopTermos = model.getTopWords(20);
			for (int i = 0; i < matrizTopTermos.length; i++) {
				Object linha[] = matrizTopTermos[i];
				String topTermos = "";
				for (int j = 0; j < linha.length; j++) {
					topTermos += linha[j] + " ";
				}
				mapTopicoTopTerms.put(i + "", topTermos);
			}

			// TAREFA 1: para cada topico descobir o doc que tem maior % deste topico
			// Vamos percorrer primeiro colunas (topicos), depois linhas (docs)

			/*
			 * System.out.
			 * println("*********************TAREFA 1*********************************");
			 * 
			 * for(int i=0; i< numTopicos; i++){
			 * System.out.print("Descobrindo o maior valor para o topico " + i + " ");
			 * double valorMaximoTopico = Double.MIN_VALUE; int indiceMaior = -1; for(int
			 * j=0; j< model.getData().size(); j++){ if(matrizDocTopicos[j][i] >
			 * valorMaximoTopico){ indiceMaior = j; valorMaximoTopico =
			 * matrizDocTopicos[j][i]; } } System.out.println(valorMaximoTopico + " " +
			 * model.getData().get(indiceMaior).instance.getName().toString());
			 * 
			 * 
			 * }
			 */

			System.out.println("*********************TAREFA 2*********************************");

			// TAREFA 2: para cada topico ordenar os docs da maior % para a menor %
			// Map no qual sera mantido para cada topico, uma lista de docs, ordenados da
			// maior % para a menor %
			Map<String, List<DocTopicPair>> mapPercentuais = new HashMap<String, List<DocTopicPair>>();
			// Objeto usado para o ordencao da lista (ordem descendente)
			ComparatorDocTopicPair comp = new ComparatorDocTopicPair();
			for (int i = 0; i < numTopicos; i++) {
				List<DocTopicPair> listTopico = new ArrayList<DocTopicPair>();
				mapPercentuais.put(i + "", listTopico);

				for (int j = 0; j < model.getData().size(); j++) {
					// Cria um objeto, passando: "nome" do doc, id do topico, e o percentual que o
					// doc possui do topico em questao
					DocTopicPair dtp = new DocTopicPair(model.getData().get(j).instance.getName().toString(), i,
							matrizDocTopicos[j][i]);
					listTopico.add(dtp);
				}
				// Ordenamos a lista
				Collections.sort(listTopico, comp);

				mapTopicoDocumentos.put(i + "", listTopico);

				// Depois de ordenar a lista, vamos imprimir os 5 primeiros docs de cada topico
				/*
				 * System.out.println("topico " + i); for(int k=0; k< 5; k++){
				 * System.out.println(" " + listTopico.get(k).getDocName() + " " +
				 * listTopico.get(k).getPercent()); }
				 */

			}

			// System.out.println("*********************TAREFA
			// 3*********************************");
			// TAREFA 3: para cada doc ordenar os topicos de acordo com o percentual
			Map<String, List<DocTopicPair>> mapDocs = new HashMap<String, List<DocTopicPair>>();
			/* ComparatorDocTopicPair */ comp = new ComparatorDocTopicPair();
			for (int i = 0; i < model.getData().size(); i++) {
				List<DocTopicPair> listDoc = new ArrayList<DocTopicPair>();
				mapDocs.put(i + "", listDoc);
				for (int j = 0; j < numTopicos; j++) {
					DocTopicPair dtp = new DocTopicPair(model.getData().get(i).instance.getName().toString(), j,
							matrizDocTopicos[i][j]);
					listDoc.add(dtp);
					Collections.sort(listDoc, comp);
				}

				// Depois de ordenar a lista, vamos imprimir os 5 primeiros topicos de cada doc
				// System.out.println("doc " +
				// model.getData().get(i).instance.getName().toString());
				// System.out.println("doc " +
				// model.getData().get(i).instance.getName().toString() + " " +
				// listDoc.get(0).getTopicId());
				String partes[] = model.getData().get(i).instance.getName().toString().split("/");
				String nome = partes[partes.length - 1].split(".txt")[0];

				/*
				 * List<String> listTopicIds = new ArrayList<String>(); for(int j=0; j<
				 * numTopicos; j++){ listTopicIds.add(listDoc.get(j).getTopicId()+""); }
				 */

				// Colocamos no map o nome do doc e a lista com os ids que o topico possui, em
				// ordem crescente de dominancia do topico
				// mapDocumentoTopicos.put(nome, listDoc.get(0).getTopicId()+"");
				mapDocumentoTopicos.put(nome, listDoc);
				// for(int k=0; k< 5; k++){
				// System.out.println(" " + listDoc.get(k).getTopicId() + " " +
				// listDoc.get(k).getPercent());
				// }

			}

			// Show the words and topics in the first instance
			// The data alphabet maps word IDs to strings
			/*
			 * Alphabet dataAlphabet = instances.getDataAlphabet();
			 * 
			 * FeatureSequence tokens = (FeatureSequence)
			 * model.getData().get(0).instance.getData();
			 * 
			 * //Recuperamos e imprimimos o nome do arquivo (id da pergunta da thread)
			 * String idPergunta = model.getData().get(0).instance.getName().toString();
			 * System.out.println(idPergunta);
			 * 
			 * LabelSequence topics = model.getData().get(0).topicSequence;
			 * 
			 * Formatter out = new Formatter(new StringBuilder(), Locale.US); for (int
			 * position = 0; position < tokens.getLength(); position++) {
			 * out.format("%s-%d ",
			 * dataAlphabet.lookupObject(tokens.getIndexAtPosition(position)),
			 * topics.getIndexAtPosition(position)); } System.out.println(out);
			 * 
			 * // Estimate the topic distribution of the first instance, // given the
			 * current Gibbs state. double[] topicDistribution =
			 * model.getTopicProbabilities(0);
			 * 
			 * // Get an array of sorted sets of word ID/count pairs
			 * ArrayList<TreeSet<IDSorter>> topicSortedWords = model.getSortedWords();
			 * 
			 * // Show top 5 words in topics with proportions for the first document for
			 * (int topic = 0; topic < numTopicos; topic++) { Iterator<IDSorter> iterator =
			 * topicSortedWords.get(topic).iterator();
			 * 
			 * out = new Formatter(new StringBuilder(), Locale.US); out.format("%d\t%.3f\t",
			 * topic, topicDistribution[topic]); int rank = 0; while (iterator.hasNext() &&
			 * rank < 5) { IDSorter idCountPair = iterator.next(); out.format("%s (%.0f) ",
			 * dataAlphabet.lookupObject(idCountPair.getID()), idCountPair.getWeight());
			 * rank++; } System.out.println(out); }
			 * 
			 * // Create a new instance with high probability of topic 0 StringBuilder
			 * topicZeroText = new StringBuilder(); Iterator<IDSorter> iterator =
			 * topicSortedWords.get(0).iterator();
			 * 
			 * int rank = 0; while (iterator.hasNext() && rank < 5) { IDSorter idCountPair =
			 * iterator.next();
			 * topicZeroText.append(dataAlphabet.lookupObject(idCountPair.getID()) + " ");
			 * rank++; }
			 * 
			 * // Create a new instance named "test instance" with empty target and source
			 * fields. InstanceList testing = new InstanceList(instances.getPipe());
			 * testing.addThruPipe(new Instance(topicZeroText.toString(), null,
			 * "test instance", null));
			 * 
			 * TopicInferencer inferencer = model.getInferencer(); //Segundo param: nro
			 * iteracoes double[] testProbabilities =
			 * inferencer.getSampledDistribution(testing.get(0), 10, 1, 5);
			 * System.out.println("0\t" + testProbabilities[0]);
			 */
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void produzArquivosPostsV2(String nomeAPI, int tipoArquivo, boolean consideraTitulo,
			boolean consideraCodigo, String nomePasta, Boolean consideraApenasComRespostaAceita,
			int tipoDeProcessamento, Boolean usaApenasHOw, int tipoDeAplicacaoDoLDA,
			List<DadoRanqueamento> listaDadosRanqueamento, Integer nroDeParesDaApi, PrintWriter outFileLinksTestados,
			int nroDeRepeticaoDoTitulo) {
		try {
			// Deleta todos os arquivos da pasta
			File f = new File(nomePasta + "/corpus/");
			if (f.exists())
				FileUtils.cleanDirectory(new File(nomePasta + "/corpus/"));
			else
				f.mkdirs();

			List<String> listIdThreadsQuePossuemParesBemColocados = new ArrayList<String>();
			// tipoDeAplicacaoDoLDA == 2 -> Nesse caso vão entrar no lda, threads que
			// possuem pares entre o top 30%
			// tipoDeAplicacaoDoLDA == 3 -> Nesse caso vão entrar no lda, uma quantidade
			// menor de threads, ie, as threads que possuem pares entre o top 300 ou 10% da
			// qtde de pares
			outFileLinksTestados.println("\ntipoDeAplicacaoDoLDA: " + tipoDeAplicacaoDoLDA);

			if (tipoDeAplicacaoDoLDA == 2 || tipoDeAplicacaoDoLDA == 3) {

				int posicaoMaximaASerConsideradaNoLda = 300;
				if (tipoDeAplicacaoDoLDA == 2)
					posicaoMaximaASerConsideradaNoLda = (int) (0.3 * nroDeParesDaApi);
				else if (tipoDeAplicacaoDoLDA == 3) {
					if (0.1 * nroDeParesDaApi < posicaoMaximaASerConsideradaNoLda)
						posicaoMaximaASerConsideradaNoLda = (int) (0.1 * nroDeParesDaApi);
				}
				outFileLinksTestados.println("posicaoMaximaASerConsideradaNoLda: " + posicaoMaximaASerConsideradaNoLda);

				for (int i = 0; i < listaDadosRanqueamento.size(); i++) {
					DadoRanqueamento dr = listaDadosRanqueamento.get(i);
					int posicaoNoRanking = dr.getPosicaoNoRank();
					String idDaPergunta = dr.getIdPergunta();
					if (posicaoNoRanking <= posicaoMaximaASerConsideradaNoLda
							&& !listIdThreadsQuePossuemParesBemColocados.contains(idDaPergunta))
						listIdThreadsQuePossuemParesBemColocados.add(idDaPergunta);
				}
			}
			outFileLinksTestados.println("listIdThreadsQuePossuemParesBemColocados.size() : "
					+ listIdThreadsQuePossuemParesBemColocados.size());

			// Conecta ao BD do Stack Overflow para em seguida executar a query
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();

			String queryPerguntas = "";
			String queryRespostas = "";
			// Recupera a querry a ser executada, de acordo com a API e outros parametros
			if (tipoDeAplicacaoDoLDA == 1) {
				queryPerguntas = ConsultasBD.queryQuestions(nomeAPI, tipoArquivo, consideraApenasComRespostaAceita);
			}
			else if (tipoDeAplicacaoDoLDA == 2 || tipoDeAplicacaoDoLDA == 3) {
                System.out.println("ERRO LDA <> 1 nao previsto nesta versao!");
                System.exit(1);
			}

			// Executa a query
			ResultSet rs = cbd.executaQuery(queryPerguntas);

			int idPostAtual = -1;
			String textoDoc = "";
			// int count = 0;
			String tituloDaPerguntaAtual = "";
			String corpoDaPerguntaAtual = "";
			ClassificadorHowTo classificador = new ClassificadorHowTo();

			// Iremos gerar aruivos que posteriormente serao usados para aplicar o LDA
			// O nome da API NAO sera passado no construtor, pois NAO sera considerado stop
			// word
			ManipuladorDeTexto mt = new ManipuladorDeTexto(nomeAPI, true);

			(new File(nomePasta + "/corpus/")).mkdir();

			int countNroThreadsConsideradas = 0;
			while (rs.next()) {
				int idPergunta = Integer.parseInt(rs.getString("id_pergunta"));
				String tituloDaPergunta = rs.getString("titulo_pergunta");
				String corpoDaPergunta = rs.getString("corpo_pergunta");

                // Pergunta
				if (!consideraTitulo)
					textoDoc = rs.getString("body") + "\n";
				else {
					String strTitulo = "";
					for (int i = 0; i < nroDeRepeticaoDoTitulo; i++) {
						strTitulo += tituloDaPergunta + "\n";
					}

					textoDoc = strTitulo + "\n" + rs.getString("body") + "\n";
				}
				

				// Respostas
				queryRespostas = ConsultasBD.queryAnswersFromQuestion(nomeAPI, idPergunta, tipoArquivo, consideraApenasComRespostaAceita);
				ResultSet rs2 = cbd.executaQuery(queryRespostas);
				while (rs2.next()) {
				     textoDoc += rs2.getString("body") + "\n";
				}
				// count++;

				String textoTratado = mt.removeTagsIndesejadas(textoDoc, consideraCodigo);

				if (tipoDeProcessamento == 1)
					textoTratado = mt.removeStopWordsEFazStemming(textoTratado);
				else if (tipoDeProcessamento == 2)
					textoTratado = mt.aplicaChunking(textoTratado);
				else if (tipoDeProcessamento == 3)
					textoTratado = mt.obtemSubstantivos(textoTratado);

				if (!usaApenasHOw || (usaApenasHOw
						&& classificador.classficaComoHowTO(tituloDaPergunta, corpoDaPergunta))) {
					// O nome do arquivo eh o id da pergunta da thread
					BufferedWriter out = new BufferedWriter(
							new FileWriter(nomePasta + "/corpus/" + idPergunta + ".txt"));
					out.write(textoTratado);
					out.close();
					// System.out.println(count);
					countNroThreadsConsideradas++;
				}

				// String count = rs.getString("body");

				// System.out.println(count);
			}

			System.out.println("Nro perguntas consideradas = " + countNroThreadsConsideradas);

			// fecha a conexao com o BD
			cbd.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void produzArquivosPosts(String nomeAPI, int tipoArquivo, boolean consideraTitulo,
			boolean consideraCodigo, String nomePasta, Boolean consideraApenasComRespostaAceita,
			int tipoDeProcessamento, Boolean usaApenasHOw, int tipoDeAplicacaoDoLDA,
			List<DadoRanqueamento> listaDadosRanqueamento, Integer nroDeParesDaApi, PrintWriter outFileLinksTestados,
			int nroDeRepeticaoDoTitulo) {
		try {
			// Deleta todos os arquivos da pasta
			File f = new File(nomePasta + "/corpus/");
			if (f.exists())
				FileUtils.cleanDirectory(new File(nomePasta + "/corpus/"));
			else
				f.mkdirs();

			List<String> listIdThreadsQuePossuemParesBemColocados = new ArrayList<String>();
			// tipoDeAplicacaoDoLDA == 2 -> Nesse caso vão entrar no lda, threads que
			// possuem pares entre o top 30%
			// tipoDeAplicacaoDoLDA == 3 -> Nesse caso vão entrar no lda, uma quantidade
			// menor de threads, ie, as threads que possuem pares entre o top 300 ou 10% da
			// qtde de pares
			outFileLinksTestados.println("\ntipoDeAplicacaoDoLDA: " + tipoDeAplicacaoDoLDA);

			if (tipoDeAplicacaoDoLDA == 2 || tipoDeAplicacaoDoLDA == 3) {

				int posicaoMaximaASerConsideradaNoLda = 300;
				if (tipoDeAplicacaoDoLDA == 2)
					posicaoMaximaASerConsideradaNoLda = (int) (0.3 * nroDeParesDaApi);
				else if (tipoDeAplicacaoDoLDA == 3) {
					if (0.1 * nroDeParesDaApi < posicaoMaximaASerConsideradaNoLda)
						posicaoMaximaASerConsideradaNoLda = (int) (0.1 * nroDeParesDaApi);
				}
				outFileLinksTestados.println("posicaoMaximaASerConsideradaNoLda: " + posicaoMaximaASerConsideradaNoLda);

				for (int i = 0; i < listaDadosRanqueamento.size(); i++) {
					DadoRanqueamento dr = listaDadosRanqueamento.get(i);
					int posicaoNoRanking = dr.getPosicaoNoRank();
					String idDaPergunta = dr.getIdPergunta();
					if (posicaoNoRanking <= posicaoMaximaASerConsideradaNoLda
							&& !listIdThreadsQuePossuemParesBemColocados.contains(idDaPergunta))
						listIdThreadsQuePossuemParesBemColocados.add(idDaPergunta);
				}
			}
			outFileLinksTestados.println("listIdThreadsQuePossuemParesBemColocados.size() : "
					+ listIdThreadsQuePossuemParesBemColocados.size());

			// Conecta ao BD do Stack Overflow para em seguida executar a query
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();

			String query = "";
			// Recupera a querry a ser executada, de acordo com a API e outros parametros
			if (tipoDeAplicacaoDoLDA == 1)
				query = ConsultasBD.consultaThreads(nomeAPI, tipoArquivo, consideraApenasComRespostaAceita);
			else if (tipoDeAplicacaoDoLDA == 2 || tipoDeAplicacaoDoLDA == 3) {
				query = ConsultasBD.consultaThreadsPorIdsDePerguntas(tipoArquivo, consideraApenasComRespostaAceita,
						listIdThreadsQuePossuemParesBemColocados);
			}

			// Executa a query
			ResultSet rs = cbd.executaQuery(query);

			int idPostAtual = -1;
			String textoDoc = "";
			// int count = 0;
			String tituloDaPerguntaAtual = "";
			String corpoDaPerguntaAtual = "";
			ClassificadorHowTo classificador = new ClassificadorHowTo();

			// Iremos gerar aruivos que posteriormente serao usados para aplicar o LDA
			// O nome da API NAO sera passado no construtor, pois NAO sera considerado stop
			// word
			ManipuladorDeTexto mt = new ManipuladorDeTexto(nomeAPI, true);

			(new File(nomePasta + "/corpus/")).mkdir();

			int countNroThreadsConsideradas = 0;
			while (rs.next()) {
				int idPergunta = Integer.parseInt(rs.getString("id_pergunta"));
				String tituloDaPergunta = rs.getString("titulo_pergunta");
				String corpoDaPergunta = rs.getString("corpo_pergunta");

				// Caso estejamos iniciando uma nova thread
				if (idPergunta != idPostAtual) {

					if (idPostAtual != -1) {

						String textoTratado = mt.removeTagsIndesejadas(textoDoc, consideraCodigo);

						if (tipoDeProcessamento == 1)
							textoTratado = mt.removeStopWordsEFazStemming(textoTratado);
						else if (tipoDeProcessamento == 2)
							textoTratado = mt.aplicaChunking(textoTratado);
						else if (tipoDeProcessamento == 3)
							textoTratado = mt.obtemSubstantivos(textoTratado);

						if (!usaApenasHOw || (usaApenasHOw
								&& classificador.classficaComoHowTO(tituloDaPerguntaAtual, corpoDaPerguntaAtual))) {
							// O nome do arquivo eh o id da pergunta da thread
							BufferedWriter out = new BufferedWriter(
									new FileWriter(nomePasta + "/corpus/" + idPostAtual + ".txt"));
							out.write(textoTratado);
							out.close();
							// System.out.println(count);
							countNroThreadsConsideradas++;
						}
					}

					idPostAtual = idPergunta;
					tituloDaPerguntaAtual = tituloDaPergunta;
					corpoDaPerguntaAtual = corpoDaPergunta;

					if (!consideraTitulo)
						textoDoc = rs.getString("body") + "\n";
					else {
						String strTitulo = "";
						for (int i = 0; i < nroDeRepeticaoDoTitulo; i++) {
							strTitulo += tituloDaPerguntaAtual + "\n";
						}

						textoDoc = strTitulo + "\n" + rs.getString("body") + "\n";
					}
					// count++;
				}
				// Caso ainda estejamos dentro da mesma thread
				else {
					textoDoc += rs.getString("body") + "\n";
					// count++;
				}

				// String count = rs.getString("body");

				// System.out.println(count);
			}

			String textoTratado = mt.removeTagsIndesejadas(textoDoc, consideraCodigo);

			if (tipoDeProcessamento == 1)
				textoTratado = mt.removeStopWordsEFazStemming(textoTratado);
			else if (tipoDeProcessamento == 2)
				textoTratado = mt.aplicaChunking(textoTratado);
			else if (tipoDeProcessamento == 3)
				textoTratado = mt.obtemSubstantivos(textoTratado);

			if (!usaApenasHOw || (usaApenasHOw
					&& classificador.classficaComoHowTO(tituloDaPerguntaAtual, corpoDaPerguntaAtual))) {
				BufferedWriter out = new BufferedWriter(new FileWriter(nomePasta + "/corpus/" + idPostAtual + ".txt"));
				out.write(textoTratado);
				out.close();
				countNroThreadsConsideradas++;
			}

			System.out.println("Nro perguntas consideradas = " + countNroThreadsConsideradas);

			// fecha a conexao com o BD
			cbd.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Meoto responsavel por construir os pipes/filtros que processarao o texto
	// antes de aplicarmos o LDA
	public static Pipe buildPipe(Boolean usaBigrans) {

		ArrayList pipeList = new ArrayList();

		pipeList.add(new Input2CharSequence("UTF-8"));

		// Expressao regular para aceitar "o que vier" como token, pois o luceno ja fez
		// a tokenizacao
		pipeList.add(new CharSequence2TokenSequence(Pattern.compile("\\S+")));
		pipeList.add(new TokenSequenceLowercase());

		if (usaBigrans) {
			int arrayGramSizes[] = { 1, 2 };
			pipeList.add(new TokenSequenceNGrams(arrayGramSizes));
		}

		// Comentando esse filtro, pois ja removemos stop words pelo lucene
		// pipeList.add( new TokenSequenceRemoveStopwords(new File("D:/mestrado/estudo
		// dirigido/Dissertação/LDA/mallet-2.0.7/mallet-2.0.7/stoplists/en.txt"),
		// "UTF-8", false, false, false) );
		pipeList.add(new TokenSequence2FeatureSequence());

		return new SerialPipes(pipeList);

	}
}
