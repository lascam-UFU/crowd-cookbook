package br.ufu.facom.lsa.MetricasDeAvaliacao;

import java.util.ArrayList;
import java.util.List;

import cc.mallet.classify.tui.Calo2Classify;

public class Main {
	public static void main(String[] args) {
		calculaInformationGain();
	}

	private static void calculaInformationGain() {
		//f1 f2 f3 f4 f5 f6 f7 f8 classe
		int valoresPossiveisParaClasse[] = {0, 1}; 
		int obj1[] = {1,4,9,5,3,1,0,7,1};
		int obj2[] = {3,1,2,4,2,5,0,6,1};
		int obj3[] = {1,4,7,4,1,2,0,6,1};
		int obj4[] = {2,6,7,2,8,7,1,7,0};
		int obj5[] = {9,2,7,2,8,8,0,1,0};
		int obj6[] = {8,8,0,1,5,2,1,9,0};
		int obj7[] = {1,0,0,1,4,2,0,7,0};
		int obj8[] = {1,4,7,4,1,2,0,6,1};
		List<int[]> listaObjetos = new ArrayList<int[]>();
		listaObjetos.add(obj1);
		listaObjetos.add(obj2);
		listaObjetos.add(obj3);
		listaObjetos.add(obj4);
		listaObjetos.add(obj5);
		listaObjetos.add(obj6);
		listaObjetos.add(obj7);
		listaObjetos.add(obj8);
		
		//IG(listaObjetos, feature) = entropia(listaObjetos)
		double entropiaGeral = calculaEntropia(listaObjetos, valoresPossiveisParaClasse);
		System.out.println(entropiaGeral);
		double entropiaParcial = 0;
		
		int nroDeFeatures = obj1.length-1;
		
		for(int i=0; i< nroDeFeatures; i++){
			entropiaParcial = 0;
			List<Double> listaValoresPossiveisFeature = descobreValoresPossiveisFeature(listaObjetos, i);
			
			for(int j=0; j <listaValoresPossiveisFeature.size(); j++ ){
				List<int[]> listaObjetosComValorEspecificoEmFeature = constroiSubConjuntoComValorEspecificoEmFeaure(listaObjetos, listaValoresPossiveisFeature.get(j), i);
				entropiaParcial += calculaEntropia(listaObjetosComValorEspecificoEmFeature, valoresPossiveisParaClasse);
			}
			
			System.out.println("IG para feature " + i + ": " + (entropiaGeral-entropiaParcial));
			
		}
		
		
		
		
	}

	private static List<int[]> constroiSubConjuntoComValorEspecificoEmFeaure(
			List<int[]> listaObjetos, Double valorFeature, int indiceFeature) {
		List<int[]> listaObjetosSelecionados = new ArrayList<int[]>();
		
		for(int i=0; i< listaObjetos.size(); i++){
			int objeto[] = listaObjetos.get(i);
			if(objeto[indiceFeature] == valorFeature)
				listaObjetosSelecionados.add(objeto);
		}
		
		return listaObjetosSelecionados;
	}

	private static List<Double> descobreValoresPossiveisFeature(
			List<int[]> listaObjetos, int indiceFeature) {
		
		List<Double> listaValoresPossiveis = new ArrayList<Double>();
		for(int i=0; i< listaObjetos.size(); i++){
			int objeto[] = listaObjetos.get(i);
			double valorFeature = objeto[indiceFeature];
			if(!listaValoresPossiveis.contains(valorFeature))
				listaValoresPossiveis.add(valorFeature);
		}
		return listaValoresPossiveis;
	}

	private static double calculaEntropia(List<int[]> listaObjetos,
			int[] valoresPossiveisParaClasse) {
		double entropia = 0;
		
		for(int i=0;i < valoresPossiveisParaClasse.length; i++){
			int classe = valoresPossiveisParaClasse[i];
			int countClasse = 0;
			
			for(int j=0; j< listaObjetos.size(); j++){
				int objeto[] = listaObjetos.get(j);
				if(objeto[objeto.length-1] == classe){
					countClasse++;
				}
			}
			
			double prob = countClasse/(double)listaObjetos.size();
			if(prob != 0)
				entropia += -(prob*(Math.log(prob)/Math.log(2)));
		}
		
		
		
		return entropia;
	}
	
	private static double calculaEntropia(
			List<Integer> listaGeral, boolean normalizaEntropa) {
		
		double soma = 0;
		for(int i=0; i< listaGeral.size(); i++){
			soma += listaGeral.get(i);
		}
		//TODO soma = 1, ou seja, todos os elementos da lista sao zero (iguais), por isso a entropia é um
		if(soma == 0)
			return 1;
		int tamanho = listaGeral.size();
		double entropiaTotal = 0;
		
		for(int i=0; i< listaGeral.size(); i++){
			double prob =  listaGeral.get(i)/(double)soma;
			if(prob != 0){
				entropiaTotal += prob*(Math.log(prob)/Math.log(2));
			}
		}
		
		if(normalizaEntropa)
			return -entropiaTotal/tamanho;
		else
			return -entropiaTotal;
	}
	
	
}
