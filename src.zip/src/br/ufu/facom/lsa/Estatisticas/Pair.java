package br.ufu.facom.lsa.Estatisticas;

public class Pair {
	private double score;
	private double idadePar;
	private int idPergunta;
	private int idResposta;
	private int scorePergunta;
	private int scoreResposta;
	
	public Pair(double score, double idade, int idPergunta, int idResposta, int scorePergunta, int scoreResposta) {
		this.score = score;
		this.idadePar = idade;
		this.idPergunta = idPergunta;
		this.idResposta = idResposta;
		this.scorePergunta = scorePergunta;
		this.scoreResposta = scoreResposta;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public double getIdade() {
		return idadePar;
	}

	public void setIdade(double idade) {
		this.idadePar = idade;
	}

	public int getIdPergunta() {
		return idPergunta;
	}

	public void setIdPergunta(int idPergunta) {
		this.idPergunta = idPergunta;
	}

	public int getIdResposta() {
		return idResposta;
	}

	public void setIdResposta(int idResposta) {
		this.idResposta = idResposta;
	}

	public int getScorePergunta() {
		return scorePergunta;
	}

	public void setScorePergunta(int scorePergunta) {
		this.scorePergunta = scorePergunta;
	}

	public int getScoreResposta() {
		return scoreResposta;
	}

	public void setScoreResposta(int scoreResposta) {
		this.scoreResposta = scoreResposta;
	}

	
}
