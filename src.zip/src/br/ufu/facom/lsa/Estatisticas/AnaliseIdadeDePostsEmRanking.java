//Classe em que vamos analiser em um ranqueamento por score, a idade dos posts que estao no topo deste ranquemento

package br.ufu.facom.lsa.Estatisticas;

import java.io.InputStream;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.zip.GZIPInputStream;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;
import br.ufu.facom.lsa.TesteHowTo.ClassificadorHowTo;

public class AnaliseIdadeDePostsEmRanking {

	public static void main(String[] args) {
		try{
			int nroTopRanking = 300;
			int idadeMaxima = 70;
			
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();

			List<Pair> listPares = new ArrayList<Pair>();

			List<String> listTags = new ArrayList<String>();
			listTags.add("android");
			String query = ConsultasBD.consultaPerguntasAleatoriasEmCategorias(listTags);
			System.out.println(query);
			ResultSet rs = cbd.executaQuery(query);
			System.out.println("query executada");
			List<Integer> listaIdPerguntas = new ArrayList<Integer>();
			while(rs.next()){
				int postid = rs.getInt("postid");
				listaIdPerguntas.add(postid);
			}

			ClassificadorHowTo classificador = new ClassificadorHowTo();

			int indiceAtual = 0;
			while(indiceAtual < listaIdPerguntas.size()){
				int idPergunta = listaIdPerguntas.get(indiceAtual);
				//System.out.println(indiceAtual);
				indiceAtual++;

				String q1 = ConsultasBD.consultaCorpo(idPergunta);
				ResultSet r1 = cbd.executaQuery(q1);
				r1.next();
				String corpoPergunta = r1.getString("body");

				q1 = ConsultasBD.consultaTitulo(idPergunta);
				r1 = cbd.executaQuery(q1);
				r1.next();
				String tituloPergunta = r1.getString("title");
				if(!classificador.classficaComoHowTO(tituloPergunta, corpoPergunta)){
					//System.out.println((indiceAtual-1) + " nao eh howto");
					continue;
				}

				//Agora vamos recuperar todas as respostas associadas a pergunta
				String query1 = ConsultasBD.consultaRespostasDePergunta(idPergunta);
				ResultSet rsInterno = cbd.executaQuery(query1);
				while(rsInterno.next()){
					int idResposta = rsInterno.getInt("id");

					int scorePergunta = recuperaScore(idPergunta, cbd);
					int scoreResposta = recuperaScore(idResposta, cbd);

					String query2 = "SELECT TIMESTAMPDIFF(DAY, (SELECT pq.creationdate from posts pq where pq.id = " + idPergunta + "), STR_TO_DATE('Sep/6/2013 23:59 PM', '%M/%d/%Y %H:%i')) idade ";
					ResultSet rsInterno2 = cbd.executaQuery(query2);
					rsInterno2.next();
					int idadePergunta = rsInterno2.getInt("idade");
					

					query2 = "SELECT TIMESTAMPDIFF(DAY, (SELECT pq.creationdate from posts pq where pq.id = " + idResposta + "), STR_TO_DATE('Sep/6/2013 23:59 PM', '%M/%d/%Y %H:%i')) idade ";
					rsInterno2 = cbd.executaQuery(query2);
					rsInterno2.next();
					int idadeResposta = rsInterno2.getInt("idade");
					
					double idadeMedia = (idadePergunta + idadeResposta)/2.0;

					Pair p = new Pair(calculaMetricaAlvo(scorePergunta, scoreResposta), idadeMedia, idPergunta, idResposta, scorePergunta, scoreResposta);

					listPares.add(p);
				}
			}	

			System.out.println("listPares.size() " + listPares.size());
			ComparatorPairsScore cp = new ComparatorPairsScore();
			Collections.sort(listPares, cp);

			//System.out.println("Imprimindo ordenacao por score (maior -> menor)");

			int nroDeParesNovos = 0;
			List<String> listIdParesTopAntes = new ArrayList<String>();
			//Isso aqui eh pra verficar se existem pares "novos" no topo do ranking
			for(int i=0; i< nroTopRanking ; i++){
				//System.out.println(listPares.get(i).getIdPergunta() + " " + listPares.get(i).getIdResposta() + " " + listPares.get(i).getIdade() + " " + listPares.get(i).getScore());
				listIdParesTopAntes.add(listPares.get(i).getIdPergunta() + "-" + listPares.get(i).getIdResposta());
				
				if(listPares.get(i).getIdade() <= idadeMaxima ){
					nroDeParesNovos++;
				}
			}
			
			System.out.println("nroDeParesJovens = " + nroDeParesNovos);
			
			List<Integer> listaPosicoesAntes = new ArrayList<Integer>();
			for(int i=0; i< listPares.size(); i++){
				if(listPares.get(i).getIdade() <= idadeMaxima){
					listaPosicoesAntes.add(i);
				}
			}
			
			System.out.println("Media da posicao dos pares jovens = " + calculaMedia(listaPosicoesAntes));
			
			//ComparatorPairsIdade cp2 = new ComparatorPairsIdade();
			//Collections.sort(listPares, cp2);

			//System.out.println("Imprimindo ordenacao por idade (menor -> maior)");

			//Isso aqui eh pra verficar se existem pares "novos" no topo do ranking
			/*for(int i=0; i< 100; i++){

				System.out.println(listPares.get(i).getIdPergunta() + " " + listPares.get(i).getIdResposta()  + " " + listPares.get(i).getIdade() + " " + listPares.get(i).getScore() + " " + listPares.get(i).getScorePergunta() + " " + listPares.get(i).getScoreResposta());
			}*/

			//query = ConsultasBD.consultaPerguntasAleatoriasEmCategorias(listTags);
			//System.out.println(query);
			//ResultSet rs = cbd.executaQuery(query);
			
			HashMap<Integer, Integer> mapScoreAtualizado = new HashMap<Integer, Integer>();
			for(int i=0; i< listPares.size(); i++){
				System.out.println(i);
				List<Integer> listIdsPar = new ArrayList<Integer>();

				int idPergunta = listPares.get(i).getIdPergunta();
				int idResposta = listPares.get(i).getIdResposta();

				listIdsPar.add(idPergunta);
				listIdsPar.add(idResposta);

				for(int p=0; p< 2; p++){

					int idPost = listIdsPar.get(p);
					
					
					query = "select score from posts_new where id = " + idPost;
					ResultSet rsInterno2 = cbd.executaQuery(query);
					if(rsInterno2.next()){
						int scorePost = rsInterno2.getInt("score");
						mapScoreAtualizado.put(idPost, scorePost);
					}
					
					
				}
			}
			
			/*System.setProperty("http.proxyHost", "proxy.ufu.br");
			System.setProperty("http.proxyPort", "3128");
			System.setProperty("https.proxyHost", "proxy.ufu.br");
			System.setProperty("https.proxyPort", "3128");


			HashMap<Integer, Integer> mapScoreAtualizado = new HashMap<Integer, Integer>();
			for(int i=0; i< listPares.size(); i++){
				System.out.println(i);
				List<Integer> listIdsPar = new ArrayList<Integer>();

				int idPergunta = listPares.get(i).getIdPergunta();
				int idResposta = listPares.get(i).getIdResposta();

				listIdsPar.add(idPergunta);
				listIdsPar.add(idResposta);

				for(int p=0; p< 2; p++){

					int idPost = listIdsPar.get(p);

					if(!mapScoreAtualizado.containsKey(idPost)){
						String comando = "http://api.stackexchange.com/2.1/posts/" + idPost + "?order=desc&sort=activity&site=stackoverflow&key=1BAOPNIyGbCybVi4U0P5Ww((";
						//System.out.println(comando);

						URL url = new URL(comando);
						url.openConnection();
						InputStream is = null;

						while(true){
							try{
								is = url.openStream();
								break;
							}catch(Exception e){
								Thread.sleep(120);
							}
						}

						GZIPInputStream ginstream =new GZIPInputStream(is);
						String respostaDescompactada = "";
						byte[] buf = new byte[1024];
						int len;
						while ((len = ginstream.read(buf)) > 0) 
							respostaDescompactada += new String(buf, 0, len); 


						//System.out.println(respostaDescompactada);

						int a = 0;
						int b =a;
						//String strParcial[] = respostaDescompactada.split("\\{\"items\":")[1].split(",\"quota_remaining\":");
						String strParcial[] = respostaDescompactada.split("\\{\"items\":")[1].split(",\"has_more\":");
						String jsonStr = strParcial[0];
						//System.out.println(jsonStr);
						String strResto = strParcial[1];
						// System.out.println(strResto);
						//if(strResto.split("\"has_more\":")[1].contains("true")){
						//	 temMaisPaginas =  true;
						//	 pageNum++;
						//}


						JSONTokener tokener = new JSONTokener(jsonStr);
						JSONArray finalResult = new JSONArray(tokener);

						int nroElementos = finalResult.length();
						int nroSemIduser = 0;
						for(int k=0; k< nroElementos; k++){
							JSONObject jsob = finalResult.getJSONObject(k);
							Integer score = (Integer)jsob.get("score");
							mapScoreAtualizado.put(idPost, score);
						}

					}
				}
			}*/
			
			List<Pair> listPairAtualizado = new ArrayList<Pair>();
			for(int i=0; i< listPares.size();i++){
				
				int idPergunta = listPares.get(i).getIdPergunta();
				int idResposta = listPares.get(i).getIdResposta();
				
				if(mapScoreAtualizado.containsKey(idPergunta) && mapScoreAtualizado.containsKey(idResposta)){
					
					int scorePergunta = mapScoreAtualizado.get(idPergunta);
					int scoreResposta = mapScoreAtualizado.get(idResposta);
					
					String query2 = "SELECT TIMESTAMPDIFF(DAY, (SELECT pq.creationdate from posts pq where pq.id = " + idPergunta + "), STR_TO_DATE('Sep/6/2013 23:59 PM', '%M/%d/%Y %H:%i')) idade ";
					ResultSet rsInterno2 = cbd.executaQuery(query2);
					rsInterno2.next();
					int idadePergunta = rsInterno2.getInt("idade");
					

					query2 = "SELECT TIMESTAMPDIFF(DAY, (SELECT pq.creationdate from posts pq where pq.id = " + idResposta + "), STR_TO_DATE('Sep/6/2013 23:59 PM', '%M/%d/%Y %H:%i')) idade ";
					rsInterno2 = cbd.executaQuery(query2);
					rsInterno2.next();
					int idadeResposta = rsInterno2.getInt("idade");
					
					double idadeMedia = (idadePergunta + idadeResposta)/2.0;

					Pair p = new Pair(calculaMetricaAlvo(scorePergunta, scoreResposta), idadeMedia, idPergunta, idResposta, scorePergunta, scoreResposta);
					listPairAtualizado.add(p);

				}
				
			}

			//System.out.println("tamanho da lista original de pares:" + listPares.size());
			//System.out.println("tamanho da lista atualizada de pares:" + listPairAtualizado.size());
			
			//Vamos ordernar a nova lista pelo score e verificar diferencas no top 100
			
			Collections.sort(listPairAtualizado, cp);

			//System.out.println("Imprimindo ordenacao por score (maior -> menor)");

			nroDeParesNovos = 0;
			//Isso aqui eh pra verficar se existem pares "novos" no topo do ranking
			List<String> listIdParesTopDepois = new ArrayList<String>();
			for(int i=0; i< nroTopRanking ; i++){
				//System.out.println(listPairAtualizado.get(i).getIdPergunta() + " " + listPairAtualizado.get(i).getIdResposta() + " " + listPairAtualizado.get(i).getIdade() + " " + listPairAtualizado.get(i).getScore());
				listIdParesTopDepois.add(listPairAtualizado.get(i).getIdPergunta() + "-" + listPairAtualizado.get(i).getIdResposta());
				
				if(listPairAtualizado.get(i).getIdade() <= idadeMaxima){
					nroDeParesNovos++;
				}
			}
			
			System.out.println("nroDeParesJovens = " + nroDeParesNovos);

			int countIguais = 0;
			for(int i=0; i < nroTopRanking ; i++){
				String codigoAtual = listPares.get(i).getIdPergunta() + "-" + listPares.get(i).getIdResposta();
				
				for(int j=0; j < nroTopRanking; j++){
					String codigoAtual2 = listPairAtualizado.get(j).getIdPergunta() + "-" + listPairAtualizado.get(j).getIdResposta();
					if(codigoAtual.equals(codigoAtual2)){
						countIguais++;
						break;
					}
						
				}
			}
			System.out.println("Pares que coincidem:" + countIguais);
			
			List<Integer> listaPosicoesDepois = new ArrayList<Integer>();
			for(int i=0; i< listPairAtualizado.size(); i++){
				if(listPairAtualizado.get(i).getIdade() <= idadeMaxima){
					listaPosicoesDepois.add(i);
				}
			}
			
			System.out.println("Media da posicao dos pares jovens = " + calculaMedia(listaPosicoesDepois));
			
			
		}catch(Exception e){
			e.printStackTrace();
		}


	}
	private static int recuperaScore(int idPost, ConexaoDB cbd) {
		try{
			//ConexaoDB cbd = new ConexaoDB();
			//cbd.conectaAoBD();
			String query = ConsultasBD.consultaScore(idPost);
			ResultSet rs = cbd.executaQuery(query);
			if(rs.next()){
				int score = Integer.parseInt(rs.getString("score"));
				return score; 
			}
			//fecha a conexao com o BD
			//cbd.close();
		}catch(Exception e){
			e.printStackTrace();
		}

		return 0;
	}

	private static double calculaMetricaAlvo(double scorePergunta, double scoreResposta){
		//Vou testar media ponderada: peso da pergunta = 3, peso da resposta = 4
		int pesoPergunta = 3;
		int pesoResposta = 7;

		double mediaScore = (pesoPergunta*scorePergunta + pesoResposta*scoreResposta)/(double)(pesoPergunta+pesoResposta);

		return mediaScore;
	}
	
	private static double calculaMedia(List<Integer> values){
		if(values.isEmpty())
			return 0;
		
		double sum=0;
		for(int i=0; i< values.size(); i++){
			sum += values.get(i);
		}
		return sum/(double)values.size();
	}

}


