/* 
 * Classe reponsavel por calcular algumas estatisticas do SO (que nao sao possiveis calcular por SQL)
 */

package br.ufu.facom.lsa.Estatisticas;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import com.mysql.jdbc.PreparedStatement;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;
import br.ufu.facom.lsa.Lda.ManipuladorDeTexto;
import br.ufu.facom.lsa.TesteHowTo.ClassificadorHowTo;

public class CalculadorDeEstatisticas {
	private ManipuladorDeTexto mt;
	
	public CalculadorDeEstatisticas() {
		this.mt = new ManipuladorDeTexto("", true);
	}
	
	//Metodo responsavel por calcular o tamanho medio dos snipets presentes nos posts bem como outras estatisticas
	public void calculaEstatisticas(){
		try{
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();
			
			//Recupera a querry a ser executada, de acordo com a API
			//Caso seja passado "" como paramentro, serao calculados o tamanho medio dos snipets de todas os posts (independente de API)
			//Iremos recuperar a query resonsavel por recuperar o corpo de todos os posts que possuem codigo fone
			String query = ConsultasBD.consultaCorpoComCodigo("");
			System.out.println(query);
			//Executa a query
			ResultSet rs = cbd.executaQuery(query);
			int nroPerguntasComCodigo = 0;
			int nroRespostasComCodigo = 0;
			int somaTamanhoCodigoPerguntas = 0;
			int somaTamanhoCodigoRespostas = 0;
			int somaTamanho = 0;
			//Variavel que se estiver como TRUE, ira considerar apenas perguntas do tipo how-to
			boolean fitraHowTo = false;
			ClassificadorHowTo classificador = new ClassificadorHowTo();
					
			List<Post> listaPostsDaThread = new ArrayList<Post>();
			int idPostAtual = -1;
			while (rs.next()) {
				int idPergunta = Integer.parseInt(rs.getString("id_pergunta"));
				int idPost = Integer.parseInt(rs.getString("id_post"));
				if(idPost == 7598){
					int a = 0;
					int  b= a;
					
				}
				
				String corpo = rs.getString("body");
				String titulo = rs.getString("title");
				int viewCount = Integer.parseInt(rs.getString("viewcount"));
				
				if(fitraHowTo && !classificador.classficaComoHowTO(titulo, corpo))
					continue;
								
				int postTypeId = Integer.parseInt(rs.getString("tipo_post"));
				int score = Integer.parseInt(rs.getString("score"));
				String reputacaoStr =  rs.getString("reputation");
				String tags = rs.getString("tags");
				int nroTags = 0;
				for (int i = 0; i < tags.length(); i++)
				    if (tags.charAt(i) == '<')
				    	nroTags++;
				
				int reputacao = 0;
				if(reputacaoStr != null)
					reputacao = Integer.parseInt(rs.getString("reputation"));
			
				String textoCodigos = mt.getCodigoPreCode(corpo).toLowerCase();
				int nroDeSnippets = mt.getNumeroDeTrechosDeCodigo(corpo);
				String[] lines = textoCodigos.split("\r\n|\r|\n");
				int tamanhoCodigo = 0;
				if(!textoCodigos.equals(""))
					tamanhoCodigo = lines.length;
				
				int tamanhoCorpo = corpo.split("\r\n|\r|\n").length;
				
				somaTamanho += tamanhoCodigo;
				if(postTypeId == 1 && tamanhoCodigo > 0){
					nroPerguntasComCodigo++;
					somaTamanhoCodigoPerguntas += tamanhoCodigo;
				}
					
				else if(postTypeId == 2 && tamanhoCodigo > 0){
					nroRespostasComCodigo++;
					somaTamanhoCodigoRespostas += tamanhoCodigo;
				}
				
				//Caso estejamos iniciando uma nova thread temos que fazer o processamento dos posts da thread anterior
				if(idPergunta != idPostAtual){
					
					//Caso estejamos iniciando uma nova thread (com excecao da primeiro, temos que finalizar o processamento da anterior)
					if(idPostAtual != -1){
						int scoreMinDaThread = Integer.MAX_VALUE;
						int scoreMaxDaThread = Integer.MIN_VALUE;
						
						for(int i=0; i < listaPostsDaThread.size(); i++){
							if(listaPostsDaThread.get(i).getScore() < scoreMinDaThread)
								scoreMinDaThread = listaPostsDaThread.get(i).getScore();
							
							if(listaPostsDaThread.get(i).getScore() > scoreMaxDaThread)
								scoreMaxDaThread = listaPostsDaThread.get(i).getScore();
						}
						
						for(int i=0; i < listaPostsDaThread.size(); i++){
							Post p = listaPostsDaThread.get(i);
							int denominador = scoreMaxDaThread-scoreMinDaThread;
							if(denominador == 0)
								p.setScoreNormalizado(0);
							else
								p.setScoreNormalizado((p.getScore()-scoreMinDaThread)/(double)(scoreMaxDaThread-scoreMinDaThread));
							
							System.out.println(p.getIdPost() + "\t" + p.getPostTypeId() + "\t" + p.getScore() + "\t" + p.getTamanhoCodigo() + "\t" + p.getNroDeSnippets() + "\t" + p.getScoreNormalizado() + "\t" + p.getReputacaoDoUsuario() + "\t" + p.getTamanhoPost() + "\t" + p.getNroTags() + "\t" + p.getViewCount());
						}
					}
					
					idPostAtual = idPergunta;
					listaPostsDaThread.clear();
				}
				Post p = new Post(idPost, postTypeId, score, tamanhoCodigo, nroDeSnippets, 0, reputacao, tamanhoCorpo, nroTags, viewCount);
				listaPostsDaThread.add(p);
				
			}
			
			//Temos que fazer o processamento da ultima thread
			int scoreMinDaThread = Integer.MAX_VALUE;
			int scoreMaxDaThread = Integer.MIN_VALUE;
			
			for(int i=0; i < listaPostsDaThread.size(); i++){
				if(listaPostsDaThread.get(i).getScore() < scoreMinDaThread)
					scoreMinDaThread = listaPostsDaThread.get(i).getScore();
				
				if(listaPostsDaThread.get(i).getScore() > scoreMaxDaThread)
					scoreMaxDaThread = listaPostsDaThread.get(i).getScore();
			}
			
			for(int i=0; i < listaPostsDaThread.size(); i++){
				Post p = listaPostsDaThread.get(i);
				int denominador = scoreMaxDaThread-scoreMinDaThread;
				if(denominador == 0)
					p.setScoreNormalizado(0);
				else
					p.setScoreNormalizado((p.getScore()-scoreMinDaThread)/(double)(scoreMaxDaThread-scoreMinDaThread));
				
				System.out.println(p.getIdPost() + "\t" + p.getPostTypeId() + "\t" + p.getScore() + "\t" + p.getTamanhoCodigo() + "\t" + p.getNroDeSnippets() + "\t" + p.getScoreNormalizado() + "\t" + p.getReputacaoDoUsuario() + "\t" + p.getTamanhoPost() + "\t" + p.getNroTags() + "\t" + p.getViewCount());
			}
			
			System.out.println("nro de perguntas com codigo: " + nroPerguntasComCodigo);
			System.out.println("nro de respostas com codigo: " + nroRespostasComCodigo);
			System.out.println("tamanho medio do codigo nas perguntas com codigo: " + somaTamanhoCodigoPerguntas/(double)nroPerguntasComCodigo);
			System.out.println("tamanho medio do codigo nas respostas com codigo: " + somaTamanhoCodigoRespostas/(double)nroRespostasComCodigo);
			System.out.println("tamanho medio do codigo geral (considerando perguntas e respostas com codigo): " + somaTamanho/(double)(nroRespostasComCodigo+nroPerguntasComCodigo));
			
			
			//fecha a conexao com o BD
			cbd.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void calculaTempoParaResposta(){
		try{
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();
			
			//Recupera a querry que recupera o ID de todas pergutas que possuem pelo menos 1 resposta
			String query = ConsultasBD.consultaPerguntasComResposta();
			System.out.println(query);
			List<Integer> listaTempoParaPrimeiraResposta = new ArrayList<Integer>();
			//Executa a query
			ResultSet rs = cbd.executaQuery(query);
			while (rs.next()) {
				int idPergunta = Integer.parseInt(rs.getString("id"));
				String queryTempoReposta = ConsultasBD.consultaTempoAtePrimeiraResposta(idPergunta);
				//System.out.println(queryTempoReposta);
				ResultSet rsTempoResposta = cbd.executaQuery(queryTempoReposta);
				rsTempoResposta.next();
				int segundosParaResposta = Integer.parseInt(rsTempoResposta.getString("tempo"));
				listaTempoParaPrimeiraResposta.add(segundosParaResposta);
			}
			
			Collections.sort(listaTempoParaPrimeiraResposta);
			
			System.out.println("Nro de perguntas com resposta: " + listaTempoParaPrimeiraResposta.size());
			double medianaTempos = calculataMediana(listaTempoParaPrimeiraResposta);
			double mediaTempos = calculateMedia(listaTempoParaPrimeiraResposta);
			System.out.println("Media: " + mediaTempos);
			System.out.println("Mediana: " + medianaTempos);
			
			//Vamos calcular o numero de perguntas que recebem a primeira resposta dentro de uma hora
			int count = 0;
			for(int i=0; i< listaTempoParaPrimeiraResposta.size(); i++){
				//1 hora = 60 min = 3600 segundos
				if(listaTempoParaPrimeiraResposta.get(i) <= 3600)
					count++;
			}
			
			System.out.println("Nro de perguntas com resposta em no maximo 1 hora: " + count);
			
			//Vamos calcular o numero de perguntas que recebem a primeira resposta dentro de um dia
			count = 0;
			for(int i=0; i< listaTempoParaPrimeiraResposta.size(); i++){
				//1 dia = 24hrs = 1440 min = 86400 segundos
				if(listaTempoParaPrimeiraResposta.get(i) <= 86400)
					count++;
			}
			
			System.out.println("Nro de perguntas com resposta em no maximo 1 dia: " + count);
			
			//Recupera a querry que recupera o ID de todas pergutas que possuem resoista aceita
			String queryPerguntasComRespostaAceita = ConsultasBD.consultaPerguntasComRespostaAceita();
			List<Integer> listaTempoParaRespostaAceita = new ArrayList<Integer>();
			//Executa a query
			ResultSet rsRespostaAceita = cbd.executaQuery(queryPerguntasComRespostaAceita);
			while (rsRespostaAceita.next()) {
				
				int idPergunta = Integer.parseInt(rsRespostaAceita.getString("id"));
				int idResposta = Integer.parseInt(rsRespostaAceita.getString("idResposta"));
				//System.out.println(idPergunta + " " + idResposta);
				String queryTempoReposta = ConsultasBD.consultaTempoAteRespostaAceita(idPergunta, idResposta);
				//System.out.println(queryTempoReposta);
				ResultSet rsTempoResposta = cbd.executaQuery(queryTempoReposta);
				if(rsTempoResposta.next()){
					int segundosParaResposta = Integer.parseInt(rsTempoResposta.getString("tempo"));
					listaTempoParaRespostaAceita.add(segundosParaResposta);
				}
			}
			
			Collections.sort(listaTempoParaRespostaAceita);
			
			System.out.println("Nro de perguntas com resposta aceita: " + listaTempoParaRespostaAceita.size());
			double medianaTemposRespostaAceita = calculataMediana(listaTempoParaRespostaAceita);
			double mediaTemposRespostaAceita  = calculateMedia(listaTempoParaRespostaAceita);
			System.out.println("Media: " + mediaTemposRespostaAceita);
			System.out.println("Mediana: " + medianaTemposRespostaAceita);
			
			//Vamos calcular o numero de perguntas que recebem a resposta aceita dentro de uma hora
			count = 0;
			for(int i=0; i< listaTempoParaRespostaAceita.size(); i++){
				//1 hora = 3600 segs
				if(listaTempoParaRespostaAceita.get(i) <= 3600)
					count++;
			}
			
			System.out.println("Nro de perguntas com resposta aceita em no maximo 1 hora: " + count);
			
			//Vamos calcular o numero de perguntas que recebem a resposta aceita dentro de um dia
			count = 0;
			for(int i=0; i< listaTempoParaRespostaAceita.size(); i++){
				//1 dia = 86400 segs
				if(listaTempoParaRespostaAceita.get(i) <= 86400)
					count++;
			}
			
			System.out.println("Nro de perguntas com resposta aceita em no maximo 1 dia: " + count);
			//fecha a conexao com o BD*/
			cbd.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private double calculataMediana(List<Integer> listaTempos) {
		if (listaTempos.size() % 2 == 1)
			return listaTempos.get((listaTempos.size()+1)/2-1);
		else
		{
			double lower = listaTempos.get(listaTempos.size()/2-1);
			double upper = listaTempos.get(listaTempos.size()/2);

			return (lower + upper) / 2.0;
		}
	}
	
	private double calculateMedia(List<Integer> values){
		
		double sum=0;
		for(int i=0; i< values.size(); i++){
			sum += values.get(i);
		}
		return sum/(double)values.size();
	}
}
