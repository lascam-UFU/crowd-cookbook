/* 
 * Classe reponsavel por testar a classe resposavel por calcular estatisticas do SO
 */

package br.ufu.facom.lsa.Estatisticas;

public class Main {

	public static void main(String[] args) {
		CalculadorDeEstatisticas ce = new CalculadorDeEstatisticas();
		ce.calculaEstatisticas();
		
		//ce.calculaTempoParaResposta();

	}
}
