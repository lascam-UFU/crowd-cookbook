package br.ufu.facom.lsa.Estatisticas;

import java.sql.Date;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;

public class AnaliseIdadePostsPorFaixa {

	public static void main(String args[]){
		try{
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();

			List<String[]> listaApis = new ArrayList<String[]>();
			String api1[] = {"sqlite"};
			listaApis.add(api1);
			String api2[] = {"qt"};
			listaApis.add(api2);
			String api3[] = {"swt"};
			listaApis.add(api3);
			String api4[] = {"stl"};
			listaApis.add(api4);
			String api5[] = {"junit"};
			listaApis.add(api5);
			String api6[] = {"log4net"};
			listaApis.add(api6);
			String api7[] = {"awt"};
			listaApis.add(api7);
			String api8[] = {"boost"};
			listaApis.add(api8);
			String api9[] = {"matplotlib"};
			listaApis.add(api9);
			String api10[] = {"backbone.js"};
			listaApis.add(api10);
			String api11[] = {"swing"};
			listaApis.add(api11);
			String api12[] = {"android"};
			listaApis.add(api12);
			String api13[] = {"hibernate"};
			listaApis.add(api13);

			for(int i=0; i< listaApis.size(); i++){
				String query = "select creationdate from posts where posttypeid = 1 AND tags LIKE '%<" + listaApis.get(i)[0]  + ">%'";
				System.out.println(listaApis.get(i)[0]);
				
				int count_01_08 = 0;
				int count_02_08 = 0;
				int count_01_09 = 0;
				int count_02_09 = 0;
				int count_01_10 = 0;
				int count_02_10 = 0;
				int count_01_11 = 0;
				int count_02_11 = 0;
				int count_01_12 = 0;
				int count_02_12 = 0;
				int count_01_13 = 0;
				int count_02_13 = 0;


				ResultSet rs = cbd.executaQuery(query);
				while(rs.next()){
					Date d = rs.getDate("creationdate");
					//System.out.println(d);
					java.util.Date utilDate = new java.util.Date(d.getTime());

					int mes = utilDate.getMonth() + 1;
					int ano = utilDate.getYear() + 1900;

					if(ano == 2008){
						if(mes <= 6)
							count_01_08++;
						else
							count_02_08++;
					}
					else if(ano == 2009){
						if(mes <= 6)
							count_01_09++;
						else
							count_02_09++;
					}
					else if(ano == 2010){
						if(mes <= 6)
							count_01_10++;
						else
							count_02_10++;
					}
					else if(ano == 2011){
						if(mes <= 6)
							count_01_11++;
						else
							count_02_11++;
					}
					else if(ano == 2012){
						if(mes <= 6)
							count_01_12++;
						else
							count_02_12++;
					}
					else if(ano == 2013){
						if(mes <= 6)
							count_01_13++;
						else
							count_02_13++;
					}

				}
				System.out.println(count_01_08);
				System.out.println(count_02_08);
				System.out.println(count_01_09);
				System.out.println(count_02_09);
				System.out.println(count_01_10);
				System.out.println(count_02_10);
				System.out.println(count_01_11);
				System.out.println(count_02_11);
				System.out.println(count_01_12);
				System.out.println(count_02_12);
				System.out.println(count_01_13);
				System.out.println(count_02_13);
			}
		
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
