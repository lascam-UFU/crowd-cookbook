package br.ufu.facom.lsa.Estatisticas;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;

public class AnaliseIdadePosts {

	public static void main(String args[]){
		try{
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();
			
			String query = "SELECT TIMESTAMPDIFF(DAY, p.creationdate, STR_TO_DATE('Sep/6/2013 23:59 PM', '%M/%d/%Y %H:%i')) idade "
					+ "FROM posts p";
			System.out.println(query);
			//Executa a query
			ResultSet rs = cbd.executaQuery(query);
			System.out.println("query executada");
			List<Integer> listIdade = new ArrayList<Integer>();
			
			while(rs.next()){
				int idadePost = rs.getInt("idade");
				listIdade.add(idadePost);
			}
			
			System.out.println("listIdade.size() = " + listIdade.size());
			
			for(int i=0; i< 31; i++){
				int count=0;
				
				for(int j=0; j< listIdade.size(); j++){
					if(listIdade.get(j) < i)
						count++;
				}
				
				System.out.println("i=" + i + " " + count + " " + count/(double)listIdade.size()) ;
			}
		
		}catch(Exception e){
			
		}
	}
	
}
