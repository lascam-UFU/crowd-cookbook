/* 
 * Classe usado para representar algumas informacoes de posts (perguntas ou respostas)
 */

package br.ufu.facom.lsa.Estatisticas;

public class Post {
	private int idPost;
	private int postTypeId;
	private int score;
	private int tamanhoCodigo;
	private int nroDeSnippets;
	private double scoreNormalizado;
	private int reputacaoDoUsuario;
	private int tamanhoPost;
	private int nroTags;
	private int viewCount;
	
	public Post(int idPost, int postTypeId, int score, int tamanhoCodigo,
			int nroDeSnippets, double scoreNormalizado, int reputacaoDoUsuario, int tamanhoPost, int nroTags, int viewCount) {
		super();
		this.idPost = idPost;
		this.postTypeId = postTypeId;
		this.score = score;
		this.tamanhoCodigo = tamanhoCodigo;
		this.nroDeSnippets = nroDeSnippets;
		this.scoreNormalizado = scoreNormalizado;
		this.reputacaoDoUsuario = reputacaoDoUsuario;
		this.tamanhoPost = tamanhoPost;
		this.nroTags = nroTags;
		this.viewCount = viewCount;
	}

	public int getIdPost() {
		return idPost;
	}

	public void setIdPost(int idPost) {
		this.idPost = idPost;
	}

	public int getPostTypeId() {
		return postTypeId;
	}

	public void setPostTypeId(int postTypeId) {
		this.postTypeId = postTypeId;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getTamanhoCodigo() {
		return tamanhoCodigo;
	}

	public void setTamanhoCodigo(int tamanhoCodigo) {
		this.tamanhoCodigo = tamanhoCodigo;
	}

	public int getNroDeSnippets() {
		return nroDeSnippets;
	}

	public void setNroDeSnippets(int nroDeSnippets) {
		this.nroDeSnippets = nroDeSnippets;
	}

	public double getScoreNormalizado() {
		return scoreNormalizado;
	}

	public void setScoreNormalizado(double scoreNormalizado) {
		this.scoreNormalizado = scoreNormalizado;
	}

	public int getReputacaoDoUsuario() {
		return reputacaoDoUsuario;
	}

	public void setReputacaoDoUsuario(int reputacaoDoUsuario) {
		this.reputacaoDoUsuario = reputacaoDoUsuario;
	}

	public int getTamanhoPost() {
		return tamanhoPost;
	}

	public void setTamanhoPost(int tamanhoPost) {
		this.tamanhoPost = tamanhoPost;
	}

	public int getNroTags() {
		return nroTags;
	}

	public void setNroTags(int nroTags) {
		this.nroTags = nroTags;
	}

	public int getViewCount() {
		return viewCount;
	}

	public void setViewCount(int viewCount) {
		this.viewCount = viewCount;
	}
}
