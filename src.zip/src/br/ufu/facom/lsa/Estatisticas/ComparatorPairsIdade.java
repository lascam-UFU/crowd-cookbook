package br.ufu.facom.lsa.Estatisticas;

import java.util.Comparator;

public class ComparatorPairsIdade implements Comparator<Pair>{
	
	public int compare(Pair du1,Pair du2) {  
		return (du1.getIdade()  > du2.getIdade()) ? +1 : (du1.getIdade()  < du2.getIdade()) ? -1 : 0;
	}
}
