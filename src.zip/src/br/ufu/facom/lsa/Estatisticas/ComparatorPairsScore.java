package br.ufu.facom.lsa.Estatisticas;

import java.util.Comparator;

public class ComparatorPairsScore implements Comparator<Pair>{
	
	public int compare(Pair du1,Pair du2) {  
		return (du1.getScore()  < du2.getScore()) ? +1 : (du1.getScore()  > du2.getScore()) ? -1 : 0;
	}
}
