/* 
 * Classe reponsavel por sortear perguntas How-To de tres APIs (Swing, JDBC e GWT),
 * que serao usadas no estudo piloto para identificar caracteristicas de bons Hows-To
 */

package br.ufu.facom.lsa.AnaliseHowTo;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;
import br.ufu.facom.lsa.TesteHowTo.ClassificadorHowTo;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		try{
			String apis[] = {"android"};
			//Variavel que indica o nro de perguntas How que serao sorteadas de cada API
			int nroPerguntas = 80;
			for(int i=0; i< apis.length; i++){
				//Essa lista guardará os ids das perguntas que já foram sorteadas 
				List<String> listaPerguntaJaSorteadas = new ArrayList<String>();
				//Essa lista armazenara os ids de todas as perguntas how to daquelea api
				List<String> listaPerguntaHow = new ArrayList<String>();
				
				ConexaoDB cbd = new ConexaoDB();
				cbd.conectaAoBD("stackoverflow2018");
				
				//Recupera a querry para consutlar todas as perguntas relacionadas aquela API (independente de ter how ou nao)
				String query = ConsultasBD.consultaPerguntas(apis[i]);
				
				Map<String, String> mapIdTitulo = new HashMap<String, String>();
				Map<String, String> mapIdCorpo = new HashMap<String, String>();
								
				//Executa a query

				ResultSet rs = cbd.executaQuery(query);
				
				//Contador para contabilizar o nro total de perguntas de cada API
				int count = 0;
				ClassificadorHowTo classificador = new ClassificadorHowTo();
				
				while (rs.next()) {
					int idPergunta = Integer.parseInt(rs.getString("Id"));
					String corpoOriginal = rs.getString("Body");
					String tituloOriginal = rs.getString("Title");
					
					boolean ehHowTo = classificador.classficaComoHowTO(tituloOriginal, corpoOriginal);
					if(ehHowTo)
						listaPerguntaHow.add(idPergunta+"");
					
					count++;
				}
				
				//fecha a conexao com o BD
				cbd.close();
				
				System.out.println("Numero de perguntas da API " + apis[i] + ": " + count);
				System.out.println("Numero de perguntas HOW da API " + apis[i] + ": " + listaPerguntaHow.size());
								
				//Iremos sortear as perguntas que particiaparam do estudo piloto
				Random randomGenerator = new Random();
				
				System.out.println("Perguntas sorteadas para fazerem parte da base de testes: ");
				while(listaPerguntaJaSorteadas.size() < nroPerguntas){
					int indice = randomGenerator.nextInt(listaPerguntaHow.size());
					String idPergunta = Integer.parseInt(listaPerguntaHow.get(indice))  + "";
					if(listaPerguntaJaSorteadas.contains(idPergunta))
						continue;
					else{
						listaPerguntaJaSorteadas.add(idPergunta);
						System.out.println(idPergunta);
					}
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}

	}

}
