package br.ufu.facom.lsa.SorteioDeReceitas;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;
import br.ufu.facom.lsa.GeradorDeCookbooks.Receita;

public class SorteiaReceitasECapitulos {
	public static void main(String[] args) {
		try{
			
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD("stackOfCookBooks");
			
			//vamos ter que ler o cookbook em momoria
			Map<String, List<Receita>> cookbook = new HashMap<String, List<Receita>>();
			List<Receita> listaDeTodasReceitas = new ArrayList<Receita>();
						
			String nomeApi = "swt";
			
			String q1 = "select questionid, answerid, topicid from recipes where isfake = FALSE and nameapis = '" + nomeApi + "'";
			ResultSet r1 = cbd.executaQuery(q1);
			
			while(r1.next()){
				int idDaPergunta = r1.getInt("questionid");
				int idDaResposta = r1.getInt("answerid");
				int idDoCapitulo = r1.getInt("topicid");
				
				 List<Receita> listaReceitasCap = new ArrayList<Receita>();
				 if(cookbook.containsKey(idDoCapitulo+"")){
					 listaReceitasCap = cookbook.get(idDoCapitulo+"");
				 }else{
					 cookbook.put(idDoCapitulo+"", listaReceitasCap);
				 }
				 
				 Receita r = new Receita(idDaPergunta, idDaResposta, idDoCapitulo);
				 listaReceitasCap.add(r);
				 listaDeTodasReceitas.add(r);
			}
			
			int nroDeCapitulos = cookbook.size();
			
			Random random = new Random(); //Create random class object
			
			Set<String> idDeCapitulosSorteados = new HashSet<String>();
			int countNroDeReceitasSorteadas = 0;
			
			List<String> listReceitasSorteadas = new ArrayList<String>();
			
			while(countNroDeReceitasSorteadas < 15){
				int randomNumber = random.nextInt(listaDeTodasReceitas.size()); 
				Receita receitaSorteada = listaDeTodasReceitas.get(randomNumber);
				int idDoCap = receitaSorteada.getIdDoTopicoDominante();
				int idDaPergunta = receitaSorteada.getIdPergunta();
				int idDaResposta = receitaSorteada.getIdResposta();
				String idDaReceita = idDaPergunta + "-" + idDaResposta;
				
				if(listReceitasSorteadas.contains(idDaReceita))
					continue;
				
				//caso ainda nao tenha sorteado receitas de todos os capitulos, vamos forcar isso. So depois permitimos sortear receitas de capitulos ja sorteados 
				if(idDeCapitulosSorteados.size() < nroDeCapitulos && idDeCapitulosSorteados.contains(idDoCap+""))
					continue;
								
				idDeCapitulosSorteados.add(idDoCap+"");
				listReceitasSorteadas.add(idDaReceita);
				countNroDeReceitasSorteadas++;
				
				System.out.println(idDoCap + " " + idDaReceita);
			}
			
			/*while(it.hasNext()){
				String idCap = it.next();
				System.out.println(idCap);
				
				List<Receita> listaReceitasDoCAp = cookbook.get(idCap);
				
				int randomNumber = random.nextInt(listaReceitasDoCAp.size()); //Generate a random number (index) with the size of the list being the maximum
				Receita r = listaReceitasDoCAp.get(randomNumber);
				
			}*/
			
			//Agora vamos sortear 5 capitulos para entrar na avaliacao da semantica do capitulo
			
			Set<String> setIdCaps = cookbook.keySet();
			List<String> listaIdCapitulos = new ArrayList<String>();
			Iterator<String> it = setIdCaps.iterator();
			while(it.hasNext()){
				listaIdCapitulos.add(it.next());
			}
			
			Set<String> setCapitulosSorteados = new HashSet<String>();
			int countNroDeCapitulosSorteados = 0;
			while(countNroDeCapitulosSorteados < 5){
				int randomNumber = random.nextInt(listaIdCapitulos.size()); 
				String idCapituloSorteado = listaIdCapitulos.get(randomNumber);
				
				if(setCapitulosSorteados.contains(idCapituloSorteado))
					continue;
				
				setCapitulosSorteados.add(idCapituloSorteado);
				countNroDeCapitulosSorteados++;
				
				System.out.println("Capitulo " + idCapituloSorteado);
				
			}
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
