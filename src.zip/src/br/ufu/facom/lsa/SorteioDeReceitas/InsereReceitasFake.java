package br.ufu.facom.lsa.SorteioDeReceitas;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;

public class InsereReceitasFake {

	public static void main(String[] args) {
		try{
			
			ConexaoDB cbd = new ConexaoDB();
			cbd.conectaAoBD();
			
			ConexaoDB cbdStackCookbooks = new ConexaoDB();
			//Conecta ao banco stack_research
			cbdStackCookbooks.conectaAoBD("stackOfCookBooks");
			
			PreparedStatement ps = cbdStackCookbooks.criaPreparedStatement("insert into recipes(NameApis, NameTopic, TopicId, QuestionId, AnswerId, TitleQuestion, TagsQuestion, BodyQuestion, BodyAnswer, RankingPosition, IsFake) values(?,?,?,?,?,?,?,?,?,?, true)");
			
			//adequado, auto-contido, repdro, nao-relacionada com capitulo
			List<String[]> listaFakes =  new ArrayList<String[]>();
			//String swtFake[] = {"swt-15594590-16579240", "swt-6660574-6666411", "swt-18190414-18190557", "swt-12752468-12752554-2"};
			//listaFakes.add(swtFake);
			//String linqFake[] = {"linq-215548-215562", "linq-8988531-8988578", "linq-1244800-1244906", "linq-12136692-12136752-5"};
			//listaFakes.add(linqFake);
			//String qtFake[] = {"qt-7292588-7295010", "qt-5497537-5497885", "qt-18035707-18038232", "qt-2491707-2491811-6"};
			//listaFakes.add(qtFake);
			
			String linqFake[] = {"linq-12136692-12136752-5"};
			listaFakes.add(linqFake);
			
			
			for(int i=0; i< listaFakes.size(); i++){
				String vetReceitasFake[] = listaFakes.get(i);
				
				for(int j=0; j< vetReceitasFake.length; j++){
					String vetPartes[] = vetReceitasFake[j].split("-");
					String nomeApi = vetPartes[0];
					String idPergunta = vetPartes[1];
					String idResposta = vetPartes[2];
					
					String q1 = ConsultasBD.consultaTitulo(Integer.parseInt(idPergunta));
					ResultSet r1 = cbd.executaQuery(q1);
					r1.next();
					String tituloPergunta = r1.getString("title");

					q1 = ConsultasBD.consultaTags(Integer.parseInt(idPergunta));
					r1 = cbd.executaQuery(q1);
					r1.next();
					String strTags = r1.getString("tags").replace("<", " ").replace(">", " ");

					q1 = ConsultasBD.consultaCorpo(Integer.parseInt(idPergunta));
					r1 = cbd.executaQuery(q1);
					r1.next();
					String corpoPergunta = r1.getString("body");

					q1 = ConsultasBD.consultaCorpo(Integer.parseInt(idResposta));
					r1 = cbd.executaQuery(q1);
					r1.next();
					String corpoResposta = r1.getString("body");
					
					List<Integer> listTopicIds = new ArrayList<Integer>();		
					List<String> listTopicNames = new ArrayList<String>();		
					q1 = "SELECT DISTINCT topicId, nametopic " + 
							"FROM recipes " +
							"WHERE NameApis = '" + nomeApi + "'"; 
					r1 = cbdStackCookbooks.executaQuery(q1);
					while(r1.next()){
						int topicId = r1.getInt("topicId");
						String nameTopic = r1.getString("nametopic");
						
						listTopicIds.add(topicId);
						listTopicNames.add(nameTopic);
					}
					//caso seja as tres primeiras receitas (que furam os criterios adeq, auto-cont e reprod, vamos coloca-las em capitulos aleatorios
					if(j != vetReceitasFake.length-1){
						Random random = new Random(); //Create random class object
						int randomNumber = random.nextInt(listTopicIds.size()); //Generate a random number (index) with the size of the list being the maximum
						int randomTopicId = listTopicIds.get(randomNumber);
						String randomTopicName = listTopicNames.get(randomNumber);
						
						ps.setString(1, nomeApi);
						ps.setString(2, randomTopicName);
						ps.setInt(3, randomTopicId);
						ps.setInt(4, Integer.parseInt(idPergunta));
						ps.setInt(5, Integer.parseInt(idResposta));
						ps.setString(6, tituloPergunta);
						ps.setString(7, strTags);
						ps.setString(8, corpoPergunta.replace("<a href=", "<a target=newtab href="));
						ps.setString(9, corpoResposta.replace("<a href=", "<a target=newtab href="));
						ps.setInt(10, Integer.MAX_VALUE);

						ps.executeUpdate();
					}
					//Caso seja a ultima receita (para furar o criterio relacionado com cap), vamos coloca-la num cap pre-definido
					else{
						int topicId = Integer.parseInt(vetPartes[3]);
						String topicName = "";
						
						for(int k=0; k <listTopicIds.size(); k++){
							
							if(listTopicIds.get(k) == topicId){
								topicName = listTopicNames.get(k);
								break;
							}
						}
						
						ps.setString(1, nomeApi);
						ps.setString(2, topicName);
						ps.setInt(3, topicId);
						ps.setInt(4, Integer.parseInt(idPergunta));
						ps.setInt(5, Integer.parseInt(idResposta));
						ps.setString(6, tituloPergunta);
						ps.setString(7, strTags);
						ps.setString(8, corpoPergunta.replace("<a href=", "<a target=newtab href="));
						ps.setString(9, corpoResposta.replace("<a href=", "<a target=newtab href="));
						ps.setInt(10, Integer.MAX_VALUE);

						ps.executeUpdate();
				
					}
				
					
					
				}
		}
			
		//Agora vamos inserir os capitulos fake com 3 receitas fake cada uma
		listaFakes =  new ArrayList<String[]>();
		//String swtFakeCap[] = {"swt-140030-140171-pdf press tableview eclipse wizard-3", "swt-7720-7747-pdf press tableview eclipse wizard-3", "swt-2027649-2027976-pdf press tableview eclipse wizard-3"};
		//listaFakes.add(swtFakeCap);
		//String linqFakeCap[] = {"linq-5551264-5551392-group relationship xml anonym_type loop-6", "linq-296972-297108-group relationship xml anonym_type loop-6", "linq-305092-305100-group relationship xml anonym_type loop-6"};
		//listaFakes.add(linqFakeCap);
		String qtFakeCap[] = {"qt-5026197-5026705-http string compil slot event-1", "qt-475345-475361-http string compil slot event-1", "qt-352896-352943-http string compil slot event-1"};
		listaFakes.add(qtFakeCap);
		
		for(int i=0; i< listaFakes.size(); i++){
			String vetReceitasFake[] = listaFakes.get(i);
			
			for(int j=0; j< vetReceitasFake.length; j++){
				String vetPartes[] = vetReceitasFake[j].split("-");
				String nomeApi = vetPartes[0];
				String idPergunta = vetPartes[1];
				String idResposta = vetPartes[2];
				String nomeTopico = vetPartes[3];
				String idTopico = vetPartes[4];
				
				String q1 = ConsultasBD.consultaTitulo(Integer.parseInt(idPergunta));
				ResultSet r1 = cbd.executaQuery(q1);
				r1.next();
				String tituloPergunta = r1.getString("title");

				q1 = ConsultasBD.consultaTags(Integer.parseInt(idPergunta));
				r1 = cbd.executaQuery(q1);
				r1.next();
				String strTags = r1.getString("tags").replace("<", " ").replace(">", " ");

				q1 = ConsultasBD.consultaCorpo(Integer.parseInt(idPergunta));
				r1 = cbd.executaQuery(q1);
				r1.next();
				String corpoPergunta = r1.getString("body");

				q1 = ConsultasBD.consultaCorpo(Integer.parseInt(idResposta));
				r1 = cbd.executaQuery(q1);
				r1.next();
				String corpoResposta = r1.getString("body");
				
				ps.setString(1, nomeApi);
				ps.setString(2, nomeTopico);
				ps.setInt(3, Integer.parseInt(idTopico));
				ps.setInt(4, Integer.parseInt(idPergunta));
				ps.setInt(5, Integer.parseInt(idResposta));
				ps.setString(6, tituloPergunta);
				ps.setString(7, strTags);
				ps.setString(8, corpoPergunta.replace("<a href=", "<a target=newtab href="));
				ps.setString(9, corpoResposta.replace("<a href=", "<a target=newtab href="));
				ps.setInt(10, Integer.MIN_VALUE);

				ps.executeUpdate();
			}
		}
			
			
		}catch(Exception e){
			e.printStackTrace();
		}

	}

}
