package br.ufu.facom.lsa.GeradorDeCookbooks;

public class CriaCookbooksFake {
	public final static void main(String[] args) {
		try{
			
			
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
