package br.ufu.facom.lsa.GeradorDeCookbooks;

import java.util.Comparator;

public class ComparatorScoreDoRanqueamento implements Comparator<DadoRanqueamento>{
	
	public int compare(DadoRanqueamento du1,DadoRanqueamento du2) {  
		return (du1.getScoreL2R() < du2.getScoreL2R()) ? +1 : (du1.getScoreL2R() > du2.getScoreL2R()) ? -1 : 0;
	}
}
