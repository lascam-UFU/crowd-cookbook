package br.ufu.facom.lsa.GeradorDeCookbooks;

import java.util.Comparator;

public class ComparatorScoreGroundThrough implements Comparator<DadoRanqueamento>{
	
	public int compare(DadoRanqueamento du1,DadoRanqueamento du2) {  
		return (du1.getScoreGoundThrough() < du2.getScoreGoundThrough()) ? +1 : (du1.getScoreGoundThrough() > du2.getScoreGoundThrough()) ? -1 : 0;
	}
}
