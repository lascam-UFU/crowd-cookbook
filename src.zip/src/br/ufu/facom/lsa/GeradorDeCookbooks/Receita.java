package br.ufu.facom.lsa.GeradorDeCookbooks;

public class Receita {
	private String titulo;
	private String tags;
	private String corpoPergunta;
	private String corpoResposta;
	private int idPergunta;
	private int idResposta;
	private int posicaoNoRank;
	private double scoreDoPar;
	private double percentDoTopicoDominanteDaThread;
	private double scoreDoParNorm;
	private double medidaCombinada;
	private int idDoTopicoDominante;
	
	public double getMedidaCombinada() {
		return medidaCombinada;
	}
	public void setMedidaCombinada(double medidaCombinada) {
		this.medidaCombinada = medidaCombinada;
	}
	public double getScoreDoParNorm() {
		return scoreDoParNorm;
	}
	public void setScoreDoParNorm(double scoreDoParNorm) {
		this.scoreDoParNorm = scoreDoParNorm;
	}

	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	public String getCorpoPergunta() {
		return corpoPergunta;
	}
	public void setCorpoPergunta(String corpoPergunta) {
		this.corpoPergunta = corpoPergunta;
	}
	public String getCorpoResposta() {
		return corpoResposta;
	}
	public void setCorpoResposta(String corpoResposta) {
		this.corpoResposta = corpoResposta;
	}
	public int getIdPergunta() {
		return idPergunta;
	}
	public void setIdPergunta(int idPergunta) {
		this.idPergunta = idPergunta;
	}
	public int getIdResposta() {
		return idResposta;
	}
	public void setIdResposta(int idResposta) {
		this.idResposta = idResposta;
	}
	public int getPosicaoNoRank() {
		return posicaoNoRank;
	}
	public void setPosicaoNoRank(int posicaoNoRank) {
		this.posicaoNoRank = posicaoNoRank;
	}
	
	public double getScoreDoPar() {
		return scoreDoPar;
	}
	public void setScoreDoPar(double scoreDoPar) {
		this.scoreDoPar = scoreDoPar;
	}
	public double getPercentDoTopicoDominanteDaThread() {
		return percentDoTopicoDominanteDaThread;
	}
	public void setPercentDoTopicoDominanteDaThread(
			double percentDoTopicoDominanteDaThread) {
		this.percentDoTopicoDominanteDaThread = percentDoTopicoDominanteDaThread;
	}
	
	public int getIdDoTopicoDominante() {
		return idDoTopicoDominante;
	}
	public void setIdDoTopicoDominante(int idDoTopicoDominante) {
		this.idDoTopicoDominante = idDoTopicoDominante;
	}
	public Receita(String titulo, String tags, String corpoPergunta,
			String corpoResposta, int idPergunta, int idResposta,
			int posicaoNoRank, double scoreDoPar, double percentDoTopicoDominante) {
		this.titulo = titulo;
		this.tags = tags;
		this.corpoPergunta = corpoPergunta;
		this.corpoResposta = corpoResposta;
		this.idPergunta = idPergunta;
		this.idResposta = idResposta;
		this.posicaoNoRank = posicaoNoRank;
		this.scoreDoPar = scoreDoPar;
		this.percentDoTopicoDominanteDaThread = percentDoTopicoDominante;
	}
	
	public Receita(String titulo, String tags, String corpoPergunta,
			String corpoResposta, int idPergunta, int idResposta,
			int posicaoNoRank) {
		this.titulo = titulo;
		this.tags = tags;
		this.corpoPergunta = corpoPergunta;
		this.corpoResposta = corpoResposta;
		this.idPergunta = idPergunta;
		this.idResposta = idResposta;
		this.posicaoNoRank = posicaoNoRank;
	}
	
	public Receita(int idPergunta, int idResposta, int idDoTopico) {
		this.idPergunta = idPergunta;
		this.idResposta = idResposta;
		this.idDoTopicoDominante = idDoTopico;
	}
}
