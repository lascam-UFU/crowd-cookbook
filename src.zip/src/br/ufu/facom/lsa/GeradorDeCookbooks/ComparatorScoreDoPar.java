package br.ufu.facom.lsa.GeradorDeCookbooks;

import java.util.Comparator;

public class ComparatorScoreDoPar implements Comparator<Receita>{
	
	public int compare(Receita r1, Receita r2) {  
		return (r1.getScoreDoPar() < r2.getScoreDoPar()) ? +1 : (r1.getScoreDoPar() > r2.getScoreDoPar()) ? -1 : 0;
	}
}

