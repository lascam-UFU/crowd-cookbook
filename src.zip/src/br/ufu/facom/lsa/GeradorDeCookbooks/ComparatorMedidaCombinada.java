package br.ufu.facom.lsa.GeradorDeCookbooks;

import java.util.Comparator;

public class ComparatorMedidaCombinada implements Comparator<Receita>{
	
	public int compare(Receita r1, Receita r2) {  
		return (r1.getMedidaCombinada() < r2.getMedidaCombinada()) ? +1 : (r1.getMedidaCombinada() > r2.getMedidaCombinada()) ? -1 : 0;
	}
}
