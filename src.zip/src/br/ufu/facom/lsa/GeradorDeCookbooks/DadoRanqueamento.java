package br.ufu.facom.lsa.GeradorDeCookbooks;

public class DadoRanqueamento {
	private String idResposta;
	private String idPergunta;
	//score produzido pelo algoritmo de L2R
	private double scoreL2R;
	private double scoreGoundThrough;
	private int posicaoNoRank;
	
	public DadoRanqueamento(String idResposta, String idPergunta, double score) {
		this.idResposta = idResposta;
		this.idPergunta = idPergunta;
		this.scoreL2R = score;
	}
	
	public DadoRanqueamento(String idResposta, String idPergunta, double score, double scoreGroundThrough) {
		this.idResposta = idResposta;
		this.idPergunta = idPergunta;
		this.scoreL2R = score;
		this.scoreGoundThrough = scoreGroundThrough;
	}
	
	public double getScoreGoundThrough() {
		return scoreGoundThrough;
	}

	public void setScoreGoundThrough(double scoreGoundThrough) {
		this.scoreGoundThrough = scoreGoundThrough;
	}

	public int getPosicaoNoRank() {
		return posicaoNoRank;
	}

	public void setPosicaoNoRank(int posicaoNoRank) {
		this.posicaoNoRank = posicaoNoRank;
	}

	public String getIdResposta() {
		return idResposta;
	}

	public void setIdResposta(String idResposta) {
		this.idResposta = idResposta;
	}

	public String getIdPergunta() {
		return idPergunta;
	}

	public void setIdPergunta(String idPergunta) {
		this.idPergunta = idPergunta;
	}

	public double getScoreL2R() {
		return scoreL2R;
	}

	public void setScoreL2R(double score) {
		this.scoreL2R = score;
	}
}
