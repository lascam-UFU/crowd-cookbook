package br.ufu.facom.RanqueamentoDePares;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;

public class ProduzArquivosParaParaLearningToRank {
	public final static void main(String[] args) {
		
		/*OLD DATA - VERSION MAR 2013*/
		
		//metodo que descobre o menor score medio de um par Q&A no SO
		//long menorMediaScore = descobreMenorMediaDeScoreDePar();
		//long menorMediaScore = -143;
		
		
				
		/*List<String[]> listaApis = new ArrayList<String[]>();
		String api1[] = {"jquery", "asp.net"};
		listaApis.add(api1);
		String api2[] = {"swing", "java"};
		listaApis.add(api2);
		String api3[] = {"swt"};
		listaApis.add(api3);
		String api4[] = {"stl"};
		listaApis.add(api4);
		String api5[] = {"c++", "qt4"};
		listaApis.add(api5);
		
		String api6[] = {"log4net", "c#"};
		listaApis.add(api6);
		String api7[] = {"awt"};
		listaApis.add(api7);
		String api8[] = {"boost"};
		listaApis.add(api8);
		String api9[] = {"matplotlib", "python"};
		listaApis.add(api9);
		String api10[] = {"backbone.js"};
		listaApis.add(api10)
		
		
		
		List<Integer> listaNroDeParesPorApi = new ArrayList<Integer>();
		listaNroDeParesPorApi.add(6601);
		listaNroDeParesPorApi.add(16462);
		listaNroDeParesPorApi.add(1269);
		listaNroDeParesPorApi.add(4382);
		listaNroDeParesPorApi.add(899);
		
		listaNroDeParesPorApi.add(292);
		listaNroDeParesPorApi.add(1128);
		listaNroDeParesPorApi.add(4174);
		listaNroDeParesPorApi.add(1648);
		listaNroDeParesPorApi.add(3612);
		
		List<String[]> listaApis = new ArrayList<String[]>();
		String api1[] = {"jquery", "asp.net"};
		listaApis.add(api1);
		String api2[] = {"swing"};
		listaApis.add(api2);
		String api3[] = {"swt"};
		listaApis.add(api3);
		String api4[] = {"stl"};
		listaApis.add(api4);
		String api5[] = {"qt4"};
		listaApis.add(api5);
		
		/*String api6[] = {"log4net", "c#"};
		listaApis.add(api6);
		String api7[] = {"awt"};
		listaApis.add(api7);
		String api8[] = {"boost"};
		listaApis.add(api8);
		String api9[] = {"matplotlib"};
		listaApis.add(api9);
		String api10[] = {"backbone.js"};
		listaApis.add(api10);
		
		
		List<Integer> listaNroDeParesPorApi = new ArrayList<Integer>();
		listaNroDeParesPorApi.add(6601);
		listaNroDeParesPorApi.add(16890);
		listaNroDeParesPorApi.add(1269);
		listaNroDeParesPorApi.add(4382);
		listaNroDeParesPorApi.add(2255);
		
		/*listaNroDeParesPorApi.add(292);
		listaNroDeParesPorApi.add(1128);
		listaNroDeParesPorApi.add(4174);
		listaNroDeParesPorApi.add(1920);
		listaNroDeParesPorApi.add(3612);*/
		
		/*NEW DATA - VERSION SEP 2013*/
		
		List<String[]> listaApis = new ArrayList<String[]>();
		String api1[] = {"sqlite"};
		listaApis.add(api1);
		String api2[] = {"qt"};
		listaApis.add(api2);
		String api3[] = {"swt"};
		listaApis.add(api3);
		String api4[] = {"stl"};
		listaApis.add(api4);
		String api5[] = {"junit"};
		listaApis.add(api5);
		String api6[] = {"log4net"};
		listaApis.add(api6);
		String api7[] = {"awt"};
		listaApis.add(api7);
		String api8[] = {"boost"};
		listaApis.add(api8);
		String api9[] = {"matplotlib"};
		listaApis.add(api9);
		String api10[] = {"backbone.js"};
		listaApis.add(api10);
		
		//Atualizar esses valores		
		List<Integer> listaNroDeParesPorApi = new ArrayList<Integer>();
		listaNroDeParesPorApi.add(9637);
		listaNroDeParesPorApi.add(10409);
		listaNroDeParesPorApi.add(1219);
		listaNroDeParesPorApi.add(3969);
		listaNroDeParesPorApi.add(2967);
		
		listaNroDeParesPorApi.add(646);
		listaNroDeParesPorApi.add(1230);
		listaNroDeParesPorApi.add(3605);
		listaNroDeParesPorApi.add(2235);
		listaNroDeParesPorApi.add(3956);
		
		int codigoDoExperimento = 1;
		int codigoDaVariacao = 6;
		int nroMaximoDeParesPorApi = Integer.MAX_VALUE;
		
		//metodo que produz as folhas para os experimentos
		//produzFolhas(codigoDoExperimento, codigoDaVariacao, listaApis, listaNroDeParesPorApi, nroMaximoDeParesPorApi);
		
		//metodo que produz os dados (arquivos) para as cinco rodadas (5-fold-cross-validation)
		//Para o codigo de variacao = 3, deve-se passar o nome da API (nome das tags seperados por `_`)
		produzDadosParaRodadas(codigoDoExperimento, codigoDaVariacao, "" );
		
	}
	
	public static double calculaMetricaAlvo(double scorePergunta, double scoreResposta){
		//Vou testar media ponderada: peso da pergunta = 3, peso da resposta = 4
		int pesoPergunta = 3;
		int pesoResposta = 7;
		
		double mediaScore = (pesoPergunta*scorePergunta + pesoResposta*scoreResposta)/(double)(pesoPergunta+pesoResposta);
		
		return mediaScore;
	}

	/*private static double menorScoreMedioNaColecao(List<String[]> listaApis) {
		
		double menorScoreMedio = Double.MAX_VALUE;
		
		try{
			Map<String, Integer> mapScores = new HashMap<String, Integer>(); 
			ConexaoDB cbd = new ConexaoDB();
			//Conecta ao banco
			cbd.conectaAoBD();
			
			String query = ConsultasBD.consultaScoreDePosts();
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				String idPost = rs.getString("postid");
				int score = rs.getInt("score");
				
				mapScores.put(idPost, score);
			}
			
			
			String caminhoPastaFeatures = "/media/HDii-2x3Tb/Lucas/lucas2/drop box/Dropbox/resultadosFeatures/";
			
			for(int i=0; i< listaApis.size(); i++){
				String vetAPIs[] = listaApis.get(i);
				
				String nomeAPIs = "";
				
				for(int j=0; j< vetAPIs.length; j++){
					nomeAPIs += vetAPIs[j];
					if(j!=vetAPIs.length-1){
						nomeAPIs += "_";
					}
				}
				
				String caminhoArquivoFeaturesApi = caminhoPastaFeatures + nomeAPIs + ".txt";
				
				BufferedReader bufferedReaderArquivoResult = new BufferedReader(new InputStreamReader(new FileInputStream(caminhoArquivoFeaturesApi)));
	
				String line = "";
				while ((line = bufferedReaderArquivoResult.readLine()) != null) {
					String idPergunta = line.split("#")[1].split("-")[0];
					String idResposta = line.split("#")[1].split("-")[1];
					
					int scoreResposta = mapScores.get(idResposta);
					int scorePergunta = mapScores.get(idPergunta);
					
					double mediaScore = calculaMetricaAlvo(scorePergunta, scoreResposta);
					
					if(mediaScore < menorScoreMedio)
						menorScoreMedio = mediaScore;
					//long mediaScoreInt = Math.round(mediaScore);
					
					//long valorTarget = mediaScoreInt + Math.abs(menorMediaScore) + 1;
			}
			bufferedReaderArquivoResult.close();
				
			}
			System.out.println("menorScoreMedio: " + menorScoreMedio);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	
		return menorScoreMedio;
	}*/

	private static void produzDadosParaRodadas(int codigoExperimento, int codigoDaVariacao, String nomeApi) {
		
		//Fold	Training.txt	Validation.txt Test.txt	
		//Fold1	S1, S2, S3				S4		S5	
		//Fold2	S2, S3, S4				S5		S1	
		//Fold3	S3, S4, S5				S1		S2	
		//Fold4	S4, S5, S1				S2		S3	
		//Fold5	S5, S1, S2				S3		S4
		
		String caminhoPastaFolhas = "/home/lucas/Dropbox/Folhas Experimentos/";
		if(codigoExperimento == 1)
			caminhoPastaFolhas += "Experimento 1 - score/";
		else if(codigoExperimento == 2) 
			caminhoPastaFolhas += "Experimento 2 - avaliacao usuario/";
		else if(codigoExperimento == 3) 
			caminhoPastaFolhas += "Experimento 3 - RankSVM/";
		
		caminhoPastaFolhas += "Variacao " + codigoDaVariacao + "/";
		
		if(!nomeApi.equals(""))
			caminhoPastaFolhas += nomeApi + "/";
		
		
		if(codigoExperimento == 1){
			//codigoDaVariacao = 1,2,3,4,5 -> 5-fold cross validation
			if(codigoDaVariacao <= 5){
				//I = 5 porque temos 5 rodadas
				for(int i=0; i< 5; i++){
					
					String caminhoPastaRodada = caminhoPastaFolhas + "Rodada " + (i+1) + "/";
					File pastaRodada = new File(caminhoPastaRodada);
					pastaRodada.mkdir();
					
					/*String vetIdFolhasTraining[] = {2};
					produzArquivosParaRodada(vetIdFolhasTraining, "A", caminhoPastaFolhas, caminhoPastaRodada);
					
					String vetIdFolhasValidation[] = {1};
					produzArquivosParaRodada(vetIdFolhasValidation, "B", caminhoPastaFolhas, caminhoPastaRodada);
					
					String vetIdFolhasTest[] = {3,4,5};
					produzArquivosParaRodada(vetIdFolhasTest, "C", caminhoPastaFolhas, caminhoPastaRodada);
				*/
			
					
					if(i==0){
						String vetIdFolhasTraining[] = {"1", "2", "3"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"4"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"5"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==1){
						String vetIdFolhasTraining[] = {"2", "3", "4"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"5"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"1"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==2){
						String vetIdFolhasTraining[] = {"3", "4", "5"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"1"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"2"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==3){
						String vetIdFolhasTraining[] = {"4", "5", "1"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"2"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"3"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==4){
						String vetIdFolhasTraining[] = {"5", "1", "2"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"3"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"4"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					
				}
			}
			//codigoDaVariacao = 6 -> 10-fold cross validation
			else if(codigoDaVariacao == 6){
				for(int i=0; i< 10; i++){
					
					String caminhoPastaRodada = caminhoPastaFolhas + "Rodada " + (i+1) + "/";
					File pastaRodada = new File(caminhoPastaRodada);
					pastaRodada.mkdir();
					
					/*String vetIdFolhasTraining[] = {2};
					produzArquivosParaRodada(vetIdFolhasTraining, "A", caminhoPastaFolhas, caminhoPastaRodada);
					
					String vetIdFolhasValidation[] = {1};
					produzArquivosParaRodada(vetIdFolhasValidation, "B", caminhoPastaFolhas, caminhoPastaRodada);
					
					String vetIdFolhasTest[] = {3,4,5};
					produzArquivosParaRodada(vetIdFolhasTest, "C", caminhoPastaFolhas, caminhoPastaRodada);
				*/
			
					
					if(i==0){
						String vetIdFolhasTraining[] = {"1", "2", "3","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"4"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"5"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==1){
						String vetIdFolhasTraining[] = {"2", "3", "4","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"5"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"1"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==2){
						String vetIdFolhasTraining[] = {"3", "4", "5","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"1"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"2"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==3){
						String vetIdFolhasTraining[] = {"4", "5", "1","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"2"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"3"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==4){
						String vetIdFolhasTraining[] = {"5", "1", "2","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"3"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"4"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==5){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","6","7","8"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"9"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"10"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==6){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","7","8","9"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"10"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"6"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==7){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"6"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"7"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==8){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","6","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"7"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"8"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==9){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","6","7","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"8"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"9"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
				}
			}
			//Similar a varicao 1, porem com 200 pares por cada folha, exceto na folha de teste que contem uma api inteira
			else if(codigoDaVariacao == 7){
				//I = 5 porque temos 5 rodadas
				for(int i=0; i< 5; i++){
					
					String caminhoPastaRodada = caminhoPastaFolhas + "Rodada " + (i+1) + "/";
					File pastaRodada = new File(caminhoPastaRodada);
					pastaRodada.mkdir();
					
					/*String vetIdFolhasTraining[] = {2};
					produzArquivosParaRodada(vetIdFolhasTraining, "A", caminhoPastaFolhas, caminhoPastaRodada);
					
					String vetIdFolhasValidation[] = {1};
					produzArquivosParaRodada(vetIdFolhasValidation, "B", caminhoPastaFolhas, caminhoPastaRodada);
					
					String vetIdFolhasTest[] = {3,4,5};
					produzArquivosParaRodada(vetIdFolhasTest, "C", caminhoPastaFolhas, caminhoPastaRodada);
				*/
			
					
					if(i==0){
						String vetIdFolhasTraining[] = {"1", "2", "3"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"4"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"qt4"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==1){
						String vetIdFolhasTraining[] = {"2", "3", "4"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"5"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"jquery_asp.net"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==2){
						String vetIdFolhasTraining[] = {"3", "4", "5"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"1"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"swing"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==3){
						String vetIdFolhasTraining[] = {"4", "5", "1"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"2"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"swt"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==4){
						String vetIdFolhasTraining[] = {"5", "1", "2"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"3"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"stl"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
				}
			}
			//variacao 8: Similar a varicao 6, porem com 200 pares por cada folha, exceto na folha de teste que contem uma api inteira
			else if(codigoDaVariacao == 8){
				for(int i=0; i< 10; i++){
					
					String caminhoPastaRodada = caminhoPastaFolhas + "Rodada " + (i+1) + "/";
					File pastaRodada = new File(caminhoPastaRodada);
					pastaRodada.mkdir();
					
					/*String vetIdFolhasTraining[] = {2};
					produzArquivosParaRodada(vetIdFolhasTraining, "A", caminhoPastaFolhas, caminhoPastaRodada);
					
					String vetIdFolhasValidation[] = {1};
					produzArquivosParaRodada(vetIdFolhasValidation, "B", caminhoPastaFolhas, caminhoPastaRodada);
					
					String vetIdFolhasTest[] = {3,4,5};
					produzArquivosParaRodada(vetIdFolhasTest, "C", caminhoPastaFolhas, caminhoPastaRodada);
				*/
			
					
					if(i==0){
						String vetIdFolhasTraining[] = {"1", "2", "3","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"4"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"qt4"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==1){
						String vetIdFolhasTraining[] = {"2", "3", "4","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"5"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"jquery_asp.net"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==2){
						String vetIdFolhasTraining[] = {"3", "4", "5","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"1"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"swing"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==3){
						String vetIdFolhasTraining[] = {"4", "5", "1","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"2"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"swt"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==4){
						String vetIdFolhasTraining[] = {"5", "1", "2","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"3"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"stl"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==5){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","6","7","8"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"9"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"backbone.js"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==6){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","7","8","9"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"10"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"log4net_c#"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==7){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"6"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"awt"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==8){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","6","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"7"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"boost"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==9){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","6","7","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasValidation[] = {"8"};
						produzArquivosParaRodada(vetIdFolhasValidation, "validation", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"matplotlib"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
				}
			}
		}
		//Experimento 3 = RankSVM. Nesse caso não temos arquivo de validação, temos apenas test e training, por isso tivemos q criar este `if`
		else if(codigoExperimento == 3){
			//codigoDaVariacao = 1,2,3,4,5 -> 5-fold cross validation
			if(codigoDaVariacao <= 5){
				//I = 5 porque temos 5 rodadas
				for(int i=0; i< 5; i++){
					
					String caminhoPastaRodada = caminhoPastaFolhas + "Rodada " + (i+1) + "/";
					File pastaRodada = new File(caminhoPastaRodada);
					pastaRodada.mkdir();
				
					if(i==0){
						String vetIdFolhasTraining[] = {"1", "2", "3", "4"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"5"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==1){
						String vetIdFolhasTraining[] = {"2", "3", "4", "5"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"1"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==2){
						//SVM-Rank exige qids em odem crescente
						String vetIdFolhasTraining[] = {"1", "3", "4", "5"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"2"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==3){
						String vetIdFolhasTraining[] = {"1", "2", "4", "5"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"3"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==4){
						String vetIdFolhasTraining[] = {"1", "2", "3", "5"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"4"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
				}
			}
			//codigoDaVariacao = 6 -> 10-fold cross validation
			else if(codigoDaVariacao == 6){
				for(int i=0; i< 10; i++){
					
					String caminhoPastaRodada = caminhoPastaFolhas + "Rodada " + (i+1) + "/";
					File pastaRodada = new File(caminhoPastaRodada);
					pastaRodada.mkdir();
					
					/*String vetIdFolhasTraining[] = {2};
					produzArquivosParaRodada(vetIdFolhasTraining, "A", caminhoPastaFolhas, caminhoPastaRodada);
					
					String vetIdFolhasValidation[] = {1};
					produzArquivosParaRodada(vetIdFolhasValidation, "B", caminhoPastaFolhas, caminhoPastaRodada);
					
					String vetIdFolhasTest[] = {3,4,5};
					produzArquivosParaRodada(vetIdFolhasTest, "C", caminhoPastaFolhas, caminhoPastaRodada);
				*/
			
					
					if(i==0){
						//SVM-Rank exige qids em odem crescente
						//String vetIdFolhasTraining[] = {1, 2, 3,6,7,8,9,10,4};
						String vetIdFolhasTraining[] = {"1", "2", "3","4","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"5"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==1){
						String vetIdFolhasTraining[] = {"2", "3", "4","5","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"1"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==2){
						String vetIdFolhasTraining[] = {"1","3", "4", "5","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"2"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==3){
						String vetIdFolhasTraining[] = {"1", "2","4", "5","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"3"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==4){
						String vetIdFolhasTraining[] = {"1", "2", "3", "5", "6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"4"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==5){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","6","7","8","9"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"10"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==6){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"6"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==7){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","6","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"7"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==8){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","6","7","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"8"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==9){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","6","7","8","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"9"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					
				}
			}
			//variacao 7: Similar a varicao 1, porem com 200 pares por cada folha, exceto na folha de teste que contem uma api inteira
			if(codigoDaVariacao == 7){
				//I = 5 porque temos 5 rodadas
				for(int i=0; i< 5; i++){
					
					String caminhoPastaRodada = caminhoPastaFolhas + "Rodada " + (i+1) + "/";
					File pastaRodada = new File(caminhoPastaRodada);
					pastaRodada.mkdir();
				
					if(i==0){
						String vetIdFolhasTraining[] = {"1", "2", "3", "4"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"qt4"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==1){
						String vetIdFolhasTraining[] = {"2", "3", "4", "5"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"jquery_asp.net"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==2){
						//SVM-Rank exige qids em odem crescente
						String vetIdFolhasTraining[] = {"1", "3", "4", "5"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"swing"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==3){
						String vetIdFolhasTraining[] = {"1", "2", "4", "5"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"swt"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==4){
						String vetIdFolhasTraining[] = {"1", "2", "3", "5"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"stl"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
				}
			}
			//variacao 8: Similar a varicao 6, porem com 200 pares por cada folha, exceto na folha de teste que contem uma api inteira
			else if(codigoDaVariacao == 8){
				for(int i=0; i< 10; i++){
					
					String caminhoPastaRodada = caminhoPastaFolhas + "Rodada " + (i+1) + "/";
					File pastaRodada = new File(caminhoPastaRodada);
					pastaRodada.mkdir();
					
					/*String vetIdFolhasTraining[] = {2};
					produzArquivosParaRodada(vetIdFolhasTraining, "A", caminhoPastaFolhas, caminhoPastaRodada);
					
					String vetIdFolhasValidation[] = {1};
					produzArquivosParaRodada(vetIdFolhasValidation, "B", caminhoPastaFolhas, caminhoPastaRodada);
					
					String vetIdFolhasTest[] = {3,4,5};
					produzArquivosParaRodada(vetIdFolhasTest, "C", caminhoPastaFolhas, caminhoPastaRodada);
				*/
			
					
					if(i==0){
						//SVM-Rank exige qids em odem crescente
						//String vetIdFolhasTraining[] = {1, 2, 3,6,7,8,9,10,4};
						String vetIdFolhasTraining[] = {"1", "2", "3","4","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"qt4"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==1){
						String vetIdFolhasTraining[] = {"2", "3", "4","5","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"jquery_asp.net"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==2){
						String vetIdFolhasTraining[] = {"1","3", "4", "5","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"swing"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==3){
						String vetIdFolhasTraining[] = {"1", "2","4", "5","6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"swt"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					
					else if(i==4){
						String vetIdFolhasTraining[] = {"1", "2", "3", "5", "6","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"stl"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==5){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","6","7","8","9"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"backbone.js"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==6){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","7","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"log4net_c#"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==7){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","6","8","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"awt"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==8){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","6","7","9","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"boost"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
					else if(i==9){
						String vetIdFolhasTraining[] = {"1","2","3","4","5","6","7","8","10"};
						produzArquivosParaRodada(vetIdFolhasTraining, "training", caminhoPastaFolhas, caminhoPastaRodada);
						
						String vetIdFolhasTest[] = {"matplotlib"};
						produzArquivosParaRodada(vetIdFolhasTest, "test", caminhoPastaFolhas, caminhoPastaRodada);
					}
				}
			}
		}
		
		
		

		
	}

	private static void produzArquivosParaRodada(String[] vetIdFolhas, String nomeArquivo, String caminhoPastaFolhas, String caminhoPastaRodada) {
		try{
			
			
			FileOutputStream saidaArquivoFolha;
			PrintStream fileSaidaArquivoSaidaFolha;
			saidaArquivoFolha = new FileOutputStream(caminhoPastaRodada +  nomeArquivo + ".txt");
			fileSaidaArquivoSaidaFolha = new PrintStream(saidaArquivoFolha);
			
			for(int i=0; i< vetIdFolhas.length; i++){
				BufferedReader bufferedReaderArquivoResult = new BufferedReader(new InputStreamReader(new FileInputStream(caminhoPastaFolhas + vetIdFolhas[i] + ".txt")));
				String line = "";

				while ((line = bufferedReaderArquivoResult.readLine()) != null) {
					fileSaidaArquivoSaidaFolha.println(line);
				}
				bufferedReaderArquivoResult.close();
			}
			
			fileSaidaArquivoSaidaFolha.close();

			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	//Caso nao queira limitar o nro maximo de pares por api, passar nroMaximoDeParesPorApi = Integer.maximun
	private static void produzFolhas(int codigoExperimento, int codigoDaVariacao, List<String[]> listaApis, List<Integer> listaNroDeParesPorApi, int nroMaximoDeParesPorApi) {
		//codigoExperimento = 1 -> experimento com score
		//codigoExperimento = 2 -> experimento com opiniao do usuario
		//codigoExperimento = 3 -> rank SVM
		
		//codigoDaVariacao = 1 -> cada API em uma folha separada
		
		String caminhoPastaFeatures = "/home/lucas/Dropbox/resultadosFeatures/corrigidos/";
		String caminhoPastaFolhas = "/home/lucas/Dropbox/Folhas Experimentos/";
		if(codigoExperimento == 1)
			caminhoPastaFolhas += "Experimento 1 - score/";
		else if(codigoExperimento == 2) 
			caminhoPastaFolhas += "Experimento 2 - avaliacao usuario/";
		else if(codigoExperimento == 3) 
			caminhoPastaFolhas += "Experimento 3 - RankSVM/";
		
		caminhoPastaFolhas += "Variacao " + codigoDaVariacao + "/";
		
		try{
			//Em todas esses experimentos, 1 api corresponde a 1 folha, por isso ficam dentro do mesmo if
			if(codigoExperimento == 1 || codigoExperimento == 3){
				Map<String, Integer> mapScores = new HashMap<String, Integer>(); 
				ConexaoDB cbd = new ConexaoDB();
				//Conecta ao banco
				cbd.conectaAoBD();
				
				String query = ConsultasBD.consultaScoreDePosts();
				ResultSet rs = cbd.executaQuery(query);
				while(rs.next()){
					String idPost = rs.getString("postid");
					int score = rs.getInt("score");
					
					mapScores.put(idPost, score);
				}
				cbd.close();
				
				//Cada API eh uma folha
				if(codigoDaVariacao == 1 || codigoDaVariacao == 6 || codigoDaVariacao == 7 || codigoDaVariacao == 8){
					
					if(codigoDaVariacao == 6 && listaApis.size() != 10){
						System.out.println("Nro incorreto de APIs: requerido = 10");
					}
					else if(codigoDaVariacao == 1&& listaApis.size() != 5){
						System.out.println("Nro incorreto de APIs: requerido = 5");
					}
					
					
					for(int i=0; i< listaApis.size(); i++){
						String vetAPIs[] = listaApis.get(i);
						
						String nomeAPIs = "";
						
						for(int j=0; j< vetAPIs.length; j++){
							nomeAPIs += vetAPIs[j];
							if(j!=vetAPIs.length-1){
								nomeAPIs += "_";
							}
						}
						
						String caminhoArquivoFeaturesApi = caminhoPastaFeatures + nomeAPIs + "_corrigido.txt";
						
						BufferedReader bufferedReaderArquivoResult = new BufferedReader(new InputStreamReader(new FileInputStream(caminhoArquivoFeaturesApi)));
						
						FileOutputStream saidaArquivoFolha;
						PrintStream fileSaidaArquivoSaidaFolha;
						saidaArquivoFolha = new FileOutputStream(caminhoPastaFolhas +  (i+1) + ".txt");
						fileSaidaArquivoSaidaFolha = new PrintStream(saidaArquivoFolha);
						
						//Iremos tambem produzir uma folha com o nome "nomeApi.txt", contendo todos os pares da Api. Isso sera feito para no caso
						//de estarmos limitando a quantidade de pares de cada api (ex. 200), podermos testar como um ranqueador construido
						//a partir de 200 pares de cada api se comporta para ranquear uma api inteira
						FileOutputStream saidaArquivoFolhaApiInteira;
						PrintStream fileSaidaArquivoSaidaFolhaApiInteira;
						saidaArquivoFolhaApiInteira = new FileOutputStream(caminhoPastaFolhas +  nomeAPIs + ".txt");
						fileSaidaArquivoSaidaFolhaApiInteira = new PrintStream(saidaArquivoFolhaApiInteira);
						
						//int tamanhoDaAPi = listaNroDeParesPorApi.get(i);
						//int metadeDaAPi = tamanhoDaAPi/2;
						
						int countNroPares = 0;
						String line = "";
						
						while (((line = bufferedReaderArquivoResult.readLine()) != null)) {
							String idPergunta = line.split("#")[1].split("-")[0];
							String idResposta = line.split("#")[1].split("-")[1];
							
							int scoreResposta = mapScores.get(idResposta);
							int scorePergunta = mapScores.get(idPergunta);
							
							double mediaScore = calculaMetricaAlvo(scorePergunta, scoreResposta);
							
							//double target = mediaScore + menorScore;
							//long mediaScoreInt = Math.round(mediaScore);
							
							//long valorTarget = mediaScoreInt + Math.abs(menorMediaScore) + 1;
							//Apenas no experimenro 3 (SVM-Rank) precisamos selecionar atributos, pois o experimento 1 (Random Forests) nao requer delecao de features
							if(codigoExperimento == 3){
								String lineComAtributosSelecionados = "";
								String metricas[] = line.split(" ");
								for(int j=0; j< metricas.length; j++){
									//TODO mudar isso, ler as features seleciondas pelo weka a partir de arquivo para não ficar hard code
									//13,72,74,90,123,127,128,130,132,133,135,136,137,139,141,143,144,152,156,158,159,168,178,200 : 24
									String idDaMetrica = metricas[j].split(":")[0];
									
									if(idDaMetrica.equals("13") ||
											idDaMetrica.equals("72") ||
											idDaMetrica.equals("74") ||
											idDaMetrica.equals("90") ||
											idDaMetrica.equals("123") ||
											idDaMetrica.equals("127") ||
											idDaMetrica.equals("128") ||
											idDaMetrica.equals("130") ||
											idDaMetrica.equals("132") ||
											idDaMetrica.equals("133") ||
											idDaMetrica.equals("135") ||
											idDaMetrica.equals("136") ||
											idDaMetrica.equals("137") ||
											idDaMetrica.equals("139") ||
											idDaMetrica.equals("141") ||
											idDaMetrica.equals("143") ||
											idDaMetrica.equals("144") ||
											idDaMetrica.equals("152") ||
											idDaMetrica.equals("156") ||
											idDaMetrica.equals("158") ||
											idDaMetrica.equals("159") ||
											idDaMetrica.equals("168") ||
											idDaMetrica.equals("178") ||
											idDaMetrica.equals("200") ||
											metricas[j].contains("#")
									   ){
										lineComAtributosSelecionados += metricas[j] + " ";
									}
								}
								
								//soh escreve neste arquivo de nao ultrapassou o limite de pares por api (ex 200)
								if(countNroPares < nroMaximoDeParesPorApi)
									fileSaidaArquivoSaidaFolha.println(mediaScore + " qid:" + (i+1) + " " + lineComAtributosSelecionados);
								//sempre escreve neste arquivo, pois eh uma folha espcial que devera conter a api inteira
								fileSaidaArquivoSaidaFolhaApiInteira.println(mediaScore + " qid:" + (i+1) + " " + lineComAtributosSelecionados);
							}
							//codigoDoExperimento = 1 (nao precisa fazer delecao de features)
							else{
								//soh escreve neste arquivo de nao ultrapassou o limite de pares por api (ex 200)
								if(countNroPares < nroMaximoDeParesPorApi)
									fileSaidaArquivoSaidaFolha.println(mediaScore + " qid:" + (i+1) + " " + line);
								//sempre escreve neste arquivo, pois eh uma folha espcial que devera conter a api inteira
								fileSaidaArquivoSaidaFolhaApiInteira.println(mediaScore + " qid:" + (i+1) + " " + line);
							}
							countNroPares++;
							
					}
						System.out.println(nomeAPIs + " -> qid:" + (i+1) + " folha:" + (i+1));
						
						bufferedReaderArquivoResult.close();
						fileSaidaArquivoSaidaFolha.close();
					}
				}
				//20% dos pares de cada API em cada folha
				else if(codigoDaVariacao == 2 || codigoDaVariacao == 5){
					for(int i=0; i< listaApis.size(); i++){
						String vetAPIs[] = listaApis.get(i);
						
						String nomeAPIs = "";
						
						for(int j=0; j< vetAPIs.length; j++){
							nomeAPIs += vetAPIs[j];
							if(j!=vetAPIs.length-1){
								nomeAPIs += "_";
							}
						}
						
						String caminhoArquivoFeaturesApi = caminhoPastaFeatures + nomeAPIs + ".txt";
						
						BufferedReader bufferedReaderArquivoResult = new BufferedReader(new InputStreamReader(new FileInputStream(caminhoArquivoFeaturesApi)));
						
						int nroParesDeApi = listaNroDeParesPorApi.get(i);
						int nroDeParesPorArquivo = new Double(nroParesDeApi/5.0).intValue();
						
						int start1 = 1;
						int start2 = start1 + nroDeParesPorArquivo;
						int start3 = start2 + nroDeParesPorArquivo;
						int start4 = start3 + nroDeParesPorArquivo;
						int start5 = start4 + nroDeParesPorArquivo;
						
						List<Integer> listaPosicoesIniciais = new ArrayList<Integer>();
						listaPosicoesIniciais.add(start1);
						listaPosicoesIniciais.add(start2);
						listaPosicoesIniciais.add(start3);
						listaPosicoesIniciais.add(start4);
						listaPosicoesIniciais.add(start5);
						
						boolean appendMode = true;
						if(i==0)
							appendMode = false;
						
						String line = "";
						int indiceDoArquivoAtual = 0;
						int contadorDaLinha = 1;
						PrintWriter out = null;
						while ((line = bufferedReaderArquivoResult.readLine()) != null) {
							
							
							
						
							//Hora de trocar de arquivo 
							//Por equanto estou criando os arquivos folhas manualmente 
							if(listaPosicoesIniciais.contains(contadorDaLinha)){
								//System.out.println("tentando criar:" +caminhoPastaFolhas +  (++indiceDoArquivoAtual) + ".txt" );
								//File f = new File(caminhoPastaFolhas +  (++indiceDoArquivoAtual) + ".txt");
								//if(!f.exists()){
									//f.mkdirs(); 
								//	f.createNewFile();
								//}
								
							    out = new PrintWriter(new BufferedWriter(new FileWriter(caminhoPastaFolhas +  (++indiceDoArquivoAtual) + ".txt", appendMode)));
							}
							  
							
							String idPergunta = line.split("#")[1].split("-")[0];
							String idResposta = line.split("#")[1].split("-")[1];
							
							int scoreResposta = mapScores.get(idResposta);
							int scorePergunta = mapScores.get(idPergunta);
							
							double mediaScore = calculaMetricaAlvo(scorePergunta, scoreResposta);
								
							out.println(mediaScore + " qid:" + (i+1) + " " + line);
							out.flush();
							contadorDaLinha++;
							
						}
						out.close();
						bufferedReaderArquivoResult.close();
					}
				}
				//uma API por vez
				else if(codigoDaVariacao == 3){
					for(int i=0; i< listaApis.size(); i++){
						String vetAPIs[] = listaApis.get(i);
						
						String nomeAPIs = "";
						
						for(int j=0; j< vetAPIs.length; j++){
							nomeAPIs += vetAPIs[j];
							if(j!=vetAPIs.length-1){
								nomeAPIs += "_";
							}
						}
						
						String caminhoArquivoFeaturesApi = caminhoPastaFeatures + nomeAPIs + ".txt";
						
						BufferedReader bufferedReaderArquivoResult = new BufferedReader(new InputStreamReader(new FileInputStream(caminhoArquivoFeaturesApi)));
						
						int nroParesDeApi = listaNroDeParesPorApi.get(i);
						int nroDeParesPorArquivo = new Double(nroParesDeApi/5.0).intValue();
						
						int start1 = 1;
						int start2 = start1 + nroDeParesPorArquivo;
						int start3 = start2 + nroDeParesPorArquivo;
						int start4 = start3 + nroDeParesPorArquivo;
						int start5 = start4 + nroDeParesPorArquivo;
						
						List<Integer> listaPosicoesIniciais = new ArrayList<Integer>();
						listaPosicoesIniciais.add(start1);
						listaPosicoesIniciais.add(start2);
						listaPosicoesIniciais.add(start3);
						listaPosicoesIniciais.add(start4);
						listaPosicoesIniciais.add(start5);
						
						//boolean appendMode = true;
						//if(i==0)
						//	appendMode = false;
						
						String line = "";
						int indiceDoArquivoAtual = 0;
						int contadorDaLinha = 1;
						PrintWriter out = null;
						
						String caminhoPastaFolhasApi = caminhoPastaFolhas + "/" + nomeAPIs + "/";
						File pasta = new File(caminhoPastaFolhasApi);
						pasta.mkdir();
						
						while ((line = bufferedReaderArquivoResult.readLine()) != null) {
							
							
							
						
							//Hora de trocar de arquivo 
							//Por equanto estou criando os arquivos folhas manualmente 
							if(listaPosicoesIniciais.contains(contadorDaLinha)){
								//System.out.println("tentando criar:" +caminhoPastaFolhas +  (++indiceDoArquivoAtual) + ".txt" );
								//File f = new File(caminhoPastaFolhas +  (++indiceDoArquivoAtual) + ".txt");
								//if(!f.exists()){
									//f.mkdirs(); 
								//	f.createNewFile();
								//}
								
							    out = new PrintWriter(new BufferedWriter(new FileWriter(caminhoPastaFolhasApi +  (++indiceDoArquivoAtual) + ".txt")));
							}
							  
							
							String idPergunta = line.split("#")[1].split("-")[0];
							String idResposta = line.split("#")[1].split("-")[1];
							
							int scoreResposta = mapScores.get(idResposta);
							int scorePergunta = mapScores.get(idPergunta);
							
							double mediaScore = calculaMetricaAlvo(scorePergunta, scoreResposta);
								
							out.println(mediaScore + " qid:" + (i+1) + " " + line);
							out.flush();
							contadorDaLinha++;
							
						}
						out.close();
						bufferedReaderArquivoResult.close();
					}
				}
				
				//Similar a variacao 1, mas 2 apis por folha
				else if(codigoDaVariacao == 4){
					if(listaApis.size() != 10){
						System.out.println("Nro incorreto de APIs: requerido = 10");
					}
					
					int codigoDaFolha = 1;
					for(int i=0; i< listaApis.size(); i = i + 2){
						
						int indiceDaApi = i;
						for(int k=0; k<2; k++){
							String vetAPIs[] = listaApis.get(indiceDaApi);
							String nomeAPIs = "";
														
							for(int j=0; j< vetAPIs.length; j++){
								nomeAPIs += vetAPIs[j];
								if(j!=vetAPIs.length-1){
									nomeAPIs += "_";
								}
							}
														
							String caminhoArquivoFeaturesApi = caminhoPastaFeatures + nomeAPIs + ".txt";
							BufferedReader bufferedReaderArquivoResult = new BufferedReader(new InputStreamReader(new FileInputStream(caminhoArquivoFeaturesApi)));
							
							boolean appendMode = true;
							if(k==0)
								appendMode = false;
							
							PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(caminhoPastaFolhas +  (codigoDaFolha) + ".txt", appendMode)));
							
							String line = "";
							while ((line = bufferedReaderArquivoResult.readLine()) != null) {
								String idPergunta = line.split("#")[1].split("-")[0];
								String idResposta = line.split("#")[1].split("-")[1];
								
								int scoreResposta = mapScores.get(idResposta);
								int scorePergunta = mapScores.get(idPergunta);
								
								double mediaScore = calculaMetricaAlvo(scorePergunta, scoreResposta);
								
								//double target = mediaScore + menorScore;
								//long mediaScoreInt = Math.round(mediaScore);
								
								//long valorTarget = mediaScoreInt + Math.abs(menorMediaScore) + 1;
								
								out.println(mediaScore + " qid:" + (indiceDaApi+1) + " " + line);
								out.flush();
								
						}
							out.close();
							bufferedReaderArquivoResult.close();
							indiceDaApi++;
						}
						codigoDaFolha++;
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	
	}

	private static long descobreMenorMediaDeScoreDePar() {
		return 0;
		
		/*
		 * substituido por 
		 * SELECT pa.`Id`, pq.`Id`,  AVG(pa.`Score` + pq.`Score`)
		   FROM posts pa INNER JOIN posts pq ON pa.`ParentId` = pq.`Id`
		   WHERE pa.`PostTypeId` = 2 AND pa.`ParentId` IS NOT NULL AND pq.`PostTypeId` = 1
		   GROUP BY pa.`Id`, pq.`Id`
		   ORDER BY AVG(pa.`Score` + pq.`Score`)
			
			resultado: -143
		 * 
		 * 
		long menorMedia = Long.MAX_VALUE;
		try{
			int countPerguntas = 0;
			ConexaoDB cbd = new ConexaoDB();
			//Conecta ao banco
			cbd.conectaAoBD();
			
			String query = ConsultasBD.consultaPerguntas();
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				
				System.out.println(countPerguntas++ + "");
				
				int idPergunta = rs.getInt("postid");
				int scorePergunta = rs.getInt("score");
				
				String queryRespostas = ConsultasBD.consultaRespostasDePergunta(idPergunta);
				ResultSet rsRespostas = cbd.executaQuery(queryRespostas);
				
				while(rsRespostas.next()){
					int scoreRespostas = rsRespostas.getInt("score");
					
					double mediaScore = (scorePergunta+scoreRespostas)/2.0;
					long mediaInteiro = Math.round(mediaScore);
					if(mediaInteiro < menorMedia)
						menorMedia = mediaInteiro;
				}
				
			}
			System.out.println("menorMedia: " + menorMedia);
			cbd.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return menorMedia;*/
	}
}
