/* 
 * Classe responsavel por gerar os arquivos sobre os quais serao aplicados o LDA 
 */

package br.ufu.facom.RanqueamentoDePares;

import java.util.ArrayList;
import java.util.List;

import br.ufu.facom.lsa.ExtratorDeCaracteristicasDosPosts.ExtratorDeCaracteristicasDeApi;

public class ExtraiCaracteristicasDeApis {
	//Para a construcao do arquivo toda a thread sera considerada (pergunta e todas as respostas)
	public static final int TODA_THREAD = 0;
	//Para a construcao do arquivo sera considerada a pergunta
	public static final int APENAS_PERGUNTA = 1;
	//Para a construcao do arquivo sera considerada a pergunta e a respota aceita
	public static final int PERGUNTA_RESPOSTA_ACEITA = 2;

	public final static void main(String[] args) {
		
		//A primeira coisa a ser feita sera gerar para cada biblioteca um arquuivo com o calculo das metricas os arquivos
		
		//List<String[]> listaApis = new ArrayList<String[]>();
		//String api3[] = {"swt"};
		//listaApis.add(api3);
		
		List<String[]> listaApis = new ArrayList<String[]>();
		
		//String api4[] = {"awt"};
		//listaApis.add(api4);
		
		//String api5[] = {"qt"};
		//listaApis.add(api5);
		
		String api6[] = {"sqlite"};
		listaApis.add(api6);
		
		//String api3[] = {"jquery", "asp.net"};
		//listaApis.add(api3);
		
		/*String api1[] = {"jquery", "asp.net"};
		listaApis.add(api1);
		String api2[] = {"swing", "java"};
		listaApis.add(api2);
		String api3[] = {"swt"};
		listaApis.add(api3);
		String api4[] = {"stl"};
		listaApis.add(api4);
		String api5[] = {"c++", "qt4"};
		listaApis.add(api5);*/
		
		//String api1[] = {"log4net", "c#"};
		//listaApis.add(api1);
		//String api2[] = {"awt"};
		//listaApis.add(api2);
		//String api3[] = {"boost"};
		//listaApis.add(api3);
		//String api4[] = {"matplotlib", "python"};
		//listaApis.add(api4);
		//String api5[] = {"backbone.js"};
		//listaApis.add(api5);
		
		/*String api1[] = {"swing"};
		listaApis.add(api1);
		String api2[] = {"qt4"};
		listaApis.add(api2);
		String api3[] = {"matplotlib"};
		listaApis.add(api3);*/
				
		ExtratorDeCaracteristicasDeApi eca = new ExtratorDeCaracteristicasDeApi();
		
		for(int i=0; i < listaApis.size(); i++){
			//System.out.println("**************" + listaApis.get(i)[0] + "******************");
			//if(i==0)
				eca.calculaFeaturesParaApi(false, listaApis.get(i), Integer.MAX_VALUE);
			//else
			//	eca.calculaFeaturesParaApi(false, listaApis.get(i), Integer.MAX_VALUE);
		}
	}
}
