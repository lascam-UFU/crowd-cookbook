package br.ufu.facom.RanqueamentoDePares;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;

public class ProduzDadosParaGraficoLogScale {
	public final static void main(String[] args) {
		List<String[]> listaApis = new ArrayList<String[]>();
		String api1[] = {"jquery", "asp.net"};
		listaApis.add(api1);
		String api2[] = {"swing", "java"};
		listaApis.add(api2);
		String api3[] = {"swt"};
		listaApis.add(api3);
		String api4[] = {"stl"};
		listaApis.add(api4);
		String api5[] = {"c++", "qt4"};
		listaApis.add(api5);

		geraArquivoComMediaDoScoreMedioDePares(1, listaApis);
	}

	private static void geraArquivoComMediaDoScoreMedioDePares(int codigoExperimento,  List<String[]> listaApis){
		
		try{
			
			Map<Double, Integer> mapNroDeOcorrenciasDeScore = new HashMap<Double, Integer>();
			
			String caminhoPastaFeatures = "/media/HDii-2x3Tb/Lucas/lucas2/drop box/Dropbox/resultadosFeatures/";
			String caminhoPastaExperimento = "/media/HDii-2x3Tb/Lucas/lucas2/drop box/Dropbox/Folhas Experimentos/";
			if(codigoExperimento == 1)
				caminhoPastaExperimento += "Experimento 1 - score/";
			else if(codigoExperimento == 2) 
				caminhoPastaExperimento += "Experimento 2 - avaliacao usuario/";

			//codigoExperimento == 1 -> metrica target eh a media aritmetica do score do par
			if(codigoExperimento == 1){
				Map<String, Integer> mapScores = new HashMap<String, Integer>(); 
				ConexaoDB cbd = new ConexaoDB();
				//Conecta ao banco
				cbd.conectaAoBD();

				String query = ConsultasBD.consultaScoreDePosts();
				ResultSet rs = cbd.executaQuery(query);
				while(rs.next()){
					String idPost = rs.getString("postid");
					int score = rs.getInt("score");

					mapScores.put(idPost, score);
				}
				cbd.close();

				
				for(int i=0; i< listaApis.size(); i++){
					String vetAPIs[] = listaApis.get(i);

					String nomeAPIs = "";

					for(int j=0; j< vetAPIs.length; j++){
						nomeAPIs += vetAPIs[j];
						if(j!=vetAPIs.length-1){
							nomeAPIs += "_";
						}
					}

					String caminhoArquivoFeaturesApi = caminhoPastaFeatures + nomeAPIs + ".txt";
					BufferedReader bufferedReaderArquivoResult = new BufferedReader(new InputStreamReader(new FileInputStream(caminhoArquivoFeaturesApi)));

					String line = "";
					while ((line = bufferedReaderArquivoResult.readLine()) != null) {
						String idPergunta = line.split("#")[1].split("-")[0];
						String idResposta = line.split("#")[1].split("-")[1];

						int scoreResposta = mapScores.get(idResposta);
						int scorePergunta = mapScores.get(idPergunta);

						double mediaScore = (scorePergunta + scoreResposta)/2.0;
						long mediaScoreInt = Math.round(mediaScore);
						
						if(mapNroDeOcorrenciasDeScore.containsKey(mediaScore))
							mapNroDeOcorrenciasDeScore.put(mediaScore, mapNroDeOcorrenciasDeScore.get(mediaScore)+1);
						else
							mapNroDeOcorrenciasDeScore.put(mediaScore, 1);
						
						
					
					}
					bufferedReaderArquivoResult.close();
				}
				
				
				
				    
				FileOutputStream saidaArquivoValoresScoresPares;
				PrintStream fileSaidaArquivoValoresScoresPares;
				saidaArquivoValoresScoresPares = new FileOutputStream(caminhoPastaExperimento + "scoresDosPares.txt");
				fileSaidaArquivoValoresScoresPares = new PrintStream(saidaArquivoValoresScoresPares);
				fileSaidaArquivoValoresScoresPares.println("scoreDoPar,nroDeOcorrencias");
				
				 Iterator it = mapNroDeOcorrenciasDeScore.entrySet().iterator();
				  while (it.hasNext()) {
				       Map.Entry pairs = (Map.Entry)it.next();
				       fileSaidaArquivoValoresScoresPares.println(pairs.getKey() + "," + pairs.getValue());
				       it.remove(); // avoids a ConcurrentModificationException
				  }
				fileSaidaArquivoValoresScoresPares.close();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
