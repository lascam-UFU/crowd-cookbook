/*A discretizacao será feita pelo programa Weka
 * Essa classe monta o arquivo de entrada para o weka, para que possamos discretizar a métrica alvo (media ponderada dos scores do par)
 */

package br.ufu.facom.RanqueamentoDePares;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;

public class ProduzArquivoParaSelecaoDeFeaturesParaRankSVM {

	public static void main(String[] args) {

		List<String[]> listaApis = new ArrayList<String[]>();
		String api1[] = {"jquery", "asp.net"};
		listaApis.add(api1);
		String api2[] = {"swing"};
		listaApis.add(api2);
		String api3[] = {"swt"};
		listaApis.add(api3);
		String api4[] = {"stl"};
		listaApis.add(api4);
		String api5[] = {"qt4"};
		listaApis.add(api5);
		
		String api6[] = {"log4net", "c#"};
		listaApis.add(api6);
		String api7[] = {"awt"};
		listaApis.add(api7);
		String api8[] = {"boost"};
		listaApis.add(api8);
		String api9[] = {"matplotlib"};
		listaApis.add(api9);
		String api10[] = {"backbone.js"};
		listaApis.add(api10);
		

		geraArquivoParaDiscretizacaoDeFeatures(1, listaApis);
	}
	
	private static double calculaMetricaAlvo(double scorePergunta, double scoreResposta){
		//Vou testar media ponderada: peso da pergunta = 3, peso da resposta = 4
		int pesoPergunta = 3;
		int pesoResposta = 7;
		
		double mediaScore = (pesoPergunta*scorePergunta + pesoResposta*scoreResposta)/(double)(pesoPergunta+pesoResposta);
		
		return mediaScore;
	}

	private static void geraArquivoParaDiscretizacaoDeFeatures(int codigoExperimento, List<String[]> listaApis) {
		try{
			String caminhoPastaFeatures = "/media/HDii-2x3Tb/Lucas/lucas2/drop box/Dropbox/resultadosFeatures/";
			String caminhoDiscretizacao = "/media/HDii-2x3Tb/Lucas/lucas2/drop box/Dropbox/Selecao de Features para Rank SVM/";
			
			//As features consideradas são as presentes no arquivo /media/HDii-2x3Tb/Lucas/lucas2/drop box/Folhas Experimentos/Experimento 1 - score/Variacao 6/featuresSemVarias.txt
			//features 1-208 e 212
			if(codigoExperimento == 1){
				Map<String, Integer> mapScores = new HashMap<String, Integer>(); 
				ConexaoDB cbd = new ConexaoDB();
				//Conecta ao banco
				cbd.conectaAoBD();

				String query = ConsultasBD.consultaScoreDePosts();
				ResultSet rs = cbd.executaQuery(query);
				while(rs.next()){
					String idPost = rs.getString("postid");
					int score = rs.getInt("score");

					mapScores.put(idPost, score);
				}
				cbd.close();
				System.out.println("aki2");

				FileOutputStream saidaArquivoInfoGain;
				PrintStream fileSaidaArquivoSaidaInfoGain;
				saidaArquivoInfoGain = new FileOutputStream(caminhoDiscretizacao + "dadosParaSelecaoDeFeatures.txt");
				fileSaidaArquivoSaidaInfoGain = new PrintStream(saidaArquivoInfoGain);
				///fileSaidaArquivoSaidaInfoGain.println("mediaScore");
				
				//1-208 e 212
				int numberOfFeatures = 209;
				for(int i=0; i< numberOfFeatures; i++){
					fileSaidaArquivoSaidaInfoGain.print("feature"+(i+1)+",");
				}
				
				fileSaidaArquivoSaidaInfoGain.println("mediaScore");
				
				
				fileSaidaArquivoSaidaInfoGain.flush();

				for(int i=0; i< listaApis.size(); i++){
					String vetAPIs[] = listaApis.get(i);

					String nomeAPIs = "";

					for(int j=0; j< vetAPIs.length; j++){
						nomeAPIs += vetAPIs[j];
						if(j!=vetAPIs.length-1){
							nomeAPIs += "_";
						}
					}

					String caminhoArquivoFeaturesApi = caminhoPastaFeatures + nomeAPIs + ".txt";
					BufferedReader bufferedReaderArquivoResult = new BufferedReader(new InputStreamReader(new FileInputStream(caminhoArquivoFeaturesApi)));

					String line = "";
					while ((line = bufferedReaderArquivoResult.readLine()) != null) {
						String idPergunta = line.split("#")[1].split("-")[0];
						String idResposta = line.split("#")[1].split("-")[1];

						int scoreResposta = mapScores.get(idResposta);
						int scorePergunta = mapScores.get(idPergunta);
						
						double mediaScore = calculaMetricaAlvo(scorePergunta, scoreResposta);

						//if(!listaValoresAlvos.contains(mediaScore))
						//	listaValoresAlvos.add(mediaScore);

						String dados[] = line.split("#")[0].split(" ");

						String lineToWrite = "";
						
						for(int j=0; j<dados.length; j++){
							//pula m-qs m-as m-afc m-aa m-qvc m-qvcn
							if(j!=208 && j!=209 && j!=210 && j!=212 && j!=213 && j!=214){
								String id = dados[j].split(":")[0];
								Double valor = Double.parseDouble(dados[j].split(":")[1]);
								lineToWrite += valor + ",";
							}
						}
						
						lineToWrite += mediaScore;
						fileSaidaArquivoSaidaInfoGain.println(lineToWrite);
					}
					bufferedReaderArquivoResult.close();
				}
				fileSaidaArquivoSaidaInfoGain.close();

				/*for(int j=0; j<listaValoresAlvos.size(); j++){
					System.out.print(listaValoresAlvos.get(j)+",");
				}*/


			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
