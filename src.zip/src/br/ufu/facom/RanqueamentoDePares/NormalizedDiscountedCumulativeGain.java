package br.ufu.facom.RanqueamentoDePares;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;
import br.ufu.facom.lsa.GeradorDeCookbooks.ComparatorScoreDoRanqueamento;
import br.ufu.facom.lsa.GeradorDeCookbooks.DadoRanqueamento;

public class NormalizedDiscountedCumulativeGain {
	//o nome da api deve coincidir com o nroDaRodada na qual aquela api foi usada como teste
	private static void montaMapComDadosDoRanqueamento(List<DadoRanqueamento> listaDadosRanqueamento, String nomeAPIs, int codigoDaVariacao, int nroDaRodada, String nomePastaFeatures) {
		try{
			Map<String, Integer> mapScores = new HashMap<String, Integer>(); 
			ConexaoDB cbd = new ConexaoDB();
			//Conecta ao banco
			cbd.conectaAoBD();
			
			String query = ConsultasBD.consultaScoreDePosts();
			ResultSet rs = cbd.executaQuery(query);
			while(rs.next()){
				String idPost = rs.getString("postid");
				int score = rs.getInt("score");
				
				mapScores.put(idPost, score);
			}
			cbd.close();
			
			String caminhoArquivoRanqueamento = "/home/lucas/Dropbox/Folhas Experimentos/Experimento 1 - score/Variacao " + codigoDaVariacao + "/Rodada " + nroDaRodada + "/" + nomePastaFeatures +  "/ranqueamento_"+  nomeAPIs+ ".txt";
			String caminhoArquivoFeatures = "/home/lucas/Dropbox/resultadosFeatures/corrigidos/" + nomeAPIs + "_corrigido.txt";
		    //String caminhoArquivoRanqueamento = "/media/HDii-2x3Tb/Lucas/lucas2/drop box/Folhas Experimentos/Experimento 1 - score/Variacao 6/Rodada 10/ranqueamento_matplotlib.txt";
			//String caminhoArquivoFeatures = "/media/HDii-2x3Tb/Lucas/lucas2/drop box/Dropbox/resultadosFeatures/matplotlib.txt";
			//String caminhoArquivoRanqueamento = "/media/HDii-2x3Tb/Lucas/lucas2/drop box/Folhas Experimentos/Experimento 1 - score/Variacao " + codigoDaVariacao + "/Rodada " + nroDaRodada + "/ranqueamento_"+  nomeAPIs+ ".txt";
			//String caminhoArquivoFeatures = "/media/HDii-2x3Tb/Lucas/lucas2/drop box/Dropbox/resultadosFeatures/" + nomeAPIs + ".txt";
			
			BufferedReader bufferedReaderArquivoRanqueamento = new BufferedReader(new InputStreamReader(new FileInputStream(caminhoArquivoRanqueamento)));
			BufferedReader bufferedReaderArquivoFeatures = new BufferedReader(new InputStreamReader(new FileInputStream(caminhoArquivoFeatures)));
			
			String lineRanquemanto = "";
			String lineFeatures = "";
			while ((lineRanquemanto = bufferedReaderArquivoRanqueamento.readLine()) != null) {
				lineFeatures = bufferedReaderArquivoFeatures.readLine();
				
				String idPergunta = lineFeatures.split("#")[1].split("-")[0];
				String idResposta = lineFeatures.split("#")[1].split("-")[1];
				
				int scoreResposta = mapScores.get(idResposta);
				int scorePergunta = mapScores.get(idPergunta);
				
				double mediaScore = ProduzArquivosParaParaLearningToRank.calculaMetricaAlvo(scorePergunta, scoreResposta);
				
				Double scoreDoRank = Double.parseDouble(lineRanquemanto.split("\t")[2]);
				//Double scoreDoRank = Double.parseDouble(lineRanquemanto);
				
				DadoRanqueamento dr = new DadoRanqueamento(idResposta, idPergunta, scoreDoRank, mediaScore);
				listaDadosRanqueamento.add(dr);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
		
	//	listaMediaScores : lista com as medias dos scores (groud trough) na ordem de ranqueamento pelo algoritmo de L2R
	public static double calculaNdcgAtK(int K, List<Double> listaMediaScores){
		
		double dcgAtK = calculaDcgAtK(listaMediaScores, K);
		//System.out.println("DCG@ " + K + " = " + dcgAtK);
		Collections.sort(listaMediaScores);
		Collections.reverse(listaMediaScores);
		
		double melhorDcgAtK = calculaDcgAtK(listaMediaScores, K);
		//System.out.println("Melhor DCG@ " + K + " = " + melhorDcgAtK);
		
		double ndcgAtk = dcgAtK/melhorDcgAtK;
		
		return ndcgAtk;
	}

	private static double calculaDcgAtK(List<Double> listaMediaScores, int K) {
		// TODO Auto-generated method stub
		//alternativa 2
		double valorAcumulado = 0;
		
		for(int i=0; i< K; i++){
			valorAcumulado += Math.pow(2, listaMediaScores.get(i))/Math.log(2+i); 
		}
		
		
		//alternativa 1
		//double valorAcumulado = listaMediaScores.get(0);
		//for(int i=1; i< K; i++){
		//	valorAcumulado += listaMediaScores.get(i)/((Math.log(i+1)/Math.log(2)));
		//}
		
		
		return valorAcumulado;
	}
	
	public final static void main(String[] args) {
		try{

		String nomePastaFeatures = "all_minus_length";
			
		//10 apis
		int vetCodigoDasRodadas[] = {1,2,3,4,5,6,7,8,9,10};	
		//String vetNomesApis[] = {"qt4", "jquery_asp.net", "swing", "swt", "stl", "backbone.js", "log4net_c#", "awt", "boost", "matplotlib"};
		
		String vetNomesApis[] = {"junit", "sqlite", "qt", "swt", "stl", "backbone.js", "log4net", "awt", "boost", "matplotlib"};
		
			
		//5 apis
		//int vetCodigoDasRodadas[] = {1,2,3,4,5};	
		//String vetNomesApis[] = {"qt4", "jquery_asp.net", "swing", "swt", "stl"};
		
		for(int i=0; i< vetCodigoDasRodadas.length; i++){
			List<DadoRanqueamento> listaDadosRanqueamento = new ArrayList<DadoRanqueamento>();
			//montaMapComDadosDoRanqueamento(List<DadoRanqueamento> listaDadosRanqueamento, String nomeAPIs, int codigoDaVariacao, int nroDaRodada) {
			montaMapComDadosDoRanqueamento(listaDadosRanqueamento, vetNomesApis[i], 6, vetCodigoDasRodadas[i], nomePastaFeatures); 
				
			ComparatorScoreDoRanqueamento comp = new ComparatorScoreDoRanqueamento();
			Collections.sort(listaDadosRanqueamento, comp);
			
			List<Double> listaValores = new ArrayList<Double>();
			for(int j=0; j< listaDadosRanqueamento.size(); j++){
				listaValores.add(listaDadosRanqueamento.get(j).getScoreGoundThrough());
			}
			
			
			
			int k=100;
			System.out.println("Rodada " + vetCodigoDasRodadas[i] +  " - NDCG@" + k + " = " + calculaNdcgAtK(k, listaValores));
			
		}
			
		
		/*List<Double> listaValores = new ArrayList<Double>();
		listaValores.add(1.0);
		listaValores.add(2.0);
		listaValores.add(2.0);
		listaValores.add(0.0);
		System.out.println(calculaNdcgAtK(4, listaValores));*/
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
