package br.ufu.facom.RanqueamentoDePares;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;

public class AnaliseInfoGain {

	public static void main(String[] args) {

		//long menorMediaScore = -143;

		List<String[]> listaApis = new ArrayList<String[]>();
		String api1[] = {"sqlite"};
		listaApis.add(api1);
		String api2[] = {"qt"};
		listaApis.add(api2);
		String api3[] = {"swt"};
		listaApis.add(api3);
		String api4[] = {"stl"};
		listaApis.add(api4);
		String api5[] = {"junit"};
		listaApis.add(api5);
		String api6[] = {"log4net"};
		listaApis.add(api6);
		String api7[] = {"awt"};
		listaApis.add(api7);
		String api8[] = {"boost"};
		listaApis.add(api8);
		String api9[] = {"matplotlib"};
		listaApis.add(api9);
		String api10[] = {"backbone.js"};
		listaApis.add(api10);


		geraArquivoParaAnaliseInfoGain(1, 1, listaApis);
	}
	
	public static double calculaMetricaAlvo(double scorePergunta, double scoreResposta){
		//Vou testar media ponderada: peso da pergunta = 3, peso da resposta = 4
		int pesoPergunta = 3;
		int pesoResposta = 7;
		
		double mediaScore = (pesoPergunta*scorePergunta + pesoResposta*scoreResposta)/(double)(pesoPergunta+pesoResposta);
		
		return mediaScore;
	}

	private static void geraArquivoParaAnaliseInfoGain(int codigoExperimento, int codigoDaVariacao, List<String[]> listaApis) {

		try{
			List<Double> listaValoresAlvos = new ArrayList<Double>(); 

			String caminhoPastaFeatures = "/home/lucas/Dropbox/resultadosFeatures/corrigidos/";
			/*String caminhoPastaFolhas = "/home/lucas/Dropbox/Folhas Experimentos/";
			if(codigoExperimento == 1)
				caminhoPastaFolhas += "Experimento 1 - score/";
			else if(codigoExperimento == 2) 
				caminhoPastaFolhas += "Experimento 2 - avaliacao usuario/";

			caminhoPastaFolhas += "Variacao " + codigoDaVariacao + "/";*/

			//Nesse caso nao consideramos as features m-qs, m-as, pois nesse experimento a metrica alvo
			//é o score medio do par e essas features ja sao os scores
			//if(codigoExperimento == 1){
				Map<String, Integer> mapScores = new HashMap<String, Integer>(); 
				ConexaoDB cbd = new ConexaoDB();
				//Conecta ao banco
				cbd.conectaAoBD();

				String query = ConsultasBD.consultaScoreDePosts();
				ResultSet rs = cbd.executaQuery(query);
				while(rs.next()){
					String idPost = rs.getString("postid");
					int score = rs.getInt("score");

					mapScores.put(idPost, score);
				}
				cbd.close();
				//System.out.println("aki2");

				//FileOutputStream saidaArquivoInfoGain;
				//PrintStream fileSaidaArquivoSaidaInfoGain;
				//saidaArquivoInfoGain = new FileOutputStream(caminhoPastaFolhas + "dadosInfoGain.txt");
				//fileSaidaArquivoSaidaInfoGain = new PrintStream(saidaArquivoInfoGain);
				
				FileOutputStream saidaArquivoInfoGain;
				PrintStream fileSaidaArquivoSaidaInfoGain;
				saidaArquivoInfoGain = new FileOutputStream("/home/lucas/Dropbox/dadosInfoGain.txt");
				fileSaidaArquivoSaidaInfoGain = new PrintStream(saidaArquivoInfoGain);

				for(int i=0; i< listaApis.size(); i++){
					String vetAPIs[] = listaApis.get(i);

					String nomeAPIs = "";

					for(int j=0; j< vetAPIs.length; j++){
						nomeAPIs += vetAPIs[j];
						if(j!=vetAPIs.length-1){
							nomeAPIs += "_";
						}
					}

					String caminhoArquivoFeaturesApi = caminhoPastaFeatures + nomeAPIs + "_corrigido.txt";
					BufferedReader bufferedReaderArquivoResult = new BufferedReader(new InputStreamReader(new FileInputStream(caminhoArquivoFeaturesApi)));

					String line = "";
					while ((line = bufferedReaderArquivoResult.readLine()) != null) {
						String idPergunta = line.split("#")[1].split("-")[0];
						String idResposta = line.split("#")[1].split("-")[1];

						int scoreResposta = mapScores.get(idResposta);
						int scorePergunta = mapScores.get(idPergunta);

						
						double mediaScore =  calculaMetricaAlvo(scorePergunta, scoreResposta);
						
						//double mediaScore = (scorePergunta + scoreResposta)/2.0;
						
						
						
						//long mediaScoreInt = Math.round(mediaScore);

						//long valorTarget = mediaScoreInt + Math.abs(menorMediaScore) + 1;

						if(!listaValoresAlvos.contains(mediaScore))
							listaValoresAlvos.add(mediaScore);

						String dados[] = line.split("#")[0].split(" ");

						String lineToWrite = "";
						for(int j=0; j<dados.length; j++){
							//pula m-qs e m-as
							if(j!=209 && j!=208){
								String id = dados[j].split(":")[0];
								Double valor = Double.parseDouble(dados[j].split(":")[1]);
								lineToWrite += valor + ",";
							}
						}

						lineToWrite += mediaScore;

						fileSaidaArquivoSaidaInfoGain.println(lineToWrite);
					}
					bufferedReaderArquivoResult.close();
				}
				fileSaidaArquivoSaidaInfoGain.close();

				for(int j=0; j<listaValoresAlvos.size(); j++){
					System.out.print(listaValoresAlvos.get(j)+",");
				}


			//}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
