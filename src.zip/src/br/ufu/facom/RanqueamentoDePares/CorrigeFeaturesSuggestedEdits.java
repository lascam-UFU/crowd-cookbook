package br.ufu.facom.RanqueamentoDePares;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.ResultSet;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;

public class CorrigeFeaturesSuggestedEdits {
	
	static ConexaoDB cbd;
	
	public static void main(String[] args) {
		try{
			cbd = new ConexaoDB();
			//Conecta ao banco
			cbd.conectaAoBD();	
			
			
		      String path = "/home/lucas/Dropbox/resultadosFeatures"; 
			  String fileName;
			  File folder = new File(path);
			  File[] listOfFiles = folder.listFiles(); 
			 
			  for (int i = 0; i < listOfFiles.length; i++) 
			  {
				  fileName = listOfFiles[i].getName();
				  System.out.println(fileName);
				  
				  BufferedReader br = null;
				  String sCurrentLine;
		 
				  if((new File(listOfFiles[i].getAbsolutePath())).isDirectory())
					  continue;
				  br = new BufferedReader(new FileReader(listOfFiles[i].getAbsolutePath()));
				  
				  PrintWriter outFile = new PrintWriter(new FileWriter("/home/lucas/Dropbox/resultadosFeatures/corrigidos/" + fileName.replace(".txt", "") + "_corrigido.txt", false)); 
		 
				  while ((sCurrentLine = br.readLine()) != null) {
					  
					  if(!sCurrentLine.equals("") ){
						  
						  int idPergunta = Integer.parseInt((sCurrentLine.split("#")[1]).split("-")[0]);
						  int idResposta = Integer.parseInt((sCurrentLine.split("#")[1]).split("-")[1]);
						  
						  String partes[] = sCurrentLine.split(" ");
						 
						  //133 - r-ase (indice no vetor = 132)
						  //134 - r-qse (indice no vetor = 133)
						  //135 - r-suc (indice no vetor = 134)
						  //136 - r-qas (indice no vetor = 135)
						  //137 - r-aas (indice no vetor = 136)
						  //138 - r-aasa (indice no vetor = 137)
						  //139 - r-ars (indice no vetor = 138)
						  
						  String r_ase = partes[132];
						  //Calcula o nro de edicoes sugeridas a resposta
						  //VERIFICADA
					      int nroSugestoesDeEdicaoAResposta = calculaNroDeEdicoesSugeridasAPost(idResposta);
					      //System.out.println("r-ase = " + nroSugestoesDeEdicaoAResposta);
						  //textoSaida += idAtualFeature++ + ":" +nroSugestoesDeEdicaoAResposta+ " ";
					      String newAse = "133:" + (nroSugestoesDeEdicaoAResposta + .0);
					      
					      if(!r_ase.equals(newAse)){
					    	  int a = 0;
					    	  int b = a;
					      }
					      
					      partes[132] = newAse;
							
							//Calcula o nro de edicoes sugeridas a pergunta
							//VERIFICADA
							int nroSugestoesDeEdicaoAPergunta= calculaNroDeEdicoesSugeridasAPost(idPergunta);
							//System.out.println("r-qse = " + nroSugestoesDeEdicaoAPergunta);
							//textoSaida += idAtualFeature++ + ":" +nroSugestoesDeEdicaoAPergunta+ " ";
							 String newQse = "134:" + (nroSugestoesDeEdicaoAPergunta + .0);
						     partes[133] = newQse;
							
							
							//Calcula o nro de usuarios que sugeriram edicoes a pergunta ou resposta
							//VERIFICADA
							int nroDeUsuariosQueSugeriramEdicoes = calculaNroDeUsuariosQueSugeriramEdicoes(idResposta, idPergunta);
							//System.out.println("r-suc = " + nroDeUsuariosQueSugeriramEdicoes);
							//textoSaida += idAtualFeature++ + ":" +nroDeUsuariosQueSugeriramEdicoes+ " ";
							String newSuc = "135:" + (nroDeUsuariosQueSugeriramEdicoes + .0);
						    partes[134] = newSuc;
							
							
							//Calcula o nro de edits aprovados na resposta
							//VERIFICADA
							int nroSugestoesDeEdicaoAprovadasNaResposta = calculaNroDeEditsSugeridosAprovadosEmPost(idResposta);
							//System.out.println("r-qas = " + nroSugestoesDeEdicaoAprovadasNaResposta);
							//textoSaida += idAtualFeature++ + ":" +nroSugestoesDeEdicaoAprovadasNaResposta+ " ";
							String newQas = "136:" + (nroSugestoesDeEdicaoAprovadasNaResposta + .0);
						    partes[135] = newQas;
							
							
							//Calcula o nro de edits rejeitados na resposta
							//VERIFICADA
							int nroSugestoesDeEdicaoRejeitadasNaResposta = calculaNroDeEditsSugeridosRejeitadosEmPost(idResposta);
							//System.out.println("r-aas = " + nroSugestoesDeEdicaoRejeitadasNaResposta);
							//textoSaida += idAtualFeature++ + ":" +nroSugestoesDeEdicaoRejeitadasNaResposta+ " ";
							String newAas = "137:" + (nroSugestoesDeEdicaoRejeitadasNaResposta + .0);
						    partes[136] = newAas;
							
							
							//Calcula o nro de edits aprovados na pergunta
							//VERIFICADA
							int nroSugestoesDeEdicaoAprovadasNaPergunta = calculaNroDeEditsSugeridosAprovadosEmPost(idPergunta);
							//System.out.println("r-aas = " + nroSugestoesDeEdicaoAprovadasNaPergunta);
							//textoSaida += idAtualFeature++ + ":" +nroSugestoesDeEdicaoAprovadasNaPergunta+ " ";
							String newAssq = "138:" + (nroSugestoesDeEdicaoAprovadasNaPergunta + .0);
						    partes[137] = newAssq;
							
							
							//Calcula o nro de edits rejeitados na pergunta
							//VERIFICADA
							int nroSugestoesDeEdicaoRejeitadasNaPergunta = calculaNroDeEditsSugeridosRejeitadosEmPost(idPergunta);
							//System.out.println("r-ars = " + nroSugestoesDeEdicaoRejeitadasNaPergunta);
							//textoSaida += idAtualFeature++ + ":" +nroSugestoesDeEdicaoRejeitadasNaPergunta+ " ";
							String newArs = "139:" + (nroSugestoesDeEdicaoRejeitadasNaPergunta + .0);
						    partes[138] = newArs;
												  
						  String strToWrite = "";
						  for(int j=0; j< partes.length; j++){
							  strToWrite += partes[j];
							  
							  if(j != partes.length - 1)
								  strToWrite += " ";
						  }
						  
						  outFile.println(strToWrite);
						 
					  }
				}
				  outFile.close();
				  br.close();
				  
			  }
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private static int calculaNroDeEdicoesSugeridasAPost(int idPost) {
		try{
			String query = ConsultasBD.consultaNroDeEditSugeridosAPost(idPost);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroEditsSugeridos = rs.getInt("nroEditsSugeridos");
			return nroEditsSugeridos;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
	
	private static int calculaNroDeUsuariosQueSugeriramEdicoes(int idResposta, int idPergunta) {
		try{
			String query = ConsultasBD.consultaNroDeUsuariosQueSugeriramEdicoes(idResposta, idPergunta);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroEditsSugeridos = rs.getInt("nroUsuarios");
			return nroEditsSugeridos;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
	
	private static int calculaNroDeEditsSugeridosRejeitadosEmPost(int idPost) {
		try{
			String query = ConsultasBD.consultaNroDeEditsSugeridosRejeitadosPorPost(idPost);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroEditsSugeridos = rs.getInt("nroEditsSugeridos");
			return nroEditsSugeridos;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	private static int calculaNroDeEditsSugeridosAprovadosEmPost(int idPost) {
		try{
			String query = ConsultasBD.consultaNroDeEditsSugeridosAprovadosPorPost(idPost);
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			int nroEditsSugeridos = rs.getInt("nroEditsSugeridos");
			return nroEditsSugeridos;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
}
