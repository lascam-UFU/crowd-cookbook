import java.sql.ResultSet;

import org.htmlcleaner.HtmlCleaner;
import org.htmlcleaner.TagNode;

import br.ufu.facom.lsa.BD.ConexaoDB;
import br.ufu.facom.lsa.BD.ConsultasBD;
import br.ufu.facom.lsa.TesteHowTo.ClassificadorHowTo;


public class TesteDB {

	public static void main(String[] args) {
		try{
			
		    ConexaoDB cbd;
			cbd = new ConexaoDB();
			//Conecta ao banco
			cbd.conectaAoBD();	
			
			String query = "select body from posts where id = 10584204";
			ResultSet rs = cbd.executaQuery(query);
			rs.next();
			String body = rs.getString("body");
			System.out.println(body);
			
			System.out.println(calculaNroDeOcorrenciasDeTag("h1", body)+"");
			
		}catch(Exception e){
			e.printStackTrace();
		}

	}
	
	public static int calculaNroDeOcorrenciasDeTag(String nomeTag, String corpoPost){
		try{
			HtmlCleaner cleaner = new HtmlCleaner();
			TagNode root = cleaner.clean( corpoPost );
			
			Object[] nodes = root.evaluateXPath( "//" + nomeTag);
			return nodes.length;
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

}
