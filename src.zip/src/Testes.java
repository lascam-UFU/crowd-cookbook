import java.util.ArrayList;
import java.util.List;


public class Testes {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> listaGeral = new ArrayList<Integer>();
		listaGeral.add(3);
		listaGeral.add(3);
		
		//listaGeral.add(0);
		//listaGeral.add(0);
		System.out.println(calculaEntropia(listaGeral , true));

	}
	
	private static double calculaEntropia(
			List<Integer> listaGeral, boolean normalizaEntropa) {
		
		double soma = 0;
		for(int i=0; i< listaGeral.size(); i++){
			soma += listaGeral.get(i);
		}
		//TODO soma = 1, ou seja, todos os elementos da lista sao zero (iguais), por isso a entropia é um
		//if(soma == 0)
		//	return 1;
		int tamanho = listaGeral.size();
		double entropiaTotal = 0;
		
		for(int i=0; i< listaGeral.size(); i++){
			double prob;
			
			if(listaGeral.get(i) == 0)
				prob = 0;
			else
				prob =  listaGeral.get(i)/(double)soma;
			if(prob != 0){
				entropiaTotal += prob*(Math.log(prob)/Math.log(2));
			}
		}
		
		if(normalizaEntropa)
			return -entropiaTotal/tamanho;
		else{
			if(-entropiaTotal > 1){
				int a=0;
				int b=a;
			}
			return -entropiaTotal;
		}
			
	}

}
